// ============================================================
//  Visa Automator — core  (ISOLATED world)
// ------------------------------------------------------------
//  Foundation for every other module: the VA namespace, site
//  selectors, config store (persisted), ring-buffer logger,
//  reactive state store, the per-run cancellation registry, and
//  cancellable DOM helpers. Everything is attached to window.VA;
//  nothing is declared at top level (R1 — avoids cross-file
//  "Identifier already declared" parse errors in the shared world).
// ============================================================
(function () {
    'use strict';

    const VA = (window.VA = window.VA || {});
    if (VA.__coreInit) return;      // idempotent: only initialise once per page
    VA.__coreInit = true;
    VA.ready = { core: false, config: false, files: false };

    try {
        VA.VERSION = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '9.1';
    } catch (_) { VA.VERSION = '9.1'; }

    // ------------------------------------------------------------
    //  SELECTORS — the single source of truth for the live site.
    //  These are proven against the IVAC portal. Where the live markup
    //  is volatile (calendar day pills, centre dropdown), detection is
    //  functional (color token / text / structure) rather than tied to
    //  a single fragile class — see VA.site and steps.dates.
    // ------------------------------------------------------------
    VA.SELECTORS = {
        // ── auth ──────────────────────────────────────────────
        phone: 'input[name="phone"], input[type="tel"]',
        password: 'input[name="password"], input[type="password"]',
        submit: 'button[type="submit"]',
        otpBox: '#otp-0',
        otpBoxes: 'input[id^="otp-"], input[autocomplete="one-time-code"], input[inputmode="numeric"][maxlength="1"]',
        appointmentNotice: 'a[href="/appointment/notice"], a[href*="notice"]',
        // Generic orange primary action button (used as a fallback).
        orangeBtn: 'button.bg-\\[\\#FF671F\\], button[class*="FF671F"]',

        // ── Cloudflare human-verification ────────────────────────
        //  The widget appears in one of two shapes and we handle BOTH:
        //   • INLINE / same-origin: label.Nwax7 + span.QZrez1 + a real
        //     checkbox input, plus success artwork (#puam6 / svg#aOAb3 /
        //     circle.tGBx5). These are reachable from a content script, so we
        //     click the box and read the success mark directly.
        //   • Managed Turnstile in a CROSS-ORIGIN iframe (challenges.cloudflare
        //     .com): the checkbox and success artwork live INSIDE the iframe and
        //     are UNREACHABLE here. For that shape we solve via 2Captcha and
        //     invoke the page's own render() callback (net-hook.js) to enable
        //     the Continue/Confirm button.
        //  Either way, success is judged by OBSERVABLE page state — the success
        //  artwork, a page-produced token, or the target button enabling — never
        //  by a token WE injected. See verification.js isPassed().
        cf: {
            iframe: 'iframe[src*="challenges.cloudflare.com"]',
            widget: '#cf-turnstile, .cf-turnstile, [data-sitekey], label.Nwax7, .main-wrapper',
            token: 'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"], input[id^="cf-chl-widget"]',
            // The inline (same-origin) checkbox, when the build renders one — it
            // is genuinely clickable from here, unlike a cross-origin widget.
            hostCheckbox: 'input[type="checkbox"][aria-label*="human" i], label.Nwax7 input[type="checkbox"]',
            hostLabel: 'label.Nwax7',
            hostSpan: 'span.QZrez1, label.Nwax7 span',
            // Success markers the page paints once verification passes.
            success: '#puam6, svg#aOAb3, circle.tGBx5'
        },
        // Legacy flat aliases (still referenced in a couple of places).
        turnstile: '#cf-turnstile, .cf-turnstile, [data-sitekey], label.Nwax7',
        turnstileResponse: 'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"], input[id^="cf-chl-widget"]',
        turnstileIframe: 'iframe[src*="challenges.cloudflare.com"]',

        // ── file upload ──────────────────────────────────────
        fileInput: 'input[type="file"]',
        // A dropzone that is not yet usable (primary before CF passes, etc.)
        dropzoneDisabled: '[class*="cursor-not-allowed"], [class*="opacity-60"]',

        // ── calendar ─────────────────────────────────────────
        nextMonth: 'button[aria-label="Next month"]',
        prevMonth: 'button[aria-label="Previous month"]',
        // Legacy: some builds wrap days in a 7-col grid. Kept as a hint only —
        // day detection is functional (see steps.dates.scan), not grid-bound.
        calendarGrid: '.grid.grid-cols-7',

        // ── mission / centre ─────────────────────────────────
        // The live page uses custom controls, NOT <select>. These <select>
        // selectors remain only for the optional "Load From Session" scrape.
        missionSelect: 'select[name*="mission" i], select[id*="mission" i]',
        centreSelect: 'select[name*="ivac" i], select[name*="center" i], select[name*="centre" i], select[id*="center" i]',
        centreChevron: 'svg.lucide-chevron-down',

        // ── text-matched buttons (via VA.dom.findButtonByText) ──
        text: {
            confirmInfo: ['Confirm All Information is Correct', 'Confirm All Information', 'Confirm All'],
            saveContinue: ['Save & Continue', 'Save and Continue', 'Save And Continue'],
            goBack: ['Go Back'],
            confirmMission: ['Confirm Mission & IVAC Center', 'Confirm Mission & IVAC', 'Confirm Mission'],
            continueBooking: ['Continue Booking', 'Continue', 'Book Slot', 'Reserve Slot', 'Book Now', 'Proceed'],
            agree: ['I Agree', 'Agree', 'Next']
        }
    };

    // ── Supported missions & IVAC centres (config dropdowns + name-match) ──
    //  Names mirror the site's option text; matching is done normalized
    //  (case/space/punctuation-insensitive, Chittagong↔Chattogram synonym),
    //  so small formatting differences on the live page still match.
    VA.MISSIONS = ['Dhaka', 'Rajshahi', 'Chittagong', 'Sylhet', 'Khulna'];
    VA.CENTRES = ['IVAC,Dhaka(JFP)', 'IVAC,Rajshahi', 'IVAC,Chittagong', 'IVAC,Sylhet','IVAC,Khulna'];

    // The 8 progress stages (map 1:1 to the stepper). `nav` marks stages
    // that have no dedicated page — they are inferred as we move forward.
    VA.STAGES = [
        { key: 'login',      label: 'Login' },
        { key: 'otp',        label: 'OTP' },
        { key: 'otpSuccess', label: 'OTP Success', nav: true },
        { key: 'popup',      label: 'Popup' },
        { key: 'upload',     label: 'Upload' },
        { key: 'confirm',    label: 'Confirm Info' },
        { key: 'centre',     label: 'Mission/Centre' },
        { key: 'dates',      label: 'Dates' },
        { key: 'payment',    label: 'Payment' }
    ];
    VA.stageIndex = (key) => VA.STAGES.findIndex((s) => s.key === key);

    VA.DEFAULT_CONFIG = {
        applicantName: '',      // shown in the Run header so the operator knows who is running
        phone: '',
        password: '',
        mission: '',
        centre: '',
        preferredDates: [],     // ["YYYY-MM-DD", ...] tried first; others still rotate
        skipDates: [],          // ["YYYY-MM-DD", ...] never attempted (extra business rules)
        gap: 2000,              // brief settle between attempts (ms) — kept short on purpose; a date attempt's time is the real verify+result waits, not this gap
        backoff429: 15000,      // longer wait after a 429 rate-limit (ms)
        maxTriesPerDate: 3,     // attempts on ONE date before moving to the next
        attemptTimeout: 20000,  // hard cap for ONE attempt's result wait AFTER CF (ms) — user rule: never wait >20s post-verify (also clamped at the read site in steps.js)
        verifyTimeout: 45000,   // max wait for a Cloudflare gate to clear (legit slow-CF waiting; not busywork)
        settleAfterVerify: 1500,// short settle after CF passes before clicking Book (was a fixed 20s sleep — removed)
        uploadConfirmMs: 2000,  // per file: how long to wait for the SERVER's upload confirmation before auto re-clicking "Use". Kept short (clamped 500–5000ms at the read site) so a ready next box is not blocked for ages; a genuinely in-flight upload is still protected by uploadInflightMaxMs below (no duplicate is ever fired mid-request).
        uploadInflightMaxMs: 90000, // per file: while an upload_file POST is genuinely IN FLIGHT (slow/busy server still receiving the file), KEEP WAITING up to this long instead of re-clicking "Use" — avoids firing a duplicate mid-upload; only re-click once nothing is in flight or this cap is exceeded
        monthsToScan: 2,        // how many months forward to scan
        captchaApiKey: '',      // ← NOT used/shipped anymore: the 2Captcha key is fetched at runtime by background.js (getCaptchaKey) after a license check and kept in chrome.storage.session
        turnstileSiteKey: '0x4AAAAAACghKkJHL1t7UkuZ',
        toggles: {
            login: true,        // Auto Sign-In
            otp: true,          // Auto OTP Fill
            otpPhone: true,     // Fetch OTP from the phone app (relay) — falls back to manual entry
            popup: true,        // Auto Close Popup
            upload: true,       // Auto Upload PDF
            centre: true,       // Auto Centre/Mission
            book: true,         // Auto Date Book — the date-selection/booking loop (pause to book manually)
            navigate: true,     // Auto Navigate — generic "I Agree"/notice page transitions (NOT dates)
            cf: true,           // Auto Solve Cloudflare — OFF blocks ALL Cloudflare work (no solve, no alerts, no toasts)
            proxyIp: true       // Proxy IP — ON: fetch/generate a secure proxy IP. OFF: disabled, dedicated device IP is used
        }
    };

    // ── OTP anti-retry policy ────────────────────────────────────────────
    //  The gateway locks the account after a few WRONG OTP submissions, so a
    //  code the site rejected must never be sent again. This tracks every code
    //  submitted on the current OTP page and enforces a "give it time to be
    //  accepted" grace window plus a hard attempt cap. Kept small and pure so
    //  the controller stays readable and the policy is unit-testable.
    VA.otpGuard = {
        MAX_TRIES: 3,        // rejected codes on one OTP page before we stop
        GRACE_MS: 12000,     // how long a submitted code may take to be accepted
        _tried: {},
        _lastAt: 0,
        reset() { this._tried = {}; this._lastAt = 0; },
        // Did we submit a code that we haven't judged yet?
        pendingSubmit() { return !!this._lastAt; },
        // Is the last submit still within its confirmation grace window?
        awaitingConfirm(now) { return !!this._lastAt && ((now || Date.now()) - this._lastAt) < this.GRACE_MS; },
        // Was this exact code already submitted on this page? → never send again.
        alreadyTried(code) { return !!this._tried[code]; },
        markSubmitted(code, now) { this._tried[code] = true; this._lastAt = now || Date.now(); },
        // Stop treating the last submit as pending (it was rejected and discarded).
        clearPending() { this._lastAt = 0; },
        attempts() { return Object.keys(this._tried).length; },
        exhausted() { return this.attempts() >= this.MAX_TRIES; }
    };

    const CONFIG_KEY = 'visaAutomatorConfig';   // legacy single-profile config (read once for migration)
    const FILES_KEY = 'visaAutomatorFiles';     // legacy single-profile files  (read once for migration)
    const UI_KEY = 'visaAutomatorUi';
    // ── 3 isolated profile sets (Set 1/2/3) ──────────────────────────────
    //  New shape: PROFILES_KEY holds { active, sets:{set1,set2,set3} } where each
    //  set is a config object. PDFs are large, so each set's files live in their
    //  OWN key (visaAutomatorFiles:set1|set2|set3) — editing one set never
    //  rewrites another set's files. `unlimitedStorage` is granted in the manifest.
    const PROFILES_KEY = 'visaAutomatorProfiles';
    const PROFILE_IDS = ['set1', 'set2', 'set3'];
    const filesKeyFor = (id) => FILES_KEY + ':' + id;   // e.g. "visaAutomatorFiles:set1"
    VA.PROFILE_IDS = PROFILE_IDS;
    const clone = (o) => JSON.parse(JSON.stringify(o));
    VA.MAX_FILES = 4;
    VA.MAX_FILE_BYTES = 500 * 1024;

    // ------------------------------------------------------------
    //  Logger — ring buffer + live listeners. NEVER pass secrets.
    // ------------------------------------------------------------
    const MAX_LOGS = 500;
    function nowStr() {
        const d = new Date();
        const p = (n) => String(n).padStart(2, '0');
        return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
    }
    VA.logger = {
        entries: [],
        listeners: [],
        _lastKey: '',
        add(cat, msg, meta) {
            // Collapse identical back-to-back messages (loop ticks) into one.
            const key = cat + '|' + msg;
            if (key === this._lastKey && this.entries.length) {
                const last = this.entries[this.entries.length - 1];
                last.n = (last.n || 1) + 1;
                last.t = nowStr();
                this.listeners.forEach((fn) => { try { fn(last, true); } catch (_) {} });
                return last;
            }
            this._lastKey = key;
            const e = { t: nowStr(), cat, msg: String(msg), meta: meta || null, n: 1 };
            this.entries.push(e);
            if (this.entries.length > MAX_LOGS) this.entries.shift();
            this.listeners.forEach((fn) => { try { fn(e, false); } catch (_) {} });
            // Mirror to DevTools console for debugging.
            const tag = '%c[IVAC Slot Automation Pro]';
            const style = 'color:#f59e0b;font-weight:bold';
            if (cat === 'ERR') console.error(tag.replace('%c', ''), msg);
            else if (cat === 'WARN') console.warn('[IVAC Slot Automation Pro]', msg);
            else console.log(tag, style, msg);
            return e;
        },
        info(m, meta) { return this.add('INFO', m, meta); },
        ok(m, meta) { return this.add('OK', m, meta); },
        warn(m, meta) { return this.add('WARN', m, meta); },
        err(m, meta) { return this.add('ERR', m, meta); },
        net(m, meta) { return this.add('NET', m, meta); },
        waiting(m, meta) { return this.add('WAITING', m, meta); },
        clear() { this.entries = []; this._lastKey = ''; this.listeners.forEach((fn) => { try { fn(null, false); } catch (_) {} }); },
        on(fn) { this.listeners.push(fn); return () => { const i = this.listeners.indexOf(fn); if (i >= 0) this.listeners.splice(i, 1); }; }
    };

    // ------------------------------------------------------------
    //  State store — reactive; UI subscribes via .on()
    // ------------------------------------------------------------
    VA.state = {
        data: {
            running: false,
            runId: 0,
            detected: 'unknown',
            stageStates: {},        // stageKey -> 'pending'|'running'|'success'|'waiting'|'warning'|'error'|'skipped'
            attempts: 0,
            cycle: 0,
            availableDates: [],     // ["YYYY-MM-DD", ...] currently detected
            trying: null,           // date currently being attempted
            turnstile: 'no token',
            paymentUrl: '',
            waitingManual: null,    // stage key awaiting a page-advance (soft, auto-resumes)
            paused: null,           // { stage, reason } hard pause — needs explicit user Resume
            uploadConfirm: 'idle',  // 'idle' | 'waiting' (files verified, awaiting user) | 'confirmed'
            uploadedCount: 0,       // applicants verified as uploaded so far
            expectedCount: 0,       // number of files queued
            uploadName: '',         // file name currently uploading (for the progress UI)
            uploadPhase: '',        // '' | 'uploading' | 'uploaded' | 'failed' | 'done'
            missionText: '',        // mission value read off the page
            centreText: '',         // centre value read off the page
            datesOnly: false,       // page-only run: only the booking loop, skip login→centre
            tryOf: 0, tryMax: 0,    // date attempt N of M (for the Run UI status)
            nextIn: 0,              // seconds until next attempt
            error: null
        },
        listeners: [],
        get(k) { return k ? this.data[k] : this.data; },
        set(patch) { Object.assign(this.data, patch); this.emit(); },
        setStage(key, st) {
            const map = Object.assign({}, this.data.stageStates);
            map[key] = st;
            this.data.stageStates = map;
            this.emit();
        },
        emit() { this.listeners.forEach((fn) => { try { fn(this.data); } catch (_) {} }); },
        on(fn) { this.listeners.push(fn); return () => { const i = this.listeners.indexOf(fn); if (i >= 0) this.listeners.splice(i, 1); }; },
        reset() {
            this.data.stageStates = {};
            VA.STAGES.forEach((s) => { this.data.stageStates[s.key] = 'pending'; });
            Object.assign(this.data, {
                detected: 'unknown', attempts: 0, cycle: 0, availableDates: [],
                trying: null, turnstile: 'no token', waitingManual: null, paused: null,
                uploadConfirm: 'idle', uploadedCount: 0, expectedCount: 0,
                uploadName: '', uploadPhase: '',
                missionText: '', centreText: '', datesOnly: false,
                tryOf: 0, tryMax: 0, nextIn: 0, error: null
            });
            this.emit();
        }
    };
    VA.state.reset();

    // ------------------------------------------------------------
    //  Run registry — every timer / observer / abort lives here so
    //  Stop can flush them all. This is the backbone of R2/R7.
    // ------------------------------------------------------------
    VA.run = {
        loopTimer: null,
        countdownTimer: null,
        ac: null,               // AbortController for the active run
        busy: false,            // single-flight lock for the tick
        lastHref: '',
        nextAttemptAt: 0,       // timestamp gating the next booking attempt
        acted: null,            // { stage, at } cooldown to avoid re-clicking
        monthsScanned: 0,
        queue: [],              // rotating date candidates for the current cycle
        current: null,          // { cand, tries } — the date being retried (≤3 tries)
        last429At: 0,
        _uploadDone: 0,         // files THIS run actually attached & verified
        _uploadWaitSlot: null,  // slot we're waiting on (log-once guard)
        snap: null,             // frozen profile for the active run ({data,files}); set on start, cleared on stop. NOT touched by clearAll → survives Skip-This-Page.
        timers: new Set(),
        observers: new Set(),
        setTimeout(fn, ms) {
            const id = setTimeout(() => { this.timers.delete(id); fn(); }, ms);
            this.timers.add(id);
            return id;
        },
        observe(target, opts, cb) {
            const mo = new MutationObserver(cb);
            mo.observe(target, opts);
            this.observers.add(mo);
            return mo;
        },
        clearAll() {
            this.timers.forEach((id) => clearTimeout(id));
            this.timers.clear();
            this.observers.forEach((o) => { try { o.disconnect(); } catch (_) {} });
            this.observers.clear();
            if (this.loopTimer) { clearInterval(this.loopTimer); this.loopTimer = null; }
            if (this.countdownTimer) { clearInterval(this.countdownTimer); this.countdownTimer = null; }
            if (this.ac) { try { this.ac.abort(); } catch (_) {} this.ac = null; }
            this.busy = false;
            this.acted = null;
            this.queue = [];
            this.current = null;
            this.monthsScanned = 0;
            this.nextAttemptAt = 0;
        }
    };

    // ------------------------------------------------------------
    //  Storage wrapper (chrome.storage.local)
    // ------------------------------------------------------------
    VA.storage = {
        // legacy single-profile keys — read once during migration, never written after
        getConfig(cb) { try { chrome.storage.local.get(CONFIG_KEY, (r) => cb((r && r[CONFIG_KEY]) || {})); } catch (_) { cb({}); } },
        setConfig(obj) { try { chrome.storage.local.set({ [CONFIG_KEY]: obj }); } catch (_) {} },
        getFiles(cb) { try { chrome.storage.local.get(FILES_KEY, (r) => cb((r && r[FILES_KEY]) || [])); } catch (_) { cb([]); } },
        setFiles(arr) { try { chrome.storage.local.set({ [FILES_KEY]: arr }); } catch (_) {} },
        // 3-profile shape
        getProfiles(cb) { try { chrome.storage.local.get(PROFILES_KEY, (r) => cb((r && r[PROFILES_KEY]) || null)); } catch (_) { cb(null); } },
        setProfiles(obj) { try { chrome.storage.local.set({ [PROFILES_KEY]: obj }); } catch (_) {} },
        getFilesFor(id, cb) { const k = filesKeyFor(id); try { chrome.storage.local.get(k, (r) => cb((r && r[k]) || [])); } catch (_) { cb([]); } },
        setFilesFor(id, arr) { try { chrome.storage.local.set({ [filesKeyFor(id)]: arr }); } catch (_) {} },
        getUi(cb) { try { chrome.storage.local.get(UI_KEY, (r) => cb((r && r[UI_KEY]) || {})); } catch (_) { cb({}); } },
        setUi(obj) { try { chrome.storage.local.set({ [UI_KEY]: obj }); } catch (_) {} }
    };

    // ------------------------------------------------------------
    //  Config store — in-memory working copy + persistence.
    //  Files are held as real File objects for upload AND persisted
    //  as data URLs so the queue survives reloads.
    // ------------------------------------------------------------
    VA.config = {
        _data: JSON.parse(JSON.stringify(VA.DEFAULT_CONFIG)),
        _files: [],            // [{ file:File, name, size, type }]  primary first — active set's WORKING copy
        _otp: '',              // in-memory only — never persisted or logged
        activeId: 'set1',      // which profile set _data/_files currently mirror
        _profiles: null,       // { active, sets:{set1,set2,set3} } — hydrated in load()

        // ── snapshot-aware reads ──────────────────────────────────────────
        //  While a run is active, VA.run.snap freezes the profile so a mid-run
        //  edit/switch can't disturb the running automation (Part 16). These
        //  accessors return the FROZEN profile during a run (what steps.js and
        //  the Run header should see) and the live working copy when idle.
        _src() { return (VA.run && VA.run.snap) ? VA.run.snap.data : this._data; },
        creds() { const d = this._src(); return { phone: d.phone || '', password: d.password || '' }; },
        otp() { return (this._otp || '').replace(/\D/g, ''); },   // always live — entered during the run
        setOtp(v) { this._otp = (v || '').replace(/\D/g, '').slice(0, 8); },
        // Automation toggles: frozen with the run snapshot EXCEPT `book`, which
        // stays LIVE so the operator can pause/resume Auto Date Book mid-run
        // (setBooking writes the live copy; route() reads this). Freezing the
        // rest (login/otp/upload/centre/navigate) means a mid-run profile switch
        // can't change how the in-flight automation behaves.
        toggles() {
            const live = this._data.toggles;
            if (VA.run && VA.run.snap && VA.run.snap.data && VA.run.snap.data.toggles) {
                // `book` and `cf` stay LIVE so pausing Auto-Book or blocking
                // Cloudflare mid-run takes effect at once; the rest are frozen
                // with the run snapshot.
                return Object.assign({}, VA.run.snap.data.toggles, { book: live.book, cf: live.cf });
            }
            return live;
        },
        get(k) { const d = this._src(); return k ? d[k] : d; },
        files() { return (VA.run && VA.run.snap) ? VA.run.snap.files : this._files; },

        // ── live reads (always the editable working copy, ignore snapshot) ──
        //  The Config tab uses these so editing during a run shows/persists to
        //  the editable profile, not the frozen run snapshot.
        getLive(k) { return k ? this._data[k] : this._data; },
        filesLive() { return this._files; },

        set(patch, persist) {
            Object.assign(this._data, patch);
            if (patch.toggles) this._data.toggles = Object.assign({}, VA.DEFAULT_CONFIG.toggles, patch.toggles);
            if (persist !== false) this.saveConfig();
        },
        setToggle(key, val) {
            this._data.toggles = Object.assign({}, this._data.toggles, { [key]: !!val });
            this.saveConfig();
        },
        saveConfig() {
            // Persist the active set's config into the 3-profile shape (never the
            // legacy key). The OTP is never part of _data, so it is never stored.
            if (this._profiles && this._profiles.sets) {
                this._profiles.sets[this.activeId] = clone(this._data);
                this._profiles.active = this.activeId;
                VA.storage.setProfiles(this._profiles);
            } else {
                VA.storage.setConfig(this._data);   // pre-load fallback only
            }
        },

        // A frozen copy of the active profile for the duration of a run (Part 16).
        // data is deep-cloned; files keep the SAME File objects (no re-decode).
        snapshot() { return { data: clone(this._data), files: this._files.slice() }; },

        // Display name for a set: its applicantName, else "Set 1/2/3".
        profileName(id) {
            const s = (this._profiles && this._profiles.sets && this._profiles.sets[id]) || {};
            const n = (s.applicantName || '').trim();
            return n || ('Set ' + (PROFILE_IDS.indexOf(id) + 1));
        },

        // Switch the active profile: stash the current working copy, rehydrate
        // _data/_files from the target set, persist `active`, then cb() so the UI
        // re-renders. A running automation is unaffected (it reads VA.run.snap).
        switchProfile(id, cb) {
            if (!PROFILE_IDS.includes(id)) { if (cb) cb(); return; }
            try { VA.otpRelay && VA.otpRelay.reset(); } catch (_) {}
            if (!this._profiles) this._profiles = { active: id, sets: {} };
            this._profiles.sets[this.activeId] = clone(this._data);   // don't lose unsaved edits
            if (id === this.activeId) { VA.storage.setProfiles(this._profiles); if (cb) cb(); return; }
            this.activeId = id;
            this._profiles.active = id;
            VA.storage.setProfiles(this._profiles);
            this._hydrateActive(cb);
        },

        async addFiles(fileList) {
            const errors = [];
            for (const file of Array.from(fileList || [])) {
                if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
                    errors.push(`${file.name}: not a PDF`); continue;
                }
                if (file.size > VA.MAX_FILE_BYTES) {
                    errors.push(`${file.name}: ${(file.size / 1024).toFixed(0)} KB > 500 KB`); continue;
                }
                if (this._files.length >= VA.MAX_FILES) { errors.push(`Max ${VA.MAX_FILES} files`); break; }
                if (this._files.find((f) => f.name === file.name && f.size === file.size)) continue;
                this._files.push({ file, name: file.name, size: file.size, type: file.type || 'application/pdf' });
            }
            await this.saveFiles();
            return errors;
        },
        removeFile(idx) {
            this._files.splice(idx, 1);
            return this.saveFiles();
        },
        clearFiles() { this._files = []; return this.saveFiles(); },

        async saveFiles() {
            try {
                const recs = [];
                for (const f of this._files) {
                    recs.push({ name: f.name, size: f.size, type: f.type, dataUrl: await fileToDataUrl(f.file) });
                }
                VA.storage.setFilesFor(this.activeId, recs);   // active set ONLY — never touches other sets
            } catch (e) { VA.logger.warn('Could not persist file queue: ' + (e && e.message)); }
        },

        // Hydrate _data/_files from the active set. Optionally accept pre-loaded
        // file records (migration passes them to avoid a storage read/write race).
        _hydrateActive(cb, preRecs) {
            const setData = (this._profiles && this._profiles.sets && this._profiles.sets[this.activeId]) || {};
            this._data = Object.assign(clone(VA.DEFAULT_CONFIG), setData);
            this._data.toggles = Object.assign({}, VA.DEFAULT_CONFIG.toggles, setData.toggles || {});
            // One-time upgrade of the per-file upload window. It is NOT exposed
            // in the UI, so a saved profile carrying the old 4000ms default would
            // otherwise silently mask the new, snappier 2000ms and the operator
            // would never get the faster re-click. Any other value is respected.
            if (this._data.uploadConfirmMs === 4000) this._data.uploadConfirmMs = VA.DEFAULT_CONFIG.uploadConfirmMs;
            VA.ready.config = true;
            const finish = async (recs) => {
                this._files = await hydrateFileRecs(recs);
                VA.ready.files = true;
                if (cb) cb();
            };
            if (preRecs) finish(preRecs);
            else VA.storage.getFilesFor(this.activeId, finish);
        },

        load(cb) {
            VA.storage.getProfiles((prof) => {
                if (prof && prof.sets) {
                    // New 3-profile shape already present.
                    this._profiles = normalizeProfiles(prof);
                    this.activeId = PROFILE_IDS.includes(prof.active) ? prof.active : 'set1';
                    this._profiles.active = this.activeId;
                    this._hydrateActive(cb);
                    return;
                }
                // ── First run on this build: migrate the legacy single profile ──
                //  Non-destructive (Part 5): legacy keys are only READ. Old config +
                //  files are copied into Set 1; Set 2/3 start from defaults. The old
                //  keys are left intact until the new shape is confirmed in use.
                VA.storage.getConfig((cfg) => {
                    const hasLegacy = cfg && Object.keys(cfg).length > 0;
                    this._profiles = {
                        active: 'set1',
                        sets: {
                            set1: hasLegacy ? clone(cfg) : clone(VA.DEFAULT_CONFIG),
                            set2: clone(VA.DEFAULT_CONFIG),
                            set3: clone(VA.DEFAULT_CONFIG)
                        }
                    };
                    this.activeId = 'set1';
                    VA.storage.setProfiles(this._profiles);
                    if (hasLegacy) {
                        VA.storage.getFiles((recs) => {
                            if (recs && recs.length) VA.storage.setFilesFor('set1', recs);
                            this._hydrateActive(cb, recs || []);
                        });
                    } else {
                        this._hydrateActive(cb, []);
                    }
                });
            });
        }
    };

    function fileToDataUrl(file) {
        return new Promise((resolve, reject) => {
            const r = new FileReader();
            r.onload = () => resolve(r.result);
            r.onerror = () => reject(r.error || new Error('read failed'));
            r.readAsDataURL(file);           // avoids btoa(...spread) stack overflow
        });
    }
    async function dataUrlToFile(rec) {
        try {
            const blob = await (await fetch(rec.dataUrl)).blob();
            return new File([blob], rec.name, { type: rec.type || 'application/pdf' });
        } catch (_) {
            // CSP fallback: manual base64 -> bytes (chunked)
            const base64 = String(rec.dataUrl).split(',')[1] || '';
            const bin = atob(base64);
            const len = bin.length;
            const bytes = new Uint8Array(len);
            for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
            return new File([bytes], rec.name, { type: rec.type || 'application/pdf' });
        }
    }

    async function hydrateFileRecs(recs) {
        const out = [];
        for (const r of (recs || [])) {
            try { out.push({ file: await dataUrlToFile(r), name: r.name, size: r.size, type: r.type }); }
            catch (_) { /* skip unreadable record */ }
        }
        return out;
    }
    // Guarantee all three sets exist and `active` is valid (a hand-edited or
    // partially-written profiles blob can't crash hydration).
    function normalizeProfiles(prof) {
        const sets = (prof && prof.sets) || {};
        PROFILE_IDS.forEach((id) => {
            if (!sets[id] || typeof sets[id] !== 'object') sets[id] = clone(VA.DEFAULT_CONFIG);
        });
        return { active: PROFILE_IDS.includes(prof && prof.active) ? prof.active : 'set1', sets };
    }

    // ------------------------------------------------------------
    //  Net consumer — receives events from the bridge, logs NET
    //  breadcrumbs, and surfaces payment URL / 429 to subscribers.
    // ------------------------------------------------------------
    VA.net = {
        subscribers: [],
        recent: [],             // small ring of recent events for post-hoc inspection
        uploads: 0,             // count of CONFIRMED file-upload responses (page's own upload_file POST → 2xx); upload() waits on this rising, not on our own attach
        uploadAt: 0,            // Date.now() of the last confirmed upload response
        pendingUploads: 0,      // page's upload_file POSTs STARTED but not yet settled (from net-hook start/end pings); >0 ⇒ an upload is genuinely in progress
        pendingUploadAt: 0,     // Date.now() the in-flight count first went 0→positive (age of the current in-flight upload)
        on(fn) { this.subscribers.push(fn); return () => { const i = this.subscribers.indexOf(fn); if (i >= 0) this.subscribers.splice(i, 1); }; },
        // True once we have observed ANY page request — i.e. the net-hook is
        // delivering. On the live site this flips immediately; in the offline vm
        // test harness (no network) it stays false, so upload() falls back to its
        // degraded settle path and the existing tests stay green.
        isLive() { return this.recent.length > 0; },
        // Is the page currently uploading a file (a upload_file POST in flight)?
        // Lets upload() WAIT on a slow-but-working upload instead of re-clicking
        // "Use" and firing a duplicate. inflightAgeMs() caps that patience so a
        // truly hung request eventually falls back to a re-click.
        inflightUpload() { return this.pendingUploads > 0; },
        inflightAgeMs() { return this.pendingUploads > 0 && this.pendingUploadAt ? Date.now() - this.pendingUploadAt : 0; },
        _ingest(evt) {
            if (!evt) return;
            // In-flight upload tracking (net-hook start/end pings, and the live
            // count that rides on every event). Update BEFORE anything else so a
            // start ping — which carries no HTTP status — still moves the counter.
            if (typeof evt.inflight === 'number') {
                if (evt.inflight > 0 && this.pendingUploads === 0) this.pendingUploadAt = Date.now();
                if (evt.inflight === 0) this.pendingUploadAt = 0;
                this.pendingUploads = evt.inflight;
            }
            if (evt.phase === 'start' || evt.phase === 'end') return; // counter-only ping: no status to log / count / surface
            const path = shortPath(evt.url);
            evt.at = Date.now();
            this.recent.push(evt);
            if (this.recent.length > 40) this.recent.shift();
            // A genuine file-upload acceptance by the server. Match `/upload/` so
            // `upload_file_v321` counts but the page-refresh `over-view-v421`
            // (also under /file/) does NOT. This is the truth upload() advances on.
            // (method is passed through un-normalized by net-hook, so match it
            // case-insensitively — a page may send `post` or `POST`.)
            if (/^post$/i.test(evt.method || '') && evt.status >= 200 && evt.status < 300 && /upload/i.test(evt.url || '')) {
                this.uploads++;
                this.uploadAt = Date.now();
            }
            if (evt.webviewUrl) {
                VA.logger.net(`payment link in response — ${evt.status} ${path}`);
            } else if (evt.status === 429) {
                VA.run.last429At = Date.now();
                VA.logger.warn(`Rate limited (429) — ${path}. Backing off.`);
            } else if (evt.status >= 400) {
                VA.logger.net(`${evt.method} ${path} — ${evt.status}`);
            } else if (evt.status) {
                VA.logger.net(`${evt.method} ${path} — ${evt.status}`);
            }
            this.subscribers.forEach((fn) => { try { fn(evt); } catch (_) {} });
        },
        drain() {
            const Q = window.__VA_NET_QUEUE || [];
            while (Q.length) { this._ingest(Q.shift()); }
        },
        // Resolve with the next network event for which pred(evt) is truthy,
        // or null on timeout / abort. This lets the booking loop wait on the
        // site's ACTUAL response (heavy-traffic friendly) instead of a fixed
        // sleep. Always resolves (never rejects).
        awaitNext(pred, opts) {
            opts = opts || {};
            const timeout = opts.timeout != null ? opts.timeout : 60000;
            const signal = opts.signal;
            return new Promise((resolve) => {
                if (signal && signal.aborted) { resolve(null); return; }
                let done = false, tid = null, off = null;
                const finish = (val) => {
                    if (done) return; done = true;
                    if (tid) clearTimeout(tid);
                    if (off) off();
                    if (signal) signal.removeEventListener('abort', onAbort);
                    resolve(val);
                };
                const onAbort = () => finish(null);
                off = this.on((evt) => { try { if (pred(evt)) finish(evt); } catch (_) {} });
                if (signal) signal.addEventListener('abort', onAbort);
                tid = setTimeout(() => finish(null), timeout);
            });
        }
    };

    function shortPath(url) {
        try { const u = new URL(url, location.href); return u.pathname + (u.search ? '?…' : ''); }
        catch (_) { return String(url || '').slice(0, 60); }
    }
    VA.shortPath = shortPath;

    // ------------------------------------------------------------
    //  DOM utils — cancellable via AbortSignal (R2)
    // ------------------------------------------------------------
    function resolveEl(selector) {
        return typeof selector === 'function' ? selector() : document.querySelector(selector);
    }
    function isVisible(el) {
        if (!el) return false;
        // A detached node can never be visible, and short-circuiting here avoids
        // the forced-layout read below for the transient nodes React throws away
        // constantly during a re-render.
        if (el.isConnected === false) return false;
        return el.offsetParent !== null && getComputedStyle(el).visibility !== 'hidden';
    }
    // Coalesce a high-frequency callback into at most one run per animation
    // frame. A whole-document MutationObserver on a re-rendering SPA can fire
    // many times per frame; running an expensive, layout-reading predicate on
    // every one is exactly the layout-thrash that stalls the tab. One run per
    // frame keeps detection visually instant while capping the cost — and it is
    // why N tabs no longer multiply into a freeze.
    //
    // rAF is PAUSED in a background tab, so when hidden we fall back to a timer:
    // a background tab's run must still observe DOM changes promptly (the safety
    // poll inside waitForEvent is the ultimate backstop, but this keeps it fast).
    const _raf = (typeof requestAnimationFrame === 'function')
        ? requestAnimationFrame
        : (fn) => setTimeout(fn, 16);
    function coalesce(fn) {
        let queued = false;
        return function () {
            if (queued) return;
            queued = true;
            const run = () => { queued = false; fn(); };
            if (typeof document !== 'undefined' && document.hidden) setTimeout(run, 0);
            else _raf(run);
        };
    }
    // Core primitive: poll `pred()` until it returns a truthy value, the
    // timeout elapses, or the signal aborts. Always resolves (never rejects).
    function waitFor(pred, opts) {
        opts = opts || {};
        const timeout = opts.timeout != null ? opts.timeout : 20000;
        const interval = opts.interval != null ? opts.interval : 300;
        const signal = opts.signal;
        return new Promise((resolve) => {
            const start = Date.now();
            let tid = null;
            const onAbort = () => { if (tid) clearTimeout(tid); cleanup(); resolve(null); };
            function cleanup() { if (signal) signal.removeEventListener('abort', onAbort); }
            if (signal) {
                if (signal.aborted) { resolve(null); return; }
                signal.addEventListener('abort', onAbort);
            }
            const tick = () => {
                if (signal && signal.aborted) { cleanup(); resolve(null); return; }
                let res = null;
                try { res = pred(); } catch (_) { res = null; }
                if (res) { cleanup(); resolve(res); return; }
                if (Date.now() - start >= timeout) { cleanup(); resolve(null); return; }
                tid = setTimeout(tick, interval);
            };
            tick();
        });
    }
    function sleep(ms, signal) {
        return new Promise((resolve) => {
            if (signal && signal.aborted) { resolve(false); return; }
            let tid = null;
            const onAbort = () => { if (tid) clearTimeout(tid); if (signal) signal.removeEventListener('abort', onAbort); resolve(false); };
            if (signal) signal.addEventListener('abort', onAbort);
            tid = setTimeout(() => { if (signal) signal.removeEventListener('abort', onAbort); resolve(true); }, ms);
        });
    }
    // Event-driven sibling of waitFor: resolves the INSTANT `pred()` turns
    // truthy, driven by a MutationObserver on the document rather than a fixed
    // poll — so a real page state change (e.g. an applicant upload card being
    // inserted) is acted on immediately, not on the next poll boundary. A slow
    // safety poll (`fallback`) still runs so a state change that emits no
    // mutation can't stall it. Always resolves (never rejects): pred()'s value,
    // or null on timeout/abort. Same contract as waitFor, just lower latency.
    function waitForEvent(pred, opts) {
        opts = opts || {};
        const timeout = opts.timeout != null ? opts.timeout : 20000;
        const fallback = opts.fallback != null ? opts.fallback : 500;
        const signal = opts.signal;
        return new Promise((resolve) => {
            const start = Date.now();
            let mo = null, tid = null, done = false;
            function cleanup() {
                if (done) return; done = true;
                if (mo) { try { mo.disconnect(); } catch (_) {} }
                if (tid) clearTimeout(tid);
                if (signal) signal.removeEventListener('abort', onAbort);
            }
            function onAbort() { cleanup(); resolve(null); }
            function check() {
                if (done) return;
                if (tid) { clearTimeout(tid); tid = null; }   // one pending poll at most
                if (signal && signal.aborted) { cleanup(); resolve(null); return; }
                let res = null;
                try { res = pred(); } catch (_) { res = null; }
                if (res) { cleanup(); resolve(res); return; }
                if (Date.now() - start >= timeout) { cleanup(); resolve(null); return; }
                tid = setTimeout(check, fallback);
            }
            if (signal) {
                if (signal.aborted) { resolve(null); return; }
                signal.addEventListener('abort', onAbort);
            }
            try {
                // Scope to <body> (not documentElement) and COALESCE: the observer
                // now triggers at most one check() per frame instead of one per
                // mutation record. The predicate reads layout (offsetParent /
                // getComputedStyle), so running it on every record was the single
                // biggest source of the multi-tab freeze. A run per frame is just
                // as responsive to the eye, at a fraction of the cost.
                mo = new MutationObserver(coalesce(check));
                mo.observe(document.body || document.documentElement || document,
                    { childList: true, subtree: true, attributes: true });
            } catch (_) { mo = null; }
            check();   // immediate check + arms the safety poll
        });
    }
    function findButtonByText(text) {
        const list = Array.isArray(text) ? text : [text];
        const needles = list.map((t) => t.toLowerCase());
        const btns = document.querySelectorAll('button, [role="button"], a');
        for (const b of btns) {
            const t = (b.textContent || '').trim().toLowerCase();
            if (!t) continue;
            for (const n of needles) { if (t.includes(n)) return b; }
        }
        return null;
    }
    function fill(el, value) {
        if (!el) return false;
        try {
            el.focus();
            // React-friendly value set (bypasses the value setter override).
            const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            const setter = Object.getOwnPropertyDescriptor(proto, 'value');
            if (setter && setter.set) setter.set.call(el, value); else el.value = value;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            return true;
        } catch (_) { el.value = value; return true; }
    }
    function click(el) { if (el) { try { el.click(); return true; } catch (_) {} } return false; }

    VA.dom = {
        resolveEl,
        isVisible,
        waitFor,
        waitForEvent,
        sleep,
        findButtonByText,
        fill,
        click,
        waitForElement(selector, opts) { return waitFor(() => resolveEl(selector), opts); },
        waitForClickable(selector, opts) {
            return waitFor(() => {
                const el = resolveEl(selector);
                if (el && isVisible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true') return el;
                return null;
            }, opts);
        },
        waitForButtonText(texts, opts) {
            return waitFor(() => {
                const el = findButtonByText(texts);
                if (el && isVisible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true') return el;
                return null;
            }, opts);
        }
    };

    // ---- extended DOM / string helpers (see plan) ----
    Object.assign(VA.dom, {
        // Resolve once the element is gone or hidden (post-action confirmation).
        waitForGone(selector, opts) {
            return waitFor(() => {
                const el = resolveEl(selector);
                return (!el || !isVisible(el)) ? true : null;
            }, opts);
        },
        // Semantic alias — an enabled, visible, clickable element.
        waitForEnabled(selector, opts) { return this.waitForClickable(selector, opts); },
        // Normalize for tolerant name matching: lowercase, drop non-alphanumerics,
        // and canonicalize the Chittagong↔Chattogram spelling the site alternates.
        normalize(str) {
            let s = String(str == null ? '' : str).toLowerCase();
            s = s.replace(/chattogram|chottogram|chattagram/g, 'chittagong');
            return s.replace(/[^a-z0-9]+/g, '');
        },
        // True when a page label and a configured value refer to the same place.
        matchName(pageText, wanted) {
            const a = this.normalize(pageText), b = this.normalize(wanted);
            if (!a || !b) return false;
            return a === b || a.indexOf(b) !== -1 || b.indexOf(a) !== -1;
        },
        // True when a control is disabled for interaction — INCLUDING a <div>
        // "disabled" only via Tailwind classes. The page's mission row is exactly
        // that shape (opacity-50 cursor-not-allowed) and a <div> has no `disabled`
        // property, so a property-only check silently treats it as usable.
        isControlDisabled(el) {
            if (!el) return true;
            if (el.disabled === true || el.hasAttribute('disabled') ||
                el.getAttribute('aria-disabled') === 'true') return true;
            let n = el;
            for (let i = 0; n && i < 4; i++) {
                const cls = (n.getAttribute && (n.getAttribute('class') || '')) || '';
                if (/cursor-not-allowed|pointer-events-none|opacity-50|opacity-60/i.test(cls)) return true;
                n = n.parentElement;
            }
            return false;
        }
    });

    // ------------------------------------------------------------
    //  VA.site — IVAC-specific DOM readers (calendar / uploads).
    //  Kept apart from generic VA.dom so the site-specific bits are
    //  easy to re-pin if the live markup shifts.
    // ------------------------------------------------------------
    VA.site = {
        // Classify a calendar day pill by its Tailwind color token / disabled state.
        //   selected    → orange  bg-[#FF671F]
        //   available   → green   border/text-[#004638]
        //   unavailable → grey    text-[#B0B0B0] or disabled/cursor-not-allowed
        classifyDatePill(el) {
            if (!el) return null;
            const cls = el.getAttribute('class') || '';
            const disabled = el.disabled === true || el.hasAttribute('disabled') ||
                el.getAttribute('aria-disabled') === 'true';
            if (/FF671F/i.test(cls)) return 'selected';
            if (/004638/i.test(cls)) return 'available';
            if (disabled || /B0B0B0/i.test(cls) || /cursor-not-allowed/i.test(cls)) return 'unavailable';
            return null;
        },

        // How many applicant RESULT CARDS the page has rendered. One card
        // appears per successfully uploaded PDF, so this is the page's own
        // proof of upload progress.
        //
        // ⚠ Deliberately does NOT read "Total number of applicants: N" — that
        // heading is the count declared up front (4 before any file lands), so
        // trusting it made upload() believe it was already finished and skip
        // every attach, including the primary. Cards only exist post-upload.
        uploadedCards() {
            let n = 0;
            const seen = new Set();
            document.querySelectorAll('button, div[role="button"]').forEach((b) => {
                if (b.closest && b.closest('#va-panel-host')) return;
                const cls = b.getAttribute('class') || '';
                // The applicant card is the tall (82px) white row.
                if (!/h-\[82px\]|h-\[82px\]/.test(cls) && !/82px/.test(cls)) return;
                if (!VA.dom.isVisible(b)) return;
                const t = (b.textContent || '').trim().toLowerCase();
                if (!t || seen.has(t)) return;
                seen.add(t);
                n++;
            });
            if (n) return n;
            // Fallback for builds that label applicants without the 82px card:
            // count distinct "Primary Applicant" / "Applicant 02" labels.
            const labels = new Set();
            document.querySelectorAll('span, p, h3, h4').forEach((s) => {
                if (s.closest && s.closest('#va-panel-host')) return;
                if (s.children && s.children.length) return;
                const t = (s.textContent || '').trim().toLowerCase();
                if (t === 'primary applicant' || /^applicant\s*0?\d+$/.test(t)) labels.add(t);
            });
            return labels.size;
        },

        // Every site file input, ordered so slot 0 is ALWAYS the primary
        // applicant. Panel inputs are excluded so the Config file picker can
        // never be mistaken for a site dropzone.
        //
        // ⚠ Ordering is by VISUAL POSITION (top-to-bottom, then left-to-right),
        // NOT raw DOM order. The bug the user reported ("primary uploaded 2nd,
        // a file from the row of 3 went first") was exactly a DOM-order vs
        // visual-order mismatch: the primary dropzone renders first on screen
        // but its <input> is not necessarily document-index 0. A dropzone whose
        // label/heading says "Primary" is pinned to slot 0 as a tie-breaker so
        // the primary can never slip even if layout shifts.
        uploadInputs() {
            const inputs = Array.from(document.querySelectorAll('input[type="file"]'))
                .filter((inp) => !(inp.closest && inp.closest('#va-panel-host')));
            const meta = inputs.map((inp, i) => {
                let top = 0, left = 0, primary = false;
                try {
                    // Measure the dropzone container, not the hidden input (a
                    // display:none input reports rect 0,0).
                    const zone = inp.closest('label, div, button') || inp;
                    const r = zone.getBoundingClientRect();
                    top = r.top; left = r.left;
                    const txt = (zone.textContent || '').toLowerCase();
                    if (/primary/.test(txt)) primary = true;
                } catch (_) {}
                return { inp, i, top, left, primary };
            });
            meta.sort((a, b) => {
                if (a.primary !== b.primary) return a.primary ? -1 : 1;   // primary always first
                if (Math.abs(a.top - b.top) > 6) return a.top - b.top;    // then top-to-bottom
                if (Math.abs(a.left - b.left) > 6) return a.left - b.left;// then left-to-right
                return a.i - b.i;                                          // stable fallback
            });
            return meta.map((m) => m.inp);
        },

        // How many site file inputs currently hold a file. Together with
        // uploadedCards() this gives an "attached" vs "accepted" pair, so a
        // file that attached but was rejected server-side can be told apart
        // from one that never attached at all.
        filledUploadInputs() {
            return this.uploadInputs().filter((inp) => inp.files && inp.files.length).length;
        },

        // Best available measure of verified upload progress: whichever of the
        // two signals is higher. Cards are authoritative once they render;
        // filled inputs cover the window before the card paints.
        countApplicants() {
            return Math.max(this.uploadedCards(), this.filledUploadInputs());
        },

        // Is a dropzone element currently locked (greyed / not-allowed)?
        inputDisabled(inp) {
            return !inp || inp.disabled === true || inp.hasAttribute('disabled') ||
                inp.getAttribute('aria-disabled') === 'true';
        },

        zoneLocked(inp) {
            if (this.inputDisabled(inp)) return true;
            let el = inp;
            for (let i = 0; el && i < 4; i++) {
                const cls = el.getAttribute && (el.getAttribute('class') || '');
                if (cls && /cursor-not-allowed|opacity-60|pointer-events-none/i.test(cls)) return true;
                el = el.parentElement;
            }
            return false;
        },

        // The file input for a SPECIFIC slot index (0 = primary). Returns null
        // when that slot isn't usable yet (still locked, e.g. the primary
        // dropzone before Cloudflare passes) or already holds a file.
        //
        // Slot-addressed rather than "next free" so ordering cannot slip: file
        // N always goes to input N, and the primary is always index 0.
        uploadInputAt(idx) {
            const inputs = this.uploadInputs();
            const inp = inputs[idx];
            if (!inp) return null;
            if (inp.files && inp.files.length) return null;   // already filled
            if (this.zoneLocked(inp)) return null;            // dropzone disabled
            return inp;
        },

        // Legacy helper kept for compatibility: first usable empty slot.
        activeUploadInput() {
            const inputs = this.uploadInputs();
            for (let i = 0; i < inputs.length; i++) {
                const inp = this.uploadInputAt(i);
                if (inp) return inp;
            }
            return null;
        },

        // The box to fill next, chosen the SAME way the panel's working "Use"
        // button chooses it: the first OPEN box in primary-first visual order.
        //
        // Deliberately NOT slot-indexed. Indexing breaks the moment the page
        // removes a box it has accepted (indices shift, so index N stops meaning
        // applicant N) — "first open box" is immune to that, which is why the
        // manual button keeps working and the old index math stalled. It still
        // goes through uploadInputAt(), so it never targets a locked dropzone:
        // the primary stays locked (and therefore stays first-to-fill) until
        // Cloudflare passes.
        strictUploadInput() {
            return this.activeUploadInput();
        },

        // Last-resort loose pick, mirroring the manual "Use" button's raw
        // fallback: the first non-panel file input not already holding a file,
        // ignoring the locked heuristic. Used ONLY for non-primary files so a
        // re-rendered / renumbered page can never strand the auto-upload.
        rawUploadInput() {
            const inputs = Array.from(document.querySelectorAll('input[type="file"]'))
                .filter((inp) => !(inp.closest && inp.closest('#va-panel-host')));
            for (const inp of inputs) {
                if (this.inputDisabled(inp)) continue;
                if (inp.files && inp.files.length) continue;
                return inp;
            }
            return null;
        },

        // Visible red-marked upload error (the "red marked it" the user
        // described). Returns the message, or '' when clean.
        //
        // Requires BOTH a red/alert container AND upload-relevant wording, so
        // a decorative red asterisk or an unrelated Tailwind "error" utility
        // class can't hard-pause a healthy run.
        findUploadError() {
            const sels = '[role="alert"], [class*="text-red" i], [class*="text-danger" i], ' +
                '[class*="border-red" i], [class*="bg-red" i], .invalid-feedback';
            // Must name a FILE/PDF problem. Deliberately excludes bare
            // "required"/"invalid" — those are ordinary form validation and
            // would hard-pause a healthy run.
            const RELEVANT = /(pdf|upload|file\s*(size|type|format|name)?|attachment|too\s*large|exceed|not\s*allowed|unsupported|corrupt|scan)/i;
            // …and must ALSO look like a failure, not a hint/label.
            const FAILISH = /(invalid|fail|error|not|cannot|can't|unable|too|exceed|unsupported|corrupt|only|must|allowed|large|required)/i;
            const nodes = document.querySelectorAll(sels);
            for (const n of nodes) {
                if (n.closest && n.closest('#va-panel-host')) continue;
                if (!VA.dom.isVisible(n)) continue;
                const t = (n.textContent || '').trim();
                if (t.length < 8 || t.length > 300) continue;
                if (!RELEVANT.test(t) || !FAILISH.test(t)) continue;
                return t.slice(0, 140);
            }
            return '';
        }
    };

    VA.ready.core = true;
})();
