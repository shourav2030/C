// ============================================================
//  Visa Automator — proxy routing client  (ISOLATED world)
// ------------------------------------------------------------
//  Dynamic routing for the Run tab's "Proxy IP" card. The IP is
//  served by the licensing backend, so the panel shows that the
//  proxy is coming from the server + API rather than being made up
//  locally. When the backend is unreachable, or has no IP set, the
//  caller falls back to ui.js's local generator — the card always
//  ends up with a value.
//
//  Content scripts NEVER fetch cross-origin themselves; every call
//  is relayed through the background service worker, which owns the
//  API base + host permission (same as the license / OTP relays).
//
//  Backend contract (base = the license API host):
//    POST /api/proxy/ip     → { success, ip, region?, operator? }
//    POST /api/proxy/shift  → { success, ip, region?, operator? }
//  The current IP is served from the backend's PROXY_IP env var.
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.proxy) return;

    // A real dotted-quad only — anything else (empty, error payload, hostname)
    // is treated as "no backend IP" so the caller falls back to local generation.
    const IPV4 = /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;
    function isIpv4(v) { return typeof v === 'string' && IPV4.test(v.trim()); }

    function pickIp(resp) {
        const data = resp && resp.data;
        const ip = (resp && resp.ip) || (data && (data.ip || data.proxyIp));
        return isIpv4(ip) ? ip.trim() : null;
    }

    // Relay one proxy API call through the service worker.
    function bgFetch(action, body) {
        return new Promise((resolve) => {
            let done = false;
            const finish = (v) => { if (!done) { done = true; resolve(v); } };
            try {
                chrome.runtime.sendMessage({ action, body: body || {} }, (resp) => {
                    if (chrome.runtime.lastError) return finish({ ok: false, error: 'offline' });
                    finish(resp || { ok: false, error: 'offline' });
                });
            } catch (_) { finish({ ok: false, error: 'offline' }); }
            setTimeout(() => finish({ ok: false, error: 'timeout' }), 8000);
        });
    }

    const api = {
        isIpv4,

        // Current proxy IP for the Run tab. Resolves to a dotted-quad string, or
        // null when the backend is unreachable / has none set (caller falls back
        // to the local generator). Never throws.
        async ip() {
            return pickIp(await bgFetch('proxy_ip_fetch'));
        },

        // Rotate to the next proxy IP (backend /api/proxy/shift). Available now
        // but NOT wired into the panel yet — call it here when the endpoint is
        // live. Resolves to { ok, ip, region, operator, source } or { ok:false }.
        async shift() {
            const resp = await bgFetch('proxy_shift');
            const ip = pickIp(resp);
            const data = resp && resp.data;
            return {
                ok: !!ip,
                ip,
                region: (data && data.region) || null,
                operator: (data && data.operator) || null,
                source: (resp && resp.source) || null
            };
        }
    };

    VA.proxy = api;
})();
