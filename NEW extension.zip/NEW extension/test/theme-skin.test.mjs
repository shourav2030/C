// ============================================================
//  Theme / skin contract — BASIC and PRO share one design.
// ------------------------------------------------------------
//  A licence TIER (from the signed payload) drives the panel's
//  FEATURES and BRANDING; a SKIN (tier → palette) drives the
//  COLOURS. BASIC and PRO deliberately share the "core" skin, and

// ============================================================
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeDocument, loadModulesFull } from './harness.mjs';

// ui.js only DEFINES VA.ui at load (no DOM work until mount()), so it can be
// loaded straight into the harness and driven with stub refs.
function boot() {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc, { modules: ['core.js', 'panel-css.js', 'ui.js'] });
    VA.logger = { info() {}, ok() {}, warn() {}, err() {} };
    const ui = VA.ui;
    ui.wrap = { dataset: {} };
    ui.host = { dataset: {} };
    const txt = () => ({ textContent: '' });
    ui.refs = { brandLogo: txt(), brandTitle: txt(), brandTag: txt(), proxyBox: { style: {} } };
    return { VA, ui };
}

test('BASIC and PRO render the same skin, but keep their own tier', () => {
    const { ui } = boot();

    ui.applyTheme('boost', 'PRO');
    assert.equal(ui.wrap.dataset.theme, 'core', 'PRO must render in the BASIC skin');
    assert.equal(ui.host.dataset.theme, 'core');
    assert.equal(ui.theme, 'boost', 'tier must stay boost — it gates the proxy card');
    assert.equal(ui.refs.brandTitle.textContent, 'PRO', 'strip still reads PRO');
    assert.equal(ui.refs.proxyBox.style.display, '', 'proxy card shown for PRO');

    ui.applyTheme('core', 'BASIC');
    assert.equal(ui.wrap.dataset.theme, 'core');
    assert.equal(ui.host.dataset.theme, 'core');
    assert.equal(ui.theme, 'core');
    assert.equal(ui.refs.brandTitle.textContent, 'BASIC');
    assert.equal(ui.refs.proxyBox.style.display, 'none', 'proxy card hidden for BASIC');
});

test('PRO and BASIC are pixel-identical apart from the strip + proxy card', () => {
    const basic = boot();
    const pro = boot();
    basic.ui.applyTheme('core', 'BASIC');
    pro.ui.applyTheme('boost', 'PRO');

    assert.equal(pro.ui.wrap.dataset.theme, basic.ui.wrap.dataset.theme, 'same palette');
    assert.equal(pro.ui.refs.brandLogo.textContent, '◆');
    assert.equal(basic.ui.refs.brandLogo.textContent, '◦');
});

test('VPS FAST SERVER and SUPER CHARGE render the SAME skin, but keep their own tier', () => {
    const { ui } = boot();

    ui.applyTheme('elite', 'VPS FAST SERVER');
    assert.equal(ui.wrap.dataset.theme, 'elite', 'VPS FAST SERVER uses the elite skin');
    assert.equal(ui.theme, 'elite');

    ui.applyTheme('overdrive', 'SUPER CHARGE SERVER');
    assert.equal(ui.wrap.dataset.theme, 'elite', 'SUPER CHARGE must reuse the VPS/elite skin');
    assert.equal(ui.host.dataset.theme, 'elite');
    assert.equal(ui.theme, 'overdrive', 'tier stays overdrive — it gates branding + splash');
    assert.equal(ui.refs.brandTitle.textContent, 'SUPER CHARGE SERVER', 'strip still shows the plan name');
});

test('VPS FAST SERVER and SUPER CHARGE are pixel-identical apart from the strip', () => {
    const vps = boot();
    const sc = boot();
    vps.ui.applyTheme('elite', 'VPS FAST SERVER');
    sc.ui.applyTheme('overdrive', 'SUPER CHARGE SERVER');

    assert.equal(sc.ui.wrap.dataset.theme, vps.ui.wrap.dataset.theme, 'same palette');
    assert.equal(sc.ui.refs.brandLogo.textContent, '⚡', 'SUPER CHARGE keeps its own logo');
    assert.equal(vps.ui.refs.brandLogo.textContent, '✦');
});

test('unknown or missing tier falls back to the BASIC skin', () => {
    const { ui } = boot();

    ui.applyTheme(undefined, '');
    assert.equal(ui.wrap.dataset.theme, 'core');
    assert.equal(ui.theme, 'core');
    assert.equal(ui.refs.brandTitle.textContent, 'BASIC');

    ui.applyTheme('nonsense', '');
    assert.equal(ui.wrap.dataset.theme, 'core');
});

test('the shared core skin still ships in the stylesheet', () => {
    const { VA } = boot();
    assert.match(VA.PANEL_CSS, /\.wrap\[data-theme="core"\]\s*\{/);
    assert.match(VA.PANEL_CSS, /\.wrap\[data-theme="boost"\]\s*\{/,
        'the gold palette is kept (unassigned) for an easy revert');
    assert.match(VA.PANEL_CSS, /\.wrap\[data-theme="overdrive"\]\s*\{/,
        'the crimson palette is kept (unassigned) for an easy revert');
});
