(function () {
    const VA = window.VA;
    if (!VA || VA.otpRelay) return;

    const INSTALL_KEY = 'ivacInstallId';
    let _install = null;
    let _pending = null;
    let _stageAt = 0;
    let _nextPollAt = 0;
    let _failures = 0;
    let _lastNoticeAt = 0;

    function getLocal(key) {
        return new Promise((resolve) => {
            try { chrome.storage.local.get(key, (r) => resolve((r && r[key]) || null)); }
            catch (_) { resolve(null); }
        });
    }

    async function installId() {
        if (_install) return _install;
        try {
            const id = VA.license && VA.license.installationId && VA.license.installationId();
            if (id) { _install = id; return id; }
        } catch (_) {}
        _install = await getLocal(INSTALL_KEY);
        return _install;
    }

    function bgFetch(endpoint, body) {
        return new Promise((resolve) => {
            let done = false;
            const finish = (value) => { if (!done) { done = true; resolve(value); } };
            try {
                chrome.runtime.sendMessage({ action: 'otp_fetch', endpoint, body }, (resp) => {
                    if (chrome.runtime.lastError) return finish({ ok: false, error: 'offline' });
                    finish(resp || { ok: false, error: 'offline' });
                });
            } catch (_) { finish({ ok: false, error: 'offline' }); }
            setTimeout(() => finish({ ok: false, error: 'timeout' }), 8000);
        });
    }

    function notice(fn, message) {
        if (Date.now() - _lastNoticeAt < 15000) return;
        _lastNoticeAt = Date.now();
        try { fn(message); } catch (_) {}
    }

    function cadence() {
        const age = Date.now() - (_stageAt || Date.now());
        const base = age < 10000 ? 2000 : age < 30000 ? 4000 : 8000;
        return Math.round(base * (0.9 + Math.random() * 0.2));
    }

    function schedule(ms) { _nextPollAt = Date.now() + Math.max(1000, ms || cadence()); }

    function ms(value) {
        const t = Date.parse(value || '');
        return Number.isNaN(t) ? null : t;
    }

    // True when the code in hand can no longer be the right one: its freshness
    // window lapsed, or the server lease lapsed without confirmation — either way
    // a newer OTP may now be waiting and we should poll again.
    function stale() {
        if (!_pending) return false;      // manually typed code — never overwrite it
        const now = Date.now();
        const exp = ms(_pending.expiresAt);
        const lease = ms(_pending.leaseExpiresAt);
        if (exp !== null && exp <= now) return true;
        if (lease !== null && lease <= now) return true;
        return false;
    }

    const api = {
        pending() { return _pending; },

        reset() {
            _pending = null;
            _stageAt = Date.now();
            _nextPollAt = 0;
            _failures = 0;
            VA.config.setOtp('');
        },

        enterStage() {
            if (!_stageAt) { _stageAt = Date.now(); _nextPollAt = 0; }
        },

        async poll(phone) {
            const p = (phone || '').trim();
            if (!p) return { status: 'invalid' };
            const install = await installId();
            if (!install) return { status: 'preparing' };
            const resp = await bgFetch('/api/otp/poll', { phone: p, installationId: install });
            const data = resp && resp.data;
            if (resp && resp.ok && data && data.success !== false) {
                if (typeof data.otp !== 'string' || !data.deliveryId) {
                    return { status: 'empty', pollAfterMs: data.pollAfterMs || 4000 };
                }
                const digits = data.otp.replace(/\D/g, '');
                if (digits.length < 4 || digits.length > 8) return { status: 'invalid' };
                return {
                    status: 'received', otp: digits, deliveryId: data.deliveryId,
                    expiresAt: data.expiresAt || '', leaseExpiresAt: data.leaseExpiresAt || '',
                    installationId: install, phone: p,
                    pollAfterMs: data.pollAfterMs || 2000
                };
            }
            if (resp && resp.status === 429) return { status: 'rate_limited', retryAfterMs: resp.retryAfterMs || 15000 };
            if (resp && resp.error === 'timeout') return { status: 'timeout' };
            if (resp && resp.status === 400) return { status: 'invalid_phone' };
            if (resp && resp.status >= 500) return { status: 'server_error' };
            return { status: 'offline' };
        },

        async tryFetch() {
            this.enterStage();
            if (Date.now() < _nextPollAt) return false;
            const phone = (VA.config.get('phone') || '').trim();
            if (!phone) {
                notice(VA.logger.warn, 'OTP phone relay: add the phone number in Config.');
                schedule(15000);
                return false;
            }
            // Already holding a code that can still be the right one → wait for the
            // page to confirm it instead of hammering the server.
            if (VA.config.otp() && !stale()) { schedule(3000); return false; }

            const held = VA.config.otp();
            const result = await this.poll(phone);
            if (result.status === 'received') {
                _pending = result;
                _failures = 0;
                schedule(result.pollAfterMs);
                VA.config.setOtp(result.otp);
                try { if (VA.ui && VA.ui.setOtpDisplay) VA.ui.setOtpDisplay(result.otp); } catch (_) {}
                if (held && held !== result.otp) VA.logger.ok('Newer OTP received from phone → filling the latest.');
                else VA.logger.ok('OTP received from phone → filling.');
                return true;
            }
            if (result.status === 'rate_limited') schedule(result.retryAfterMs);
            else if (result.status === 'empty') schedule(result.pollAfterMs);
            else {
                _failures++;
                schedule(Math.min(15000, 2000 * Math.pow(2, Math.min(_failures, 3))));
            }
            const text = result.status === 'rate_limited' ? 'OTP relay is busy — waiting before retry.'
                : result.status === 'invalid_phone' ? 'OTP relay: the phone number in Config looks invalid.'
                    : result.status === 'offline' || result.status === 'timeout' ? 'OTP relay is offline — you can type the OTP manually.'
                        : 'Waiting for OTP from the phone app…';
            notice(VA.logger.waiting, text);
            return false;
        },

        async ack() {
            if (!_pending) return true;
            const item = _pending;
            const resp = await bgFetch('/api/otp/ack', {
                phone: item.phone,
                installationId: item.installationId,
                deliveryId: item.deliveryId
            });
            const data = resp && resp.data;
            if (resp && resp.ok && data && data.acknowledged) {
                this.reset();
                return true;
            }
            notice(VA.logger.warn, 'OTP filled, but delivery confirmation is pending — retrying safely.');
            return false;
        },

        // Drop a code the site rejected: consume its delivery server-side (so the
        // backend never hands the SAME code out again) and clear the local lease +
        // code. Deliberately does NOT reset the poll cadence — we go back to
        // waiting normally for a NEW code instead of hammering the server. Safe
        // when nothing is leased (a manually typed code): it just clears it.
        async discard() {
            const item = _pending;
            _pending = null;
            VA.config.setOtp('');
            if (!item) return false;
            try {
                const resp = await bgFetch('/api/otp/ack', {
                    phone: item.phone,
                    installationId: item.installationId,
                    deliveryId: item.deliveryId
                });
                const data = resp && resp.data;
                return !!(resp && resp.ok && data && data.acknowledged);
            } catch (_) { return false; }
        }
    };

    VA.otpRelay = api;
})();
