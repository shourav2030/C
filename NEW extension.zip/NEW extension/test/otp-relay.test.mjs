import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeDocument, loadModulesFull } from './harness.mjs';

const INSTALL = '123e4567-e89b-42d3-a456-426614174000';

function boot(responses) {
    const calls = [];
    const { doc } = makeDocument();
    const loaded = loadModulesFull(doc, {
        seed: { ivacInstallId: INSTALL },
        modules: ['core.js', 'otp-relay.js'],
        sendMessage(message, callback) {
            calls.push(message);
            const next = responses.shift();
            callback(typeof next === 'function' ? next(message) : next);
        },
    });
    loaded.VA.config._data.phone = '01712345678';
    return { ...loaded, calls };
}

test('relay stores leased OTP and ACK clears it only after confirmation', async () => {
    const { VA, calls } = boot([
        { ok: true, data: { success: true, otp: '123456', deliveryId: 'd0c36a57-ec4a-4b8d-a8ab-7783008a44c1', pollAfterMs: 2000 } },
        { ok: true, data: { success: true, acknowledged: true } },
    ]);

    assert.equal(await VA.otpRelay.tryFetch(), true);
    assert.equal(VA.config.otp(), '123456');
    assert.equal(VA.otpRelay.pending().deliveryId, 'd0c36a57-ec4a-4b8d-a8ab-7783008a44c1');
    assert.equal(calls[0].endpoint, '/api/otp/poll');

    assert.equal(await VA.otpRelay.ack(), true);
    assert.equal(calls[1].endpoint, '/api/otp/ack');
    assert.equal(VA.config.otp(), '');
    assert.equal(VA.otpRelay.pending(), null);
});

test('failed ACK preserves the OTP and delivery for safe retry', async () => {
    const { VA } = boot([
        { ok: true, data: { success: true, otp: '87654321', deliveryId: '24cb6705-92ad-4909-8f3a-e901629d6259' } },
        { ok: false, status: 503, data: { success: false } },
    ]);
    await VA.otpRelay.tryFetch();
    assert.equal(VA.config.otp(), '87654321', '7–8 digit OTPs are not truncated');
    assert.equal(await VA.otpRelay.ack(), false);
    assert.equal(VA.config.otp(), '87654321');
    assert.ok(VA.otpRelay.pending());
});

test('adaptive cadence avoids polling on every controller tick', async () => {
    const { VA, calls } = boot([
        { ok: true, data: { success: true, otp: null, deliveryId: null, pollAfterMs: 4000 } },
    ]);
    assert.equal(await VA.otpRelay.tryFetch(), false);
    assert.equal(await VA.otpRelay.tryFetch(), false);
    assert.equal(calls.length, 1);
});

test('reset clears stale OTP and pending delivery across runs/profiles', async () => {
    const { VA } = boot([
        { ok: true, data: { success: true, otp: '112233', deliveryId: '22d32cf4-369e-42b5-aeb3-f9014f0fb2af' } },
    ]);
    await VA.otpRelay.tryFetch();
    VA.otpRelay.reset();
    assert.equal(VA.config.otp(), '');
    assert.equal(VA.otpRelay.pending(), null);
});

test('a lapsed lease lets a newer OTP replace the code in hand', async () => {
    const past = new Date(Date.now() - 60_000).toISOString();
    const { VA, calls } = boot([
        { ok: true, data: { success: true, otp: '111111', deliveryId: 'd0c36a57-ec4a-4b8d-a8ab-7783008a44c1', leaseExpiresAt: past, pollAfterMs: 1000 } },
        { ok: true, data: { success: true, otp: '222222', deliveryId: '24cb6705-92ad-4909-8f3a-e901629d6259', leaseExpiresAt: new Date(Date.now() + 60_000).toISOString(), pollAfterMs: 1000 } },
    ]);
    await VA.otpRelay.tryFetch();
    assert.equal(VA.config.otp(), '111111');
    await new Promise((r) => setTimeout(r, 1100));
    await VA.otpRelay.tryFetch();
    assert.equal(calls.length, 2);
    assert.equal(VA.config.otp(), '222222', 'the newest code supersedes the stale lease');
});

test('a fresh lease in hand is held — no extra polling', async () => {
    const future = new Date(Date.now() + 60_000).toISOString();
    const { VA, calls } = boot([
        { ok: true, data: { success: true, otp: '135790', deliveryId: 'd0c36a57-ec4a-4b8d-a8ab-7783008a44c1', leaseExpiresAt: future, pollAfterMs: 1000 } },
    ]);
    await VA.otpRelay.tryFetch();
    await new Promise((r) => setTimeout(r, 1100));
    assert.equal(await VA.otpRelay.tryFetch(), false);
    assert.equal(calls.length, 1, 'a still-valid code must not be re-fetched');
    assert.equal(VA.config.otp(), '135790');
});

test('a manually typed OTP is never overwritten by polling', async () => {
    const { VA, calls } = boot([]);
    VA.config.setOtp('999999');
    assert.equal(await VA.otpRelay.tryFetch(), false);
    assert.equal(calls.length, 0, 'manual entry takes precedence over the relay');
    assert.equal(VA.config.otp(), '999999');
});
