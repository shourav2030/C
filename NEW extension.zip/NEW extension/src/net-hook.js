// ============================================================
//  Visa Automator — network hook  (MAIN world, document_start)
// ------------------------------------------------------------
//  Runs in the PAGE's JS world so it can wrap the page's own
//  fetch / XMLHttpRequest and observe the responses the site
//  makes for its own authenticated session. It NEVER modifies
//  requests or responses — it only reads a clone to detect:
//    • the payment gateway URL (a `webview_url` field), and
//    • HTTP 429 (rate limiting) + generic status codes.
//
//  Findings are handed to the ISOLATED world via postMessage
//  with a string-only payload (R3). MAIN and ISOLATED share the
//  DOM but NOT JS globals, so postMessage is the only safe bridge.
// ============================================================
(function () {
    'use strict';
    if (window.__VA_NET_HOOK_INSTALLED) return;
    window.__VA_NET_HOOK_INSTALLED = true;

    const MARKER = 1;

    // Live count of the page's own file-upload POSTs that have STARTED but not
    // yet completed. upload() (via VA.net.inflightUpload) reads this to tell a
    // slow-but-working upload apart from a stalled one, so it WAITS on a real
    // in-flight upload instead of re-clicking "Use" and firing a duplicate.
    // Matches the same endpoint as the confirmed-upload counter (POST + /upload/).
    let inflightUploads = 0;
    function isUploadReq(method, url) {
        return /^post$/i.test(String(method || '')) && /upload/i.test(String(url || ''));
    }

    // ------------------------------------------------------------
    //  DO NOT touch the Turnstile globals.
    // ------------------------------------------------------------
    //  We used to wrap turnstile.render (via an accessor on window.turnstile)
    //  to capture the page's success callback. That BROKE the challenge: with
    //  the extension on, Cloudflare's platform fingerprints the page, sees the
    //  accessor / non-native render, decides the environment is tampered, and
    //  never renders the "Verify you are human" widget at all — so the operator
    //  could never solve it and Sign In stayed disabled. With the extension off
    //  the widget appeared normally.
    //
    //  Rendering the challenge is non-negotiable — nothing in the flow works
    //  without it — so we now leave window.turnstile completely alone (no
    //  accessor, no render wrap, no poll). A solved 2Captcha token is still
    //  delivered to the page in deliverToken() below, but ONLY through
    //  non-intrusive, POST-challenge hooks (a data-callback attribute, known
    //  global callback names, and a lazy getResponse shim) — none of which run
    //  at document_start or alter the Turnstile API before it renders. The
    //  same-origin inline checkbox is handled by a real click in
    //  verification.js, which is what actually ticks it on the live site.

    function post(payload) {
        try {
            // Only primitive, structured-cloneable fields cross the world boundary.
            window.postMessage({
                __va: MARKER,
                url: String(payload.url || ''),
                method: String(payload.method || 'GET'),
                status: payload.status | 0,
                webviewUrl: payload.webviewUrl ? String(payload.webviewUrl) : '',
                // Live in-flight upload count + a start/end phase so the ISOLATED
                // world can track uploads that are still in progress. A phased
                // ping carries no HTTP status; it only moves the counter.
                inflight: inflightUploads | 0,
                phase: (payload.phase === 'start' || payload.phase === 'end') ? payload.phase : ''
            }, '*');
        } catch (_) { /* ignore */ }
    }

    // Pull a payment URL out of a response body string, if present.
    // The IVAC flow returns { ..., webview_url: "https://gateway/..." }.
    function extractWebviewUrl(text) {
        if (!text || text.length > 2_000_000) return '';
        // Fast reject before the (relatively costly) regex / JSON parse.
        if (text.indexOf('webview_url') === -1 && text.indexOf('http') === -1) return '';
        try {
            const j = JSON.parse(text);
            const found = deepFindUrl(j);
            if (found) return found;
        } catch (_) { /* not JSON — fall through to regex */ }
        const m = text.match(/"?webview_url"?\s*[:=]\s*"?(https?:\/\/[^"'\\\s]+)/i);
        return m ? m[1] : '';
    }

    function deepFindUrl(obj, depth) {
        depth = depth || 0;
        if (obj == null || depth > 6) return '';
        if (typeof obj === 'object') {
            for (const k in obj) {
                if (!Object.prototype.hasOwnProperty.call(obj, k)) continue;
                const v = obj[k];
                if (/webview_url|payment_url|gateway_url|redirect_url|checkout_url/i.test(k) &&
                    typeof v === 'string' && /^https?:\/\//.test(v)) {
                    return v;
                }
                if (typeof v === 'object') {
                    const nested = deepFindUrl(v, depth + 1);
                    if (nested) return nested;
                }
            }
        }
        return '';
    }

    function report(url, method, status, bodyText) {
        const webviewUrl = extractWebviewUrl(bodyText);
        if (status === 429 || webviewUrl || status >= 400) {
            post({ url, method, status, webviewUrl });
        } else {
            // Still surface a lightweight NET breadcrumb for the Logs tab.
            post({ url, method, status, webviewUrl: '' });
        }
    }

    // ------------------------------------------------------------
    //  Solved-CAPTCHA token delivery (ISOLATED → MAIN).
    //
    //  A content script lives in an isolated JS world, so it cannot call the
    //  page's own functions. verification.js posts the solved token here and we
    //  hand it to the page using only NON-INTRUSIVE hooks that run after the
    //  challenge has already rendered — we never wrap or accessor-trap the
    //  Turnstile API (that stopped the widget from rendering; see the note at
    //  the top of this file). Read-only with respect to the site's data.
    // ------------------------------------------------------------
    function deliverToken(token) {
        if (!token || typeof token !== 'string') return;
        let invoked = false;   // did a REAL page-side success callback actually run?

        // 1) turnstile.getResponse consumers: some pages poll it. Patch it to
        //    return our token so a later read succeeds. This runs only on
        //    delivery (post-challenge) and merely reads window.turnstile — it
        //    installs no accessor and does not touch render.
        try {
            const ts = window.turnstile;
            if (ts && typeof ts.getResponse === 'function' && !ts.__vaGetPatched) {
                const orig = ts.getResponse.bind(ts);
                ts.getResponse = function () {
                    try { const v = orig.apply(this, arguments); if (v) return v; } catch (_) {}
                    return token;
                };
                ts.__vaGetPatched = true;
            }
        } catch (_) {}

        // 2) Explicit data-callback on the widget container.
        try {
            const el = document.querySelector('[data-callback]');
            const name = el && el.getAttribute('data-callback');
            if (name && typeof window[name] === 'function') { window[name](token); invoked = true; }
        } catch (_) {}

        // 3) Common global callback names used by Turnstile integrations.
        const NAMES = [
            'onTurnstileSuccess', 'turnstileCallback', 'onCaptchaSuccess',
            'cfCallback', 'onloadTurnstileCallback', 'handleTurnstile',
            'setTurnstileToken', 'onVerify'
        ];
        for (const n of NAMES) {
            try { if (typeof window[n] === 'function') { window[n](token); invoked = true; } } catch (_) {}
        }

        // Report back to the ISOLATED world whether a real page callback ran, so
        // it can log honestly. The PASS decision is made ONLY from observable
        // page state (verification.js isPassed), never from this flag — a
        // callback running does not by itself prove the page accepted the token.
        try { window.postMessage({ __vaCfDelivered: 1, ok: invoked }, '*'); } catch (_) {}
    }

    window.addEventListener('message', function (ev) {
        if (ev.source !== window) return;
        const d = ev.data;
        if (!d || d.__vaCf !== 1) return;
        try { deliverToken(String(d.token || '')); } catch (_) {}
    }, false);

    // ---- fetch wrap (non-destructive: read a clone, R4) ----
    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
        window.fetch = function (...args) {
            // Compute the request URL/method up front so we can flag an upload as
            // IN FLIGHT before the response lands (a slow server may take 20-30s).
            let reqUrl = '', reqMethod = 'GET';
            try {
                reqUrl = (typeof args[0] === 'string') ? args[0] : (args[0] && args[0].url) || '';
                reqMethod = (args[1] && args[1].method) || (args[0] && args[0].method) || 'GET';
            } catch (_) { /* ignore */ }
            const isUp = isUploadReq(reqMethod, reqUrl);
            if (isUp) { inflightUploads++; post({ url: reqUrl, method: reqMethod, status: 0, phase: 'start' }); }

            const p = origFetch.apply(this, args);
            p.then((res) => {
                try {
                    const url = res.url || reqUrl;
                    const method = reqMethod;
                    // Opaque (no-cors) responses can't be read — skip body, still report status.
                    if (res.type === 'opaque') { report(url, method, res.status || 0, ''); return; }
                    res.clone().text().then((t) => report(url, method, res.status, t)).catch(() => report(url, method, res.status, ''));
                } catch (_) { /* ignore */ }
            }).catch(() => { /* network error — ignore */ })
              .finally(() => {
                  // Always clear the in-flight flag once the request settles
                  // (success, HTTP error, OR network failure) so upload() stops
                  // waiting and re-clicks when appropriate.
                  if (isUp) { inflightUploads = Math.max(0, inflightUploads - 1); post({ url: reqUrl, method: reqMethod, status: 0, phase: 'end' }); }
              });
            return p;
        };
    }

    // ---- XMLHttpRequest wrap (adds a listener, never clobbers onload) ----
    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url) {
        this.__va_method = method;
        this.__va_url = url;
        return origOpen.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
        const isUp = isUploadReq(this.__va_method, this.__va_url);
        if (isUp) { inflightUploads++; post({ url: this.__va_url || '', method: this.__va_method || 'POST', status: 0, phase: 'start' }); }
        this.addEventListener('loadend', () => {
            // Clear the in-flight flag first, unconditionally, so a body-read
            // error below can never leave a phantom "still uploading" state.
            if (isUp) { inflightUploads = Math.max(0, inflightUploads - 1); post({ url: this.__va_url || '', method: this.__va_method || 'POST', status: 0, phase: 'end' }); }
            try {
                let body = '';
                const rt = this.responseType;
                if (rt === '' || rt === 'text') body = this.responseText || '';
                else if (rt === 'json' && this.response) { try { body = JSON.stringify(this.response); } catch (_) {} }
                report(this.__va_url || '', this.__va_method || 'GET', this.status, body);
            } catch (_) { /* ignore */ }
        });
        return origSend.apply(this, arguments);
    };
})();
