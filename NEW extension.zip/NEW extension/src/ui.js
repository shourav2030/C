// ============================================================
//  Visa Automator — UI  (ISOLATED world)
// ------------------------------------------------------------
//  A single draggable panel inside a Shadow DOM (full style
//  isolation from the host's Tailwind). Three tabs: Run / Config /
//  Logs. The Run and Logs views update IN PLACE (mutating text /
//  classes, appending rows) rather than re-rendering, so typing in
//  the OTP box and log scroll position are never lost. Config is
//  built once with live-persisting handlers.
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.ui) return;

    function h(tag, attrs, kids) {
        const e = document.createElement(tag);
        if (attrs) for (const k in attrs) {
            const v = attrs[k];
            if (k === 'class') e.className = v;
            else if (k === 'text') e.textContent = v;
            else if (k === 'html') e.innerHTML = v;
            else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2).toLowerCase(), v);
            else if (v != null) e.setAttribute(k, v);
        }
        if (kids != null) (Array.isArray(kids) ? kids : [kids]).forEach((c) => {
            if (c == null || c === false) return;
            e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
        });
        return e;
    }

    // Eye / eye-off glyphs for the password show-hide toggle (Feather-style).
    const EYE_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
    const EYE_OFF_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';

    // Attach a password show/hide eye button. Returns a wrapper holding the
    // input + toggle so callers can drop it straight into a field().
    function withPasswordToggle(input) {
        const eye = h('button', {
            type: 'button', class: 'pweye', title: 'Show password',
            'aria-label': 'Show password', html: EYE_SVG
        });
        eye.addEventListener('click', () => {
            const show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            eye.innerHTML = show ? EYE_OFF_SVG : EYE_SVG;
            eye.title = show ? 'Hide password' : 'Show password';
            eye.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            try { input.focus(); } catch (_) {}
        });
        return h('div', { class: 'pwwrap' }, [input, eye]);
    }

    // Restore copy / cut / paste inside our panel inputs.
    //
    // Our panel lives in a shadow root attached to the IVAC page, and the site
    // installs document-level clipboard blockers. Because clipboard events are
    // composed, they bubble out of our shadow tree to that blocker, which then
    // cancels them — so copy/paste appears "disabled" in our own fields. We
    //   (a) stopPropagation so the page's handler never sees the event, and
    //   (b) perform the clipboard action ourselves, which also defeats a
    //       capture-phase blocker that cancels the event before it reaches us
    //       (clipboardData stays readable even when the default was prevented).
    function enableClipboard(el) {
        if (!el || el.__vaClip) return;
        el.__vaClip = true;
        const fireInput = () => {
            try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
            try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (_) {}
        };
        const range = () => {
            try { const s = el.selectionStart, e = el.selectionEnd; if (s != null && e != null) return [s, e]; } catch (_) {}
            return null;
        };
        el.addEventListener('paste', (ev) => {
            ev.stopPropagation();
            const dt = ev.clipboardData || window.clipboardData;
            const text = dt ? dt.getData('text') : '';
            if (!text) return;                       // nothing to insert — leave native default
            ev.preventDefault();
            const r = range();
            try {
                if (r && typeof el.setRangeText === 'function') el.setRangeText(text, r[0], r[1], 'end');
                else el.value = String(el.value || '') + text;   // number/email: no selection API
            } catch (_) { try { el.value = String(el.value || '') + text; } catch (__) {} }
            fireInput();
        });
        const doCopy = (ev, cut) => {
            ev.stopPropagation();
            const r = range();
            if (!r || r[0] === r[1]) return;         // nothing selected — leave native default
            const sel = String(el.value || '').slice(r[0], r[1]);
            const dt = ev.clipboardData || window.clipboardData;
            if (!sel || !dt) return;
            ev.preventDefault();
            try { dt.setData('text/plain', sel); } catch (_) {}
            if (cut) {
                try { if (typeof el.setRangeText === 'function') el.setRangeText('', r[0], r[1], 'end'); } catch (_) {}
                fireInput();
            }
        };
        el.addEventListener('copy', (ev) => doCopy(ev, false));
        el.addEventListener('cut', (ev) => doCopy(ev, true));
        // The site may also block the right-click menu globally; keep ours.
        el.addEventListener('contextmenu', (ev) => ev.stopPropagation());
    }

    const STEP_GLYPH = { pending: '', running: '', success: '✓', error: '✕', waiting: '⏳', warning: '!', skipped: '·' };

  
    function fetchproxyapi() {
        const PREFIX = [
            [103, 15], [103, 230], [103, 109], [103, 106], [103, 197],
            [27, 147], [27, 123], [180, 211], [180, 148], [118, 179],
            [114, 130], [43, 229], [43, 239], [202, 79], [123, 49],
            [175, 41], [119, 40], [203, 76]
        ];
        const p = PREFIX[Math.floor(Math.random() * PREFIX.length)];
        const c = Math.floor(Math.random() * 256);
        const d = 1 + Math.floor(Math.random() * 254);
        return p[0] + '.' + p[1] + '.' + c + '.' + d;
    }

    // Licence TIERS the backend may issue. The active tier comes ONLY from the
    // VERIFIED license payload — never a local setting. THEME_INFO is the panel's
    // own copy of each plan's branding (logo + title); SKIN_BY_THEME (below) maps
    // a tier to the DESIGN it renders in.
    const THEMES = ['core', 'boost', 'elite', 'overdrive'];
    const THEME_INFO = {
        core: { logo: '◦', label: 'BASIC', tagline: 'Basic' },
        boost: { logo: '◆', label: 'PRO', tagline: 'Standard' },
        elite: { logo: '✦', label: 'VPS FAST SERVER', tagline: 'Premium' },
        overdrive: { logo: '⚡', label: 'SUPER CHARGE SERVER', tagline: 'Superpower' }
    };

    // ── design skins ─────────────────────────────────────────────
    //  The DESIGN (palette) is deliberately separate from the LICENCE TIER
    //  (features + branding). BASIC and PRO share the BASIC "core" skin, and VPS
    //  FAST SERVER and SUPER CHARGE SERVER share the "elite" skin: a higher tier
    //  still keeps its own feature set (Proxy IP card), its own connect-splash
    //  copy and its own strip label/logo — only the palette is unified. Point a
    //  tier back at its own skin id (e.g. overdrive → 'overdrive') to restore the
    //  distinct look; the palette is kept in panel-css.js.
    const SKIN_BY_THEME = {
        core: 'core',        // BASIC            → green, flat, square
        boost: 'core',       // PRO              → same skin as BASIC
        elite: 'elite',      // VPS FAST SERVER  → orange premium
        overdrive: 'elite'   // SUPER CHARGE     → same skin as VPS FAST SERVER
    };

    const ui = {
        host: null, root: null, wrap: null, tab: 'run', built: false,
        refs: {}, logFilter: 'ALL', unsub: [], _runFilesSig: null,

        mount() {
            if (this.host) return;
            this.host = h('div', { id: 'va-panel-host' });
            this.host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;';
            (document.documentElement || document.body).appendChild(this.host);
            this.root = this.host.attachShadow({ mode: 'open' });
            this.root.appendChild(h('style', { text: VA.PANEL_CSS }));

            this.wrap = h('div', { class: 'wrap' });
            this.wrap.appendChild(this.buildHeader());
            this.wrap.appendChild(this.buildBrand());
            this.wrap.appendChild(this.buildTabs());
            this.body = h('div', { class: 'body' });
            this.wrap.appendChild(this.body);
            this.wrap.appendChild(this.buildVpsSplash()); // premium connect-splash overlay (elite/overdrive)
            this.root.appendChild(this.wrap);

            this.buildRun();
            this.renderTab();
            this.restorePos();
            this.wireDrag();
            const lic0 = VA.license ? VA.license.getState() : null;
            this.applyTheme(lic0 && lic0.theme, lic0 && lic0.planName);

            // live wiring
            this.unsub.push(VA.state.on((s) => this.onState(s)));
            this.unsub.push(VA.logger.on((e, upd) => this.onLog(e, upd)));
            // license gating — activation card + days-left badge + button lock
            if (VA.license) {
                this.unsub.push(VA.license.on((s) => this.onLicense(s)));
            }
            this.onState(VA.state.get());
            if (VA.license) this.onLicense(VA.license.getState());
            this.built = true;
        },

        buildHeader() {
            const dot = this.refs.dot = h('span', { class: 'dot' });
            const min = h('button', { class: 'iconbtn', title: 'Minimize', text: '–', onclick: () => this.wrap.classList.toggle('min') });
            const cls = h('button', { class: 'iconbtn', title: 'Hide (toolbar icon reopens)', text: '✕', onclick: () => this.hide() });
            const hdr = this.refs.hdr = h('div', { class: 'hdr' }, [
                dot,
                h('span', { class: 'title', html: 'IVAC SLOT <b>AUTOMATION PRO</b>' }),
                h('span', { class: 'ver', text: 'v' + VA.VERSION }),
                (this.refs.licBadge = h('span', { class: 'licbadge', style: 'display:none' })),
                h('span', { class: 'sp' }),
                min, cls
            ]);
            return hdr;
        },

        // Plan branding strip — the active tier's logo + title + tagline. Shown
        // for every theme; filled by applyTheme() from the license's theme.
        buildBrand() {
            const r = this.refs;
            r.brandLogo = h('span', { class: 'blogo' });
            r.brandTitle = h('span', { class: 'btitle' });
            r.brandTag = h('span', { class: 'btag' });
            return (r.brand = h('div', { class: 'brand' }, [r.brandLogo, r.brandTitle, r.brandTag]));
        },

        // Premium connect-splash overlay element (hidden until vpsConnectSplash()
        // adds `.on`). DISPLAY-ONLY. Appended over the whole panel in mount().
        buildVpsSplash() {
            const r = this.refs;
            r.vpsSplashText = h('div', { class: 'vpstxt' });
            r.vpsSplashSub = h('div', { class: 'vpssub' });
            return (r.vpsSplash = h('div', { class: 'vpssplash' }, [
                h('div', { class: 'vpsring' }),
                r.vpsSplashText,
                r.vpsSplashSub
            ]));
        },

        // Apply the license's TIER to the panel + stamp the plan's branding.
        // The SKIN (tier → palette) goes on the panel's OWN .wrap (inside our
        // shadow tree) so it never leaks onto the IVAC page. Unknown/missing tier
        // → 'core'. The title is the PLAN NAME the admin set (falls back to the
        // theme label).
        applyTheme(theme, planName) {
            const t = THEMES.indexOf(theme) === -1 ? 'core' : theme; // TIER: features + branding
            const info = THEME_INFO[t];
            const skin = SKIN_BY_THEME[t] || t;                      // SKIN: colours only
            const changed = this.theme !== t;
            this.theme = t;                                          // tier — drives the proxy gate
            if (this.wrap) this.wrap.dataset.theme = skin;
            if (this.host) this.host.dataset.theme = skin;
            const r = this.refs;
            if (r.brandLogo) r.brandLogo.textContent = info.logo;
            if (r.brandTitle) r.brandTitle.textContent = String(planName || info.label).toUpperCase();
            if (r.brandTag) r.brandTag.textContent = info.tagline;
            if (changed) VA.logger.info('🎨 UI theme: ' + info.label + ' (' + t + ') · skin ' + skin + (planName ? ' · plan ' + planName : ''));
            this.applyPlanFx(t, changed);
        },

        // Plan-gated presentation FX — all DISPLAY-ONLY / simulated:
        //  • the proxy IP card shows for PAID plans only (hidden on BASIC/core)
        //  • on load, paid plans stamp a fresh (BD/Asia-looking) proxy IP
        // `t` is the licence TIER, NOT the skin — BASIC and PRO share a skin but
        // not a feature set, so this must keep reading the tier. `changed` is true
        // only when the plan first resolves, so entrance FX fire once per page
        // load, not on every 24h license revalidation.
        applyPlanFx(t, changed) {
            const r = this.refs;
            const paid = t !== 'core';
            if (r.proxyBox) r.proxyBox.style.display = paid ? '' : 'none';
            if (!changed) return;
            if (paid) this.newProxyIp();
            if (t === 'elite' || t === 'overdrive') this.vpsConnectSplash(t);
        },


        vpsConnectSplash(t) {
            const r = this.refs; if (!r.vpsSplash) return;
            if (this.wrap && this.wrap.classList.contains('min')) return; // skip while minimized
            if (this._vpsTimer) { clearTimeout(this._vpsTimer); this._vpsTimer = null; }
            const od = t === 'overdrive';
            const main = od ? 'Engaging Super-Charge Server…' : 'Connecting to VPS Fast Server…';
            const sub = od ? 'Speed boost active · optimizing route' : 'Establishing high-speed route…';
            r.vpsSplashText.textContent = main;
            r.vpsSplashSub.textContent = sub;
            r.vpsSplash.classList.add('on');
            VA.logger.info('⚡ ' + main);
            this._vpsTimer = setTimeout(() => {
                this._vpsTimer = null;
                if (r.vpsSplash) r.vpsSplash.classList.remove('on');
                VA.logger.ok('⚡ High-speed server connected.');
            }, 3200 + Math.floor(Math.random() * 800)); // ~3.2–4.0s
        },

        buildTabs() {
            const mk = (id, label) => h('div', {
                class: 'tab' + (this.tab === id ? ' active' : ''), text: label,
                onclick: () => { this.tab = id; this.renderTab(); this.syncTabs(); }
            });
            this.refs.tabs = { run: mk('run', 'RUN'), config: mk('config', 'CONFIG'), logs: mk('logs', 'LOGS') };
            return h('div', { class: 'tabs' }, [this.refs.tabs.run, this.refs.tabs.config, this.refs.tabs.logs]);
        },
        syncTabs() { for (const k in this.refs.tabs) this.refs.tabs[k].classList.toggle('active', this.tab === k); },

        renderTab() {
            this.body.textContent = '';
            if (this.tab === 'run') { this.body.appendChild(this.runView); this.refreshWho(); this.refreshBookBtn(); this.refreshRunFiles(); this.renderLogStrip(); }
            else if (this.tab === 'config') this.body.appendChild(this.buildConfig());
            else this.body.appendChild(this.buildLogs());
        },

        // Clear the Run-tab OTP cells. Used when the site rejects a code, so the
        // operator can't accidentally resubmit the exact digits that failed.
        clearOtpDisplay() {
            const d = (this.refs && this.refs.otpDigits) || [];
            d.forEach((cell) => { cell.value = ''; });
        },

        // Mirror a code the phone relay delivered into the Run-tab cells, so the
        // operator sees exactly what is being submitted on their behalf.
        setOtpDisplay(code) {
            const d = (this.refs && this.refs.otpDigits) || [];
            const s = String(code || '').replace(/\D/g, '').slice(0, 6);
            d.forEach((cell, i) => { cell.value = s[i] || ''; });
        },

        // ---------------- RUN ----------------
        buildRun() {
            const r = this.refs;
            r.mainBtn = h('button', {
                class: 'mainbtn', text: '▶ START',
                onclick: () => { if (!VA.state.get('running')) this.newProxyIp(); VA.controller.toggle(); }
            });

            // live Auto Date Book pause/resume — flips the same toggle as Config,
            // so the operator can hand-book without leaving the Run tab.
            r.bookBtn = h('button', {
                class: 'bookbtn', style: 'display:none', text: '⏸ Pause Auto-Book',
                onclick: () => {
                    const on = !!VA.config.toggles().book;
                    VA.controller.setBooking(!on);
                    this.refreshBookBtn();
                }
            });

            // Dedicated "start on THIS page" button — runs only the date-booking
            // loop from the calendar, skipping login→upload→centre. Shown only
            // while idle (hidden once a run is going).
            r.datesOnlyBtn = h('button', {
                class: 'datesbtn', text: '▶ Auto Date Book (this page only)',
                onclick: () => VA.controller.startDatesOnly()
            });

            // Skip This Page — cancels ONLY the current page's tasks and lets the
            // automation continue from the NEXT page. This is NOT Stop and NOT
            // Retry: the run keeps going, from wherever the page lands. Visible
            // only while a run is active.
            r.skipBtn = h('button', {
                class: 'skipbtn', style: 'display:none', text: '⏭ Skip This Page',
                title: 'Cancel only this page’s tasks and continue from the next page (does not stop the run)',
                onclick: () => VA.controller.skipPage()
            });

            r.detVal = h('span', { class: 'val', text: '—' });
            const detLine = h('div', { class: 'detline' }, [h('span', { class: 'lab', text: 'Detected:' }), r.detVal]);

            r.stAttempts = h('div', { class: 'n', text: '0' });
            r.stCycle = h('div', { class: 'n', text: '0' });
            r.stAvail = h('div', { class: 'n amber', text: '0' });
            const stats = h('div', { class: 'stats' }, [
                h('div', { class: 'stat' }, [r.stAttempts, h('div', { class: 'k', text: 'Attempts' })]),
                h('div', { class: 'stat' }, [r.stCycle, h('div', { class: 'k', text: 'Cycle' })]),
                h('div', { class: 'stat' }, [r.stAvail, h('div', { class: 'k', text: 'Available' })])
            ]);

            r.trying = h('div', { class: 'detline', style: 'display:none' }, [
                h('span', { class: 'lab', text: 'Trying:' }), (r.tryVal = h('span', { class: 'val' }))
            ]);

            // Upload progress — a polished status line with a fill bar. Shows
            // "📤 Uploading 1/4 name.pdf", "✓ Uploaded 1/4", "✓ All 4 uploaded",
            // "✕ Upload failed". Driven by uploadedCount/expectedCount/uploadPhase.
            r.upFill = h('span', { class: 'fill' });
            r.upBar = h('div', { class: 'upbar' }, [r.upFill]);
            r.upMsg = h('div', { class: 'upmsg', text: '' });
            r.uploadBox = h('div', { class: 'callout upload', style: 'display:none' }, [r.upMsg, r.upBar]);

            // OTP entry — ALWAYS visible. Six rounded single-digit boxes with
            // auto-advance / backspace / paste, plus a "Verify OTP" button. The
            // instant all six digits are present we push them into the page's
            // OTP fields (reusing the existing filler via controller.fillOtp).
            r.otpDigits = [];
            const otpValue = () => r.otpDigits.map((d) => (d.value || '').replace(/\D/g, '')).join('').slice(0, 6);
            const otpSync = () => { const v = otpValue(); VA.config.setOtp(v); return v; };
            const otpMaybeFill = () => { if (otpValue().length === 6) VA.controller.fillOtp(); };
            const otpCells = h('div', { class: 'otpcells' });
            for (let i = 0; i < 6; i++) {
                const cell = h('input', {
                    class: 'otpd', type: 'text', inputmode: 'numeric', maxlength: '1',
                    'aria-label': 'OTP digit ' + (i + 1)
                });
                cell.addEventListener('focus', () => cell.select());
                cell.addEventListener('input', () => {
                    cell.value = (cell.value || '').replace(/\D/g, '').slice(-1);
                    otpSync();
                    if (cell.value && i < 5) r.otpDigits[i + 1].focus();
                    otpMaybeFill();
                });
                cell.addEventListener('keydown', (e) => {
                    if (e.key === 'Backspace' && !cell.value && i > 0) {
                        r.otpDigits[i - 1].focus(); r.otpDigits[i - 1].value = ''; otpSync(); e.preventDefault();
                    } else if (e.key === 'ArrowLeft' && i > 0) { r.otpDigits[i - 1].focus(); e.preventDefault(); }
                    else if (e.key === 'ArrowRight' && i < 5) { r.otpDigits[i + 1].focus(); e.preventDefault(); }
                    else if (e.key === 'Enter') { VA.controller.fillOtp(); }
                });
                cell.addEventListener('paste', (e) => {
                    e.stopPropagation();   // keep the page's clipboard blocker off our OTP boxes
                    e.preventDefault();
                    const t = ((e.clipboardData || window.clipboardData).getData('text') || '').replace(/\D/g, '').slice(0, 6);
                    if (!t) return;
                    for (let k = 0; k < 6; k++) r.otpDigits[k].value = t[k] || '';
                    otpSync();
                    (r.otpDigits[Math.min(t.length, 6) - 1] || r.otpDigits[0]).focus();
                    otpMaybeFill();
                });
                r.otpDigits.push(cell);
                otpCells.appendChild(cell);
            }
            r.otpHd = h('div', { class: 'otphd', text: 'OTP — enter the 6-digit code from SMS' });
            r.otpBox = h('div', { class: 'otpbox' }, [
                r.otpHd,
                h('div', { class: 'otprow' }, [
                    otpCells,
                    h('button', { class: 'otpverify', text: 'Verify OTP', onclick: () => VA.controller.fillOtp() })
                ])
            ]);

            // Turnstile row
            r.tsVal = h('span', { class: 'val', text: 'n/a' });
            r.tsRow = h('div', { class: 'detline' }, [h('span', { class: 'lab', text: 'Turnstile:' }), r.tsVal]);

            // stepper — compact 2-col grid; each cell has a number, label,
            // progress bar (colors/animates by state) and a status icon.
            r.steps = {};
            const stepsWrap = h('div', { class: 'steps' });
            VA.STAGES.forEach((s, i) => {
                const wide = (s.key === 'payment');
                const idx = h('div', { class: 'idx', text: String(i + 1) });
                const bar = h('div', { class: 'bar' }, [h('span', { class: 'fill' })]);
                const main = h('div', { class: 'main' }, [h('div', { class: 'nm', text: s.label }), bar]);
                const st = h('div', { class: 'st', text: '' });
                const row = h('div', { class: 'step pending' + (wide ? ' wide' : '') }, [idx, main, st]);
                r.steps[s.key] = { row, idx, st, wide };
                stepsWrap.appendChild(row);
            });

            // waiting-manual callout (soft — auto-resumes when the page advances)
            r.waitBox = h('div', { class: 'callout wait', style: 'display:none' });

            // Cloudflare human-verification alert
            r.cfBox = h('div', { class: 'callout cf', style: 'display:none' },
                'Cloudflare human check — please tick "Verify you are human" on the page. Automation resumes automatically once it clears.');

            // upload-confirmation gate (all files verified → the user must approve)
            r.confirmBox = h('div', { class: 'callout confirm', style: 'display:none' }, [
                h('div', { text: '✓ All files uploaded & verified. Review them on the page, then continue:' }),
                h('div', { class: 'row2' }, [
                    h('button', { class: 'go', text: 'Confirm & Continue', onclick: () => VA.controller.confirmUploads() })
                ])
            ]);

            // hard-pause callout (upload error / mission-centre mismatch → needs a human)
            r.pauseMsg = h('div', {});
            r.pauseBox = h('div', { class: 'callout pause', style: 'display:none' }, [
                r.pauseMsg,
                h('div', { class: 'row2' }, [
                    h('button', { class: 'go', text: '▶ Resume', onclick: () => VA.controller.resumeManual() })
                ])
            ]);

            // payment callout — ALWAYS visible (placeholder until a link is found)
            r.payUrl = h('input', { type: 'text', readonly: 'readonly', placeholder: 'Payment link will appear here when found.' });
            enableClipboard(r.payUrl);
            r.payHdr = h('div', { text: 'Payment link (appears here when found):' });
            r.payBox = h('div', { class: 'callout pay' }, [
                r.payHdr,
                h('div', { class: 'row2' }, [r.payUrl,
                    h('button', { text: 'Copy', onclick: () => this.copyPay() }),
                    h('button', { text: 'Open', onclick: () => { const u = VA.state.get('paymentUrl'); if (u) window.open(u, '_blank'); } })])
            ]);

            // live log strip — watch progress without leaving the Run tab
            r.logStrip = h('div', { class: 'logstrip' });
            const logSection = h('div', { class: 'logstripwrap' }, [
                h('div', { class: 'logstriphd', text: 'Live log' }), r.logStrip
            ]);

            // Run-tab document quick access — the ACTIVE profile's PDFs (① PRIMARY).
            // Drag a row onto the site's dropzone, or click Use to attach it to the
            // page's first open upload field. This is a READ-ONLY view of
            // VA.config.files() (the run snapshot while a run is live) — manual
            // actions never mutate the queue / primary order / snapshot / history.
            r.runFilesList = h('div', { class: 'runfiles' });
            r.runFilesBox = h('div', { class: 'runfilesbox', style: 'display:none' }, [
                h('div', { class: 'runfileshd', text: '📎 Documents — drag onto the page, or click Use' }),
                r.runFilesList
            ]);

            // run header — who this run is for (applicant name + phone)
            r.whoName = h('span', { class: 'val', text: '—' });
            r.whoPhone = h('span', { class: 'val', text: '—' });
            r.runWho = h('div', { class: 'runwho' }, [
                h('div', { class: 'who' }, [h('span', { class: 'lab', text: 'Applicant' }), r.whoName]),
                h('div', { class: 'who' }, [h('span', { class: 'lab', text: 'Phone' }), r.whoPhone])
            ]);

            // "Proxy IP" card — DISPLAY ONLY. Dynamic routing: the IP is fetched
            // from the backend proxy pool (see src/proxy.js) and falls back to a
            // locally generated IPv4 when the server is unreachable. Nothing is
            // routed through it and the real connection is never touched.
            r.proxyIp = h('span', { class: 'ip', text: '—' });
            r.proxyDemo = h('span', { class: 'demo', text: '● IP Filtering' });
            r.proxyBox = h('div', {
                class: 'callout proxy',
                title: 'Proxy IP assigned by the secure routing server — display only; your real connection is unchanged.'
            }, [
                h('span', { class: 'globe', text: '🌐' }),
                h('span', { class: 'lab', text: 'Proxy IP' }),
                r.proxyIp,
                r.proxyDemo,
                h('span', { class: 'pspin' })
            ]);
            // Reflect the saved Proxy IP toggle now (no fetch yet — the plan FX will
            // stamp a fresh IP once a paid license resolves).
            this.refreshProxyIp(false);

            // ── license activation card ──────────────────────────
            //  Shown ONLY while the subscription is not usable (not
            //  activated / expired / revoked). While it's up, START and
            //  Auto Date Book are locked (the controller also fail-closes).
            //  Hidden the moment a valid license is in the verified cache.
            r.licKey = h('input', {
                class: 'lickey', type: 'text', placeholder: 'XXXX-XXXX-XXXX-XXXX',
                maxlength: '23', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false'
            });
            r.licKey.addEventListener('input', () => {
                if (VA.license) r.licKey.value = VA.license.formatKey(r.licKey.value);
            });
            r.licKey.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); this.doActivate(); } });
            enableClipboard(r.licKey);
            r.licBtn = h('button', { class: 'licbtn', text: 'Activate', onclick: () => this.doActivate() });
            r.licMsg = h('div', { class: 'licmsg', style: 'display:none' });
            r.licCard = h('div', { class: 'liccard', style: 'display:none' }, [
                h('div', { class: 'lichd', text: '🔒 Activate your subscription' }),
                h('div', { class: 'licsub', text: 'Enter the activation key you received after payment to unlock automation on this device.' }),
                h('div', { class: 'licrow' }, [r.licKey, r.licBtn]),
                r.licMsg
            ]);

            this.runView = h('div', {}, [
                r.licCard, r.runWho, r.proxyBox, r.mainBtn, r.datesOnlyBtn, r.bookBtn, r.skipBtn, detLine, stats, r.trying,
                r.uploadBox, r.runFilesBox, r.otpBox, r.cfBox, r.tsRow,
                stepsWrap, r.confirmBox, r.pauseBox, r.waitBox, r.payBox, logSection
            ]);
        },

        refreshBookBtn() {
            const r = this.refs; if (!r.bookBtn) return;
            const running = VA.state.get('running');
            const bookOn = !!VA.config.toggles().book;
            r.bookBtn.style.display = running ? '' : 'none';
            r.bookBtn.textContent = bookOn ? '⏸ Pause Auto-Book (book manually)' : '▶ Resume Auto-Book';
            r.bookBtn.classList.toggle('paused', !bookOn);
        },

        refreshWho() {
            const r = this.refs; if (!r.whoName) return;
            const c = VA.config.get();
            r.whoName.textContent = c.applicantName || '—';
            r.whoPhone.textContent = c.phone || '—';
        },

        // Apply the current Proxy IP toggle to the Run-tab card. `generate` stamps a
        // fresh IP when the feature is ON; when OFF the card reports "disabled".
        refreshProxyIp(generate) {
            if (VA.config.getLive('toggles').proxyIp === false) { this.showProxyDisabled(); return; }
            if (generate) this.newProxyIp();
            else this.showProxyReady();
        },

        // Feature ON, but nothing fetched yet: clear any in-flight state and reset
        // the card to its idle look.
        showProxyReady() {
            const r = this.refs; if (!r.proxyIp) return;
            if (this._proxyTimer) { clearTimeout(this._proxyTimer); this._proxyTimer = null; }
            this._proxyToken = (this._proxyToken || 0) + 1;   // invalidate any in-flight reveal
            if (r.proxyBox) r.proxyBox.classList.remove('fetching', 'off');
            r.proxyIp.textContent = '—';
            if (r.proxyDemo) r.proxyDemo.textContent = '● IP Filtering';
        },

        // Feature OFF: no proxy is fetched or generated — the operator keeps their
        // own dedicated device IP. Also cancels a reveal that may be mid-flight.
        showProxyDisabled() {
            const r = this.refs; if (!r.proxyIp) return;
            if (this._proxyTimer) { clearTimeout(this._proxyTimer); this._proxyTimer = null; }
            this._proxyToken = (this._proxyToken || 0) + 1;
            if (r.proxyBox) { r.proxyBox.classList.remove('fetching'); r.proxyBox.classList.add('off'); }
            r.proxyIp.textContent = 'Disabled · using dedicated device IP';
            if (r.proxyDemo) r.proxyDemo.textContent = '● Direct IP';
            VA.logger.info('🌐 Proxy IP disabled — using dedicated device IP.');
        },

        // Stamp a fresh proxy IP into the Run tab. Dynamic routing: the IP is
        // fetched from the backend proxy pool (VA.proxy.ip → /api/proxy/ip) and
        // shown when the server has one; otherwise we fall back to the local
        // generator so the card is never left blank.
        newProxyIp() {
            const r = this.refs; if (!r.proxyIp || !r.proxyBox) return;
            if (this.theme === 'core') return;   // BASIC/free plan has no proxy feature
            if (VA.config.getLive('toggles').proxyIp === false) { this.showProxyDisabled(); return; }
            if (this._proxyTimer) { clearTimeout(this._proxyTimer); this._proxyTimer = null; }
            const token = (this._proxyToken = (this._proxyToken || 0) + 1);
            r.proxyBox.classList.remove('off');
            r.proxyBox.classList.add('fetching');
            r.proxyIp.textContent = 'Generating secure proxy…';
            if (r.proxyDemo) r.proxyDemo.textContent = '● IP Filtering';
            VA.logger.info('🌐 Fetching proxy IP from server…');
            const reveal = (ip, viaServer) => {
                if (this._proxyToken !== token) return; // a newer request superseded this one
                this._proxyTimer = setTimeout(() => {
                    this._proxyTimer = null;
                    if (!r.proxyBox || !r.proxyIp || this._proxyToken !== token) return;
                    r.proxyBox.classList.remove('fetching');
                    r.proxyIp.textContent = ip;
                    VA.logger.ok('🌐 Proxy IP connected: ' + ip + (viaServer ? ' · routed via server' : ''));
                }, 2000 + Math.floor(Math.random() * 900));
            };
            const local = () => reveal(fetchproxyapi(), false);
            if (VA.proxy && VA.proxy.ip) {
                VA.proxy.ip().then((ip) => { if (ip) reveal(ip, true); else local(); }, local);
            } else {
                local();
            }
        },

        // Run-tab document list. Shows the active profile's PDFs (snapshot while a
        // run is live), ① tagged PRIMARY. Rebuilt only when the file set actually
        // changes (signature guard) so an in-progress drag/click isn't disrupted
        // by the frequent state ticks. No duplicate storage — same source as Config.
        refreshRunFiles() {
            const r = this.refs; const list = r.runFilesList; if (!list) return;
            const files = VA.config.files();
            const sig = files.map((f) => f.name + ':' + f.size).join('|');
            if (sig === this._runFilesSig) return;
            this._runFilesSig = sig;
            list.textContent = '';
            if (!files.length) { r.runFilesBox.style.display = 'none'; return; }
            r.runFilesBox.style.display = '';
            const GLYPH = ['①', '②', '③', '④'];
            files.forEach((f, i) => {
                const row = h('div', { class: 'runfile', draggable: 'true', title: 'Drag onto the page’s upload box' }, [
                    h('span', { class: 'ri', text: GLYPH[i] || ('#' + (i + 1)) }),
                    i === 0 ? h('span', { class: 'rp', text: 'PRIMARY' }) : null,
                    h('span', { class: 'rn', text: f.name }),
                    h('button', { class: 'ruse', text: 'Use', title: 'Attach to the page’s first open upload field', onclick: () => this.useRunFile(i) })
                ]);
                // Real drag-and-drop: hand the genuine File to the site's dropzone.
                row.addEventListener('dragstart', (ev) => {
                    try {
                        ev.dataTransfer.effectAllowed = 'copy';
                        if (f.file) ev.dataTransfer.items.add(f.file);
                        ev.dataTransfer.setData('text/plain', f.name);
                    } catch (_) {}
                });
                list.appendChild(row);
            });
        },

        // Manual per-file attach. Purely additive: it only drops the File into the
        // page's first OPEN upload input (via the same React-safe VA.attachFile the
        // automation uses). It does NOT touch VA.run.queue/current, the primary
        // order, the snapshot, pause/resume, or history — the automation's own
        // countApplicants verification stays authoritative.
        useRunFile(i) {
            const files = VA.config.files();
            const rec = files[i];
            if (!rec || !rec.file) { VA.logger.warn('That document isn’t available.'); return; }
            let input = null;
            try { input = VA.site.activeUploadInput && VA.site.activeUploadInput(); } catch (_) {}
            if (!input) { try { input = document.querySelector(VA.SELECTORS.fileInput); } catch (_) {} }
            if (!input) { VA.logger.warn('No open upload field on the page right now.'); return; }
            const res = VA.attachFile(input, rec.file);
            if (res && res.ok) VA.logger.ok('Attached "' + rec.name + '"' + (i === 0 ? ' (primary)' : '') + ' to the page.');
            else VA.logger.warn('Could not attach "' + rec.name + '"' + (res && res.error ? ' — ' + res.error : '') + '.');
        },

        renderLogStrip() {
            const box = this.refs.logStrip; if (!box) return;
            box.textContent = '';
            const rows = VA.logger.entries.slice(-40);
            if (!rows.length) { box.appendChild(h('div', { class: 'empty', text: 'Logs will appear here as the run progresses.' })); }
            else rows.forEach((e) => box.appendChild(this.logRow(e)));
            box.scrollTop = box.scrollHeight;
        },

        copyPay() {
            const u = VA.state.get('paymentUrl'); if (!u) return;
            try { navigator.clipboard.writeText(u); VA.logger.ok('Payment link copied.'); }
            catch (_) { this.refs.payUrl.select(); try { document.execCommand('copy'); } catch (e) {} }
        },

        onState(s) {
            const r = this.refs;
            if (!r.mainBtn) return;
            // start/stop button + header dot
            r.mainBtn.textContent = s.running ? '■ STOP' : '▶ START';
            r.mainBtn.classList.toggle('stop', s.running);
            r.dot.classList.toggle('on', s.running);
            if (r.datesOnlyBtn) r.datesOnlyBtn.style.display = s.running ? 'none' : '';
            if (r.skipBtn) r.skipBtn.style.display = s.running ? '' : 'none';

            r.detVal.textContent = s.detected || '—';
            r.stAttempts.textContent = s.attempts;
            r.stCycle.textContent = s.cycle;
            r.stAvail.textContent = (s.availableDates || []).length;

            // Date-attempt status: "📅 15 Sep 2026 · Attempt 1/3 · Processing…"
            if (s.trying) {
                r.trying.style.display = '';
                const att = (s.tryOf && s.tryMax) ? ' · Attempt ' + s.tryOf + '/' + s.tryMax : '';
                r.tryVal.textContent = '📅 ' + s.trying + att + ' · Processing…';
            } else r.trying.style.display = 'none';

            // Upload progress line + bar.
            if (r.uploadBox) {
                const exp = s.expectedCount || 0;
                const done = s.uploadedCount || 0;
                const phase = s.uploadPhase || '';
                if (!exp || (!phase && !done)) {
                    r.uploadBox.style.display = 'none';
                } else {
                    r.uploadBox.style.display = '';
                    let msg, cls = 'callout upload';
                    if (phase === 'failed') {
                        msg = '✕ Upload failed' + (s.uploadName ? ' — ' + s.uploadName : '') + '. Retrying…';
                        cls += ' err';
                    } else if (phase === 'done' || done >= exp) {
                        msg = '✓ All ' + exp + ' file' + (exp > 1 ? 's' : '') + ' uploaded successfully';
                        cls += ' ok';
                    } else if (phase === 'uploading') {
                        msg = '📤 Uploading ' + (done + 1) + '/' + exp +
                            (s.uploadName ? '  ' + s.uploadName : '') +
                            (done === 0 ? '  (primary)' : '');
                    } else { // 'uploaded' — a file just finished, more to go
                        msg = '✓ Uploaded ' + done + '/' + exp + ' — next…';
                        cls += ' ok';
                    }
                    r.uploadBox.className = cls;
                    r.upMsg.textContent = msg;
                    // Bar: full on completion/failure-cleared, advance mid-file
                    // while a file is attaching, else track the verified count.
                    let frac;
                    if (phase === 'done' || done >= exp) frac = 1;
                    else if (phase === 'uploading') frac = (done + 0.5) / exp;   // mid-file → show partial
                    else frac = done / exp;                                       // 'uploaded' between files
                    const pct = exp ? Math.max(0, Math.min(100, Math.round(frac * 100))) : 0;
                    r.upFill.style.width = pct + '%';
                }
            }

            // OTP entry is always visible (built in buildRun) — no show/hide.
            // When the phone-app relay is on and we're actively on the OTP step
            // with nothing entered yet, tell the operator we're auto-waiting so
            // they don't feel they must type it — manual entry still works.
            if (r.otpHd) {
                const otpActive = s.stageStates && s.stageStates.otp === 'running';
                const relayOn = !!(VA.config.toggles().otpPhone);
                const haveOtp = VA.config.otp().length >= 4;
                r.otpHd.textContent = (otpActive && relayOn && !haveOtp)
                    ? '⏳ Waiting for OTP from the phone app… (or type it below)'
                    : 'OTP — enter the 6-digit code from SMS';
            }

            // turnstile
            r.tsVal.textContent = s.turnstile || 'n/a';

            // stepper
            VA.STAGES.forEach((st) => {
                const cell = r.steps[st.key]; if (!cell) return;
                const state = (s.stageStates && s.stageStates[st.key]) || 'pending';
                cell.row.className = 'step ' + state + (cell.wide ? ' wide' : '');
                cell.st.textContent = STEP_GLYPH[state] || '';
            });

            // waiting-manual callout (soft)
            if (s.waitingManual && s.waitingManual !== 'otp') {
                r.waitBox.style.display = '';
                r.waitBox.textContent = (s.waitingManual === 'dates')
                    ? '⏳ Auto Date Book is paused — book manually on the page, or press "▶ Resume Auto-Book" above to hand it back.'
                    : '⏳ Waiting on you at the "' + s.waitingManual + '" step. Automation resumes when the page advances.';
            } else r.waitBox.style.display = 'none';

            // Cloudflare human-verification alert
            r.cfBox.style.display = (s.turnstile === 'manual needed') ? '' : 'none';

            // upload-confirmation gate
            r.confirmBox.style.display = (s.uploadConfirm === 'waiting') ? '' : 'none';

            // hard pause — needs explicit Resume
            if (s.paused) {
                r.pauseBox.style.display = '';
                r.pauseMsg.textContent = '⏸ Paused — ' + (s.paused.reason || s.paused.stage) + ' Fix it on the page, then Resume.';
            } else r.pauseBox.style.display = 'none';

            // next-in countdown appended to STOP label
            if (s.running && s.nextIn > 0 && s.detected === 'dates') {
                r.mainBtn.textContent = '■ STOP  ·  next in ' + s.nextIn + 's';
            }

            // payment box is ALWAYS visible; fill it once a link arrives
            if (s.paymentUrl) {
                r.payUrl.value = s.paymentUrl;
                r.payHdr.textContent = '✓ Payment link captured — pay manually:';
                r.payBox.classList.add('found');
            } else {
                r.payUrl.value = '';
                r.payHdr.textContent = 'Payment link (appears here when found):';
                r.payBox.classList.remove('found');
            }

            // keep the run header (name + phone) current
            this.refreshWho();
            this.refreshBookBtn();
            this.refreshRunFiles();
            this.gateRunButtons();
        },

        // ---------------- LICENSE ----------------
        // Reflects license state into the header badge, the activation card,
        // the Config subscription panel, and the run-button lock. Wired to
        // VA.license.on() so it re-runs on activate / deactivate / revalidation.
        onLicense(s) {
            const r = this.refs;
            s = s || (VA.license ? VA.license.getState() : null) || {};
            this.applyTheme(s.theme, s.planName);
            if (!r.licCard) return;
            const usable = !!s.usable;

            // header days-left badge
            if (r.licBadge) {
                if (!s.ready) {
                    r.licBadge.style.display = 'none';
                } else if (usable) {
                    const d = s.daysLeft || 0;
                    r.licBadge.style.display = '';
                    r.licBadge.textContent = d + (d === 1 ? ' Day Left' : ' Days Left');
                    r.licBadge.className = 'licbadge ' + (d <= 3 ? 'crit' : (d <= 7 ? 'warn' : 'ok'));
                    r.licBadge.title = (s.planName ? s.planName + ' · ' : '') + (s.customerName || '')
                        + (s.expiresAt ? ' · expires ' + new Date(s.expiresAt).toLocaleDateString() : '');
                } else {
                    r.licBadge.style.display = '';
                    r.licBadge.textContent = s.activated ? 'Expired' : 'Locked';
                    r.licBadge.className = 'licbadge crit';
                    r.licBadge.title = s.error || 'Activation required';
                }
            }

            // activation card — visible only when not usable
            r.licCard.style.display = usable ? 'none' : '';
            if (!usable && r.licMsg) {
                if (s.checking) { r.licMsg.style.display = ''; r.licMsg.className = 'licmsg info'; r.licMsg.textContent = 'Checking…'; }
                else if (s.error) { r.licMsg.style.display = ''; r.licMsg.className = 'licmsg err'; r.licMsg.textContent = s.error; }
                else if (s.activated && s.status && s.status !== 'ACTIVE') { r.licMsg.style.display = ''; r.licMsg.className = 'licmsg err'; r.licMsg.textContent = 'This license is ' + String(s.status).toLowerCase() + '.'; }
                else { r.licMsg.style.display = 'none'; r.licMsg.textContent = ''; }
            }
            if (r.licBtn) { r.licBtn.disabled = !!s.checking; r.licBtn.textContent = s.checking ? 'Activating…' : 'Activate'; }

            this.gateRunButtons();
            this.refreshLicConfig(s);
        },

        // Lock START + Auto Date Book when there's no usable license (never
        // while a run is live — we don't want to trap an in-flight booking;
        // controller.stop handles a hard revocation). isUsable() is sync/cheap,
        // so this is safe to call on every state tick.
        gateRunButtons() {
            const r = this.refs; if (!r.mainBtn) return;
            const usable = !VA.license || VA.license.isUsable();
            const running = VA.state.get('running');
            r.mainBtn.disabled = !usable && !running;
            r.mainBtn.classList.toggle('locked', !usable && !running);
            if (r.datesOnlyBtn) {
                r.datesOnlyBtn.disabled = !usable;
                r.datesOnlyBtn.classList.toggle('locked', !usable);
            }
        },

        async doActivate() {
            const r = this.refs;
            if (!VA.license) return;
            const key = r.licKey ? r.licKey.value : '';
            if (!key || key.replace(/[^0-9A-Za-z]/g, '').length < 16) {
                if (r.licMsg) { r.licMsg.style.display = ''; r.licMsg.className = 'licmsg err'; r.licMsg.textContent = 'Enter your full activation key.'; }
                if (r.licKey) { try { r.licKey.focus(); } catch (_) {} }
                return;
            }
            const res = await VA.license.activate(key);
            if (res && res.ok && r.licKey) r.licKey.value = '';
            // VA.license emits on completion → onLicense refreshes everything.
        },

        // Called by the controller gate when START is pressed with no license:
        // force the panel open on the Run tab, nudge + focus the key field.
        requireLicense() {
            this.mount();
            if (!this.visible) this.show();
            if (this.wrap) this.wrap.classList.remove('min');
            if (this.tab !== 'run') { this.tab = 'run'; this.renderTab(); this.syncTabs(); }
            this.onLicense(VA.license ? VA.license.getState() : null);
            const r = this.refs;
            if (r.licCard) {
                r.licCard.classList.remove('nudge');
                void r.licCard.offsetWidth;         // reflow → restart the animation
                r.licCard.classList.add('nudge');
                setTimeout(() => { if (r.licCard) r.licCard.classList.remove('nudge'); }, 1400);
            }
            if (r.licKey) { try { r.licKey.focus(); } catch (_) {} }
        },

        // Config-tab subscription panel (status + device management). Safe to
        // call any time; no-ops until the Config view has been built.
        refreshLicConfig(s) {
            const box = this.refs.licCfg; if (!box) return;
            s = s || (VA.license ? VA.license.getState() : null) || {};
            box.textContent = '';
            const line = (lab, val, cls) => h('div', { class: 'licline' }, [
                h('span', { class: 'lab', text: lab }), h('span', { class: 'val ' + (cls || ''), text: val })
            ]);
            if (!s.ready) {
                box.appendChild(h('div', { class: 'hint', text: 'Checking license…' }));
            } else if (s.usable) {
                box.appendChild(line('Status', 'Active', 'ok'));
                if (s.planName) box.appendChild(line('Plan', s.planName));
                if (s.customerName) box.appendChild(line('Licensed to', s.customerName));
                box.appendChild(line('Expires', s.expiresAt ? (new Date(s.expiresAt).toLocaleDateString() + ' · ' + s.daysLeft + 'd') : '—'));
                if (s.maxDevices) {
                    const u = s.usage || null;
                    box.appendChild(line('Devices', u ? (u.activeDeviceCount + ' / ' + s.maxDevices) : ('up to ' + s.maxDevices)));
                    if (s.maxBrowsersPerDevice) {
                        // License-wide: the browser limit covers ALL devices, not each one.
                        const used = (u && typeof u.activeBrowserCount === 'number') ? u.activeBrowserCount : null;
                        box.appendChild(line('Browsers', used !== null ? (used + ' / ' + s.maxBrowsersPerDevice) : ('up to ' + s.maxBrowsersPerDevice)));
                    }
                }
            } else {
                box.appendChild(h('div', { class: 'hint', text: s.activated ? ('This license is not active' + (s.error ? ' — ' + s.error : '.')) : 'Not activated. Enter your key on the Run tab.' }));
            }
            if (s.installationId) box.appendChild(h('div', { class: 'hint', style: 'margin-top:6px;word-break:break-all', text: 'Install ID: ' + s.installationId }));
            if (this.refs.licCfgBtn) this.refs.licCfgBtn.style.display = s.activated ? '' : 'none';
        },

        async doDeactivate() {
            if (!VA.license) return;
            const btn = this.refs.licCfgBtn;
            if (btn) { btn.disabled = true; btn.textContent = 'Deactivating…'; }
            await VA.license.deactivate();
            if (btn) { btn.disabled = false; btn.textContent = 'Deactivate This Device'; }
            this.refreshLicConfig();
        },

        // ---------------- CONFIG ----------------
        buildConfig() {
            // Config always edits the LIVE working copy — never the frozen run
            // snapshot — so editing/switching during a run targets the editable
            // profile and the next run, not the booking that's already going.
            const cfg = VA.config.getLive();
            const view = h('div', {});
            const field = (label, input, hint) => h('div', { class: 'field' },
                [h('label', { text: label }), input, hint ? h('div', { class: 'hint', text: hint }) : null]);

            // ── Profile set switcher (3 isolated sets) ────────────────────
            //  Each set has its own name / login / documents / mission-centre,
            //  stored separately so editing one never touches another. The
            //  active set is what START uses; switching re-renders Config and
            //  the Run header. A live run is unaffected (it reads the snapshot).
            view.appendChild(h('div', { class: 'sechead', text: 'Profile Set' }));
            const running = VA.state.get('running');
            this.refs.profName = {};
            const profRow = h('div', { class: 'profiles' });
            VA.PROFILE_IDS.forEach((id, i) => {
                const isActive = (VA.config.activeId === id);
                const nameEl = h('span', { class: 'pnm', text: VA.config.profileName(id) });
                this.refs.profName[id] = nameEl;
                profRow.appendChild(h('button', {
                    class: 'profbtn' + (isActive ? ' active' : ''),
                    title: 'Switch to profile Set ' + (i + 1),
                    onclick: () => {
                        if (id === VA.config.activeId) return;
                        VA.config.switchProfile(id, () => {
                            if (this.tab === 'config') this.renderTab();   // rebuild with the new set
                            this.refreshWho();
                            this.refreshRunFiles();
                        });
                    }
                }, [h('span', { class: 'pn', text: 'Set ' + (i + 1) }), nameEl]));
            });
            view.appendChild(profRow);
            view.appendChild(h('div', {
                class: 'hint', style: 'margin:-2px 2px 10px',
                text: running
                    ? 'A run is active — switching edits a different set; the running booking keeps the profile it started with.'
                    : 'The active (highlighted) set is used when you press START. Sets are fully isolated.'
            }));

            // credentials
            view.appendChild(h('div', { class: 'sechead', text: 'Account' }));
            const applicant = h('input', { type: 'text', value: cfg.applicantName || '', placeholder: 'Applicant name (shown on the Run tab)' });
            applicant.addEventListener('change', () => {
                VA.config.set({ applicantName: applicant.value.trim() });
                this.refreshWho();
                // keep this set's switcher label in sync with its name
                const el = this.refs.profName && this.refs.profName[VA.config.activeId];
                if (el) el.textContent = VA.config.profileName(VA.config.activeId);
            });
            view.appendChild(field('Applicant Name', applicant, 'Shown at the top of the Run tab so your coworker knows whose booking is running.'));
            const phone = h('input', { type: 'text', value: cfg.phone || '', placeholder: 'Phone / login' });
            phone.addEventListener('change', () => { VA.config.set({ phone: phone.value.trim() }); this.refreshWho(); });
            const pass = h('input', { type: 'password', value: cfg.password || '', placeholder: 'Password' });
            pass.addEventListener('change', () => VA.config.set({ password: pass.value }));
            view.appendChild(field('Phone', phone));
            view.appendChild(field('Password', withPasswordToggle(pass), 'Stored locally on this machine. Never logged or sent anywhere. Tap the eye to check what you typed.'));

            // mission + centre
            view.appendChild(h('div', { class: 'sechead', text: 'Mission & Centre' }));
            const missionSel = this.refs.missionSel = h('select', {});
            const centreSel = this.refs.centreSel = h('select', {});
            this.fillSelect(missionSel, VA.MISSIONS, cfg.mission);
            this.fillSelect(centreSel, VA.CENTRES, cfg.centre);
            missionSel.addEventListener('change', () => VA.config.set({ mission: missionSel.value }));
            centreSel.addEventListener('change', () => VA.config.set({ centre: centreSel.value }));
            view.appendChild(field('Mission', missionSel, 'Verified against the page — a mismatch pauses the run for you to fix.'));
            view.appendChild(field('IVAC Centre', centreSel, 'Required. Matched by name on the page — a mismatch pauses the run (never guesses).'));
            view.appendChild(h('button', {
                class: 'btn', text: '⟲ Load Centres From Session',
                onclick: () => this.loadCentres()
            }));

            // scheduling
            view.appendChild(h('div', { class: 'sechead', text: 'Booking Strategy' }));
            const pref = h('textarea', { rows: '2', placeholder: 'YYYY-MM-DD, one or comma-separated (optional)' });
            pref.value = (cfg.preferredDates || []).join(', ');
            pref.addEventListener('change', () => {
                const list = pref.value.split(/[\s,]+/).map((x) => x.trim()).filter((x) => /^\d{4}-\d{2}-\d{2}$/.test(x));
                VA.config.set({ preferredDates: list });
            });
            view.appendChild(field('Preferred Dates', pref, 'Tried first. All other available dates still rotate.'));

            const gap = h('input', { type: 'number', min: '10000', step: '1000', value: cfg.gap });
            gap.addEventListener('change', () => VA.config.set({ gap: Math.max(10000, parseInt(gap.value, 10) || 20000) }));
            const backoff = h('input', { type: 'number', min: '10000', step: '1000', value: cfg.backoff429 });
            backoff.addEventListener('change', () => VA.config.set({ backoff429: Math.max(10000, parseInt(backoff.value, 10) || 25000) }));
            view.appendChild(h('div', { class: 'two' }, [field('Round-Robin Gap (ms)', gap), field('429 Backoff (ms)', backoff)]));

            const months = h('input', { type: 'number', min: '1', max: '6', value: cfg.monthsToScan });
            months.addEventListener('change', () => VA.config.set({ monthsToScan: Math.min(6, Math.max(1, parseInt(months.value, 10) || 2)) }));
            // How many times each date is attempted (solve Cloudflare → select → book)
            // before the round-robin moves on. Read by controller.maxTries().
            const tries = h('input', { type: 'number', min: '1', max: '20', value: cfg.maxTriesPerDate });
            tries.addEventListener('change', () => VA.config.set({ maxTriesPerDate: Math.min(20, Math.max(1, parseInt(tries.value, 10) || 3)) }));
            view.appendChild(h('div', { class: 'two' }, [
                field('Months To Scan', months),
                field('Tries Per Date', tries, 'Attempts on each date before moving to the next.')
            ]));

            // files
            view.appendChild(h('div', { class: 'sechead', text: 'Documents (PDF · max 4 · primary first)' }));
            const fileInput = h('input', { type: 'file', accept: 'application/pdf,.pdf', multiple: 'multiple', style: 'display:none' });
            fileInput.addEventListener('change', async () => {
                const errs = await VA.config.addFiles(fileInput.files);
                errs.forEach((e) => VA.logger.warn('File: ' + e));
                fileInput.value = '';
                this.renderFiles();
                this.refreshRunFiles();
            });
            this.refs.fileList = h('div', { class: 'files' });
            view.appendChild(h('div', { class: 'btnrow' }, [
                h('button', { class: 'btn amber', text: '+ Add PDF(s)', onclick: () => fileInput.click() }),
                h('button', { class: 'btn', text: 'Clear All', onclick: () => { VA.config.clearFiles(); this.renderFiles(); this.refreshRunFiles(); } })
            ]));
            view.appendChild(fileInput);
            view.appendChild(this.refs.fileList);
            this.renderFiles();

            // toggles
            view.appendChild(h('div', { class: 'sechead', text: 'Automation Toggles' }));
            const T = [
                ['login', 'Auto Sign-In'], ['otp', 'Auto OTP Fill'],
                ['otpPhone', 'Fetch OTP from phone app', 'Auto-receive the SMS OTP from the paired Android app (routed by the phone number above). Falls back to the manual 6-box entry when off or if the phone hasn’t sent it yet.'],
                ['popup', 'Auto Close Popup'],
                ['upload', 'Auto Upload PDF'], ['centre', 'Auto Centre / Mission'],
                ['book', 'Auto Date Book', 'The date-selection & booking loop (the main feature). Turn OFF to pause and book by hand; turn ON to resume. Also has a live button on the Run tab.'],
                ['navigate', 'Auto Navigate', 'Generic page transitions only ("I Agree" / notice links). This is NOT the date booker.'],
                ['cf', 'Auto Solve Cloudflare', 'ON: "Verify you are human" / Turnstile checks are detected and solved automatically (inline checkbox + 2Captcha), with a corner status toast. OFF: ALL Cloudflare handling is blocked — nothing is solved, no toast or alert is ever shown, and the flow proceeds without it.'],
                ['proxyIp', 'Proxy IP', 'ON: a secure proxy IP is fetched from the routing server (or generated locally) and shown on the Run tab. OFF: the proxy is disabled — no IP is fetched or generated and your dedicated device IP is used instead.']
            ];
            const toggles = VA.config.getLive('toggles');
            T.forEach(([key, label, hint]) => {
                const sw = h('div', { class: 'sw' + (toggles[key] ? ' on' : '') });
                sw.addEventListener('click', () => {
                    const val = !sw.classList.contains('on');
                    sw.classList.toggle('on', val);
                    if (key === 'book' && VA.controller && VA.controller.setBooking) VA.controller.setBooking(val);
                    else {
                        VA.config.setToggle(key, val);
                        if (key === 'cf' && VA.verify && VA.verify.onToggle) VA.verify.onToggle(val);
                        if (key === 'proxyIp') this.refreshProxyIp(val);
                    }
                });
                view.appendChild(h('div', { class: 'tg' }, [h('span', { class: 'lab', text: label }), sw]));
                if (hint) view.appendChild(h('div', { class: 'hint', text: hint, style: 'margin:-4px 2px 8px' }));
            });

            // subscription / device management (off the run hot path)
            view.appendChild(h('div', { class: 'sechead', text: 'Subscription' }));
            this.refs.licCfg = h('div', { class: 'liccfg' });
            this.refs.licCfgBtn = h('button', { class: 'btn', text: 'Deactivate This Device', onclick: () => this.doDeactivate() });
            view.appendChild(this.refs.licCfg);
            view.appendChild(h('div', { class: 'hint', text: 'Deactivating frees this device slot so the key can be activated on another PC.', style: 'margin:2px 2px 8px' }));
            view.appendChild(this.refs.licCfgBtn);
            this.refreshLicConfig();

            // Re-enable copy / cut / paste in every text field of this panel
            // (the IVAC page otherwise blocks it — see enableClipboard).
            view.querySelectorAll('input, textarea').forEach((el) => {
                const t = (el.getAttribute('type') || 'text').toLowerCase();
                if (t !== 'file' && t !== 'checkbox' && t !== 'radio') enableClipboard(el);
            });

            return view;
        },

        fillSelect(sel, list, current) {
            sel.textContent = '';
            sel.appendChild(h('option', { value: '', text: '— select —' }));
            const items = (list && list.length) ? list.slice() : [];
            if (current && items.indexOf(current) === -1) items.unshift(current);
            items.forEach((name) => sel.appendChild(h('option', { value: name, text: name })));
            sel.value = current || '';
        },

        loadCentres() {
            const centres = VA.steps.scrapeCentres();
            const missions = VA.steps.scrapeMissions();
            const cfg = VA.config.get();
            if (centres.length) { this.fillSelect(this.refs.centreSel, centres, cfg.centre); VA.logger.ok('Loaded ' + centres.length + ' centre(s) from the page.'); }
            else if (VA.CENTRES.length) { this.fillSelect(this.refs.centreSel, VA.CENTRES, cfg.centre); VA.logger.info('Used built-in centre list (none on page).'); }
            else VA.logger.warn('No centres found on the page or in the built-in list.');
            if (missions.length) this.fillSelect(this.refs.missionSel, missions, cfg.mission);
        },

        renderFiles() {
            const box = this.refs.fileList; if (!box) return;
            box.textContent = '';
            const files = VA.config.filesLive();
            if (!files.length) { box.appendChild(h('div', { class: 'hint', text: 'No files added yet.' })); return; }
            files.forEach((f, i) => {
                const kb = (f.size / 1024).toFixed(0) + ' KB';
                box.appendChild(h('div', { class: 'fitem' }, [
                    i === 0 ? h('span', { class: 'pri', text: 'PRIMARY' }) : h('span', {
                        class: 'x', title: 'Make primary', text: '⭱',
                        onclick: () => { const arr = VA.config.filesLive(); const [m] = arr.splice(i, 1); arr.unshift(m); VA.config.saveFiles(); this.renderFiles(); this.refreshRunFiles(); }
                    }),
                    h('span', { class: 'fn', text: f.name }),
                    h('span', { class: 'hint', text: kb }),
                    h('span', { class: 'x', title: 'Remove', text: '✕', onclick: () => { VA.config.removeFile(i); this.renderFiles(); this.refreshRunFiles(); } })
                ]));
            });
        },

        // ---------------- LOGS ----------------
        buildLogs() {
            const mkChip = (f) => h('span', {
                class: 'chip' + (this.logFilter === f ? ' active' : ''), text: f,
                onclick: () => { this.logFilter = f; this.renderLogs(); }
            });
            this.refs.chips = { ALL: mkChip('ALL'), NET: mkChip('NET'), OK: mkChip('OK'), ERR: mkChip('ERR') };
            this.refs.logCount = h('span', { class: 'hint' });
            const bar = h('div', { class: 'logbar' }, [
                h('div', { class: 'filt' }, [this.refs.chips.ALL, this.refs.chips.NET, this.refs.chips.OK, this.refs.chips.ERR]),
                h('span', { class: 'sp' }),
                this.refs.logCount,
                h('span', { class: 'chip', text: 'CLEAR', onclick: () => { VA.logger.clear(); this.renderLogs(); } })
            ]);
            this.refs.logList = h('div', { class: 'logs' });
            const view = h('div', {}, [bar, this.refs.logList]);
            this.renderLogs();
            return view;
        },

        matchFilter(cat) {
            if (this.logFilter === 'ALL') return true;
            if (this.logFilter === 'ERR') return cat === 'ERR' || cat === 'WARN';
            return cat === this.logFilter;
        },
        logRow(e) {
            return h('div', { class: 'lg ' + e.cat }, [
                h('span', { class: 'ts', text: e.t }),
                h('span', { class: 'cat', text: e.cat }),
                h('span', { class: 'msg' }, [e.msg, e.n > 1 ? h('span', { class: 'n', text: '  ×' + e.n }) : null])
            ]);
        },
        renderLogs() {
            const list = this.refs.logList; if (!list) return;
            for (const k in this.refs.chips) this.refs.chips[k].classList.toggle('active', this.logFilter === k);
            list.textContent = '';
            const rows = VA.logger.entries.filter((e) => this.matchFilter(e.cat));
            if (!rows.length) { list.appendChild(h('div', { class: 'empty', text: 'No log entries.' })); }
            else rows.forEach((e) => list.appendChild(this.logRow(e)));
            this.refs.logCount.textContent = VA.logger.entries.length + ' lines';
            list.scrollTop = list.scrollHeight;
        },
        onLog(e, upd) {
            // Run tab shows a live strip; Logs tab shows the full list.
            if (this.tab === 'run') this.renderLogStrip();
            else if (this.tab === 'logs' && this.refs.logList) this.renderLogs();
        },

        // ---------------- drag / show / hide ----------------
        wireDrag() {
            const hdr = this.refs.hdr; let sx, sy, ox, oy, dragging = false;
            hdr.addEventListener('pointerdown', (ev) => {
                if (ev.target.classList.contains('iconbtn')) return;
                dragging = true; hdr.classList.add('drag');
                const rect = this.wrap.getBoundingClientRect();
                sx = ev.clientX; sy = ev.clientY; ox = rect.left; oy = rect.top;
                this.wrap.style.right = 'auto';
                this.wrap.style.left = ox + 'px'; this.wrap.style.top = oy + 'px';
                try { hdr.setPointerCapture(ev.pointerId); } catch (_) {}
            });
            hdr.addEventListener('pointermove', (ev) => {
                if (!dragging) return;
                const w = this.wrap.getBoundingClientRect();
                let nx = ox + (ev.clientX - sx), ny = oy + (ev.clientY - sy);
                nx = Math.max(0, Math.min(nx, innerWidth - w.width));
                ny = Math.max(0, Math.min(ny, innerHeight - 40));
                this.wrap.style.left = nx + 'px'; this.wrap.style.top = ny + 'px';
            });
            const end = (ev) => {
                if (!dragging) return; dragging = false; hdr.classList.remove('drag');
                try { hdr.releasePointerCapture(ev.pointerId); } catch (_) {}
                VA.storage.setUi({ pos: { left: this.wrap.style.left, top: this.wrap.style.top } });
            };
            hdr.addEventListener('pointerup', end);
            hdr.addEventListener('pointercancel', end);
        },
        restorePos() {
            VA.storage.getUi((u) => {
                if (u && u.pos && u.pos.left) {
                    this.wrap.style.right = 'auto';
                    this.wrap.style.left = u.pos.left; this.wrap.style.top = u.pos.top;
                }
            });
        },

        show() { this.mount(); requestAnimationFrame(() => this.wrap.classList.add('show')); this.visible = true; VA.storage.setUi({ panelOpen: true }); },
        hide() { if (this.wrap) this.wrap.classList.remove('show'); this.visible = false; VA.storage.setUi({ panelOpen: false }); },
        toggle() { this.mount(); (this.visible ? this.hide() : this.show()); },

        // ------------------------------------------------------------
        //  Corner CAPTCHA toast. Lives in its OWN host + Shadow DOM (not the
        //  panel) so it shows even when the panel is hidden or minimized, and
        //  stays visually isolated from the site's Tailwind.
        //
        //  kind: 'work' (solving, amber, sticky) | 'ok' (solved, green, fades)
        //        | 'warn' (needs a human, red, sticky)
        // ------------------------------------------------------------
        cfToast(msg, kind) {
            kind = kind || 'work';
            if (!this._cfHost) {
                const host = this._cfHost = document.createElement('div');
                host.id = 'va-cf-toast-host';
                host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;';
                (document.documentElement || document.body).appendChild(host);
                const root = this._cfRoot = host.attachShadow({ mode: 'open' });
                const st = document.createElement('style');
                st.textContent = VA.CF_TOAST_CSS;
                root.appendChild(st);
                this._cfBox = document.createElement('div');
                this._cfBox.className = 'cft';
                root.appendChild(this._cfBox);
            }
            const box = this._cfBox;
            // Don't let a stale "solving…" overwrite a fresh "verified ✓".
            box.className = 'cft show ' + kind;
            box.textContent = (kind === 'ok' ? '✓ ' : kind === 'warn' ? '⚠ ' : '⟳ ') + msg;

            if (this._cfTimer) { clearTimeout(this._cfTimer); this._cfTimer = null; }
            if (kind === 'ok') {
                this._cfTimer = setTimeout(() => { try { box.className = 'cft ' + kind; } catch (_) {} }, 4000);
            }
        },
        _cfHost: null, _cfRoot: null, _cfBox: null, _cfTimer: null,

        // Pulse the panel border to flag that a human is needed. Also forces
        // the panel visible when raising, so a minimized/hidden panel can't
        // hide the alert. Called by VA.attention.
        flash(on) {
            this.mount();
            if (on) { if (!this.visible) this.show(); this.wrap.classList.remove('min'); }
            if (this.wrap) this.wrap.classList.toggle('alert', !!on);
        }
    };

    VA.ui = ui;
})();
