// ============================================================
//  Visa Automator — controller  (ISOLATED world)
// ------------------------------------------------------------
//  The brain. One setInterval tick (R7) drives a reactive machine:
//  detectStage() reads the live page, and the enabled handler for
//  that stage runs — never a rigid linear script. Stage 7 (dates)
//  is special: the controller keeps the run parked there and cycles
//  through candidate dates on a round-robin gap until it breaks
//  through to payment or the user stops.
//
//  Cancellation is layered (R2): Stop aborts the AbortController AND
//  bumps runId; every async continuation re-checks its captured gen
//  and bails if the run moved on. All timers/observers live in
//  VA.run and are flushed on Stop.
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.controller) return;
    const SEL = VA.SELECTORS;
    const D = VA.dom;

    const TICK_MS = 1200;
    const COOLDOWN = 2500;      // don't re-fire a stage that just acted 'ok'
    const STABLE_TICKS = 2;     // a stage must persist before we act (R5)
    // spec: try one date up to N full cycles, then move on. Config-driven
    // (maxTriesPerDate) with a hard default of 3.
    const maxTries = () => Math.max(1, VA.config.get('maxTriesPerDate') || 3);
    const PAYMENT_HINT = /(payment|gateway|checkout|dgepay|webview|sslcommerz|aamarpay|bkash|nagad|redirect|billing)/i;

    function ctxNow() {
        return { signal: VA.run.ac ? VA.run.ac.signal : undefined, gen: VA.state.get('runId') };
    }
    function isCurrent(gen) { return gen === VA.state.get('runId') && VA.state.get('running'); }

    // ---- stage reflection into the stepper ----
    function reflect(stageKey, st) {
        const idx = VA.stageIndex(stageKey);
        const map = Object.assign({}, VA.state.get('stageStates'));
        VA.STAGES.forEach((s, i) => {
            const cur = map[s.key];
            if (i < idx) {
                if (cur !== 'error' && cur !== 'success' && cur !== 'skipped') map[s.key] = 'success';
            } else if (i === idx) {
                if (cur !== 'success' || st === 'error' || st === 'waiting') map[s.key] = st;
            }
        });
        VA.state.set({ stageStates: map });
    }

    function manualWait(stageKey, note) {
        reflect(stageKey, 'waiting');
        if (VA.state.get('waitingManual') !== stageKey) {
            VA.state.set({ waitingManual: stageKey });
            VA.logger.waiting('Manual step needed — ' + (note || stageKey) + '. Automation continues when the page advances.');
        }
    }

    // Hard pause — needs an explicit user Resume; does NOT auto-resume when the
    // page advances (unlike manualWait). Used for upload errors and mission/
    // centre mismatches: anything a human must inspect before we go on.
    function pauseHard(stageKey, reason) {
        reflect(stageKey, 'error');
        const cur = VA.state.get('paused');
        if (!cur || cur.stage !== stageKey || cur.reason !== reason) {
            VA.state.set({ paused: { stage: stageKey, reason: reason }, error: reason });
            VA.logger.err('⏸ Paused at ' + stageKey + ' — ' + reason);
        }
    }

    function applyResult(stageKey, r, gen) {
        if (!isCurrent(gen)) return;
        if (!r) return;
        switch (r.status) {
            case 'ok':
                if (r.more) {
                    // Serial upload, mid-sequence: the next file must attach at
                    // once, not after the anti-double-click cooldown. Keep the
                    // stage 'running', skip the cooldown, and re-tick promptly —
                    // still exactly one file per tick.
                    reflect(stageKey, 'running');
                    VA.run.acted = null;
                    VA.run.setTimeout(function () { if (isCurrent(gen)) tick(); }, 150);
                } else {
                    reflect(stageKey, 'success');
                    VA.run.acted = { stage: stageKey, at: Date.now() };
                }
                break;
            case 'uploaded':
                // Every file verified. Park for the mandatory user confirmation.
                if (VA.state.get('uploadConfirm') === 'idle') {
                    VA.state.set({ uploadConfirm: 'waiting' });
                    reflect('confirm', 'waiting');
                    VA.logger.waiting('All files uploaded & verified — review them on the page, then click "Confirm & Continue" in the panel.');
                }
                break;
            case 'manual':
                manualWait(stageKey, r.note);
                VA.run.acted = { stage: stageKey, at: Date.now() };
                break;
            case 'error':
                pauseHard(stageKey, r.reason || 'error');
                break;
            case 'wait':
            case 'noop':
            default:
                break;
        }
    }

    // Release the phone-relayed OTP once the page has demonstrably accepted it.
    // Called when the OTP stage is behind us; idempotent (no pending lease = no-op),
    // and a failed ACK simply leaves the lease in place for a later retry.
    async function confirmRelayedOtp() {
        try {
            if (VA.otpRelay && VA.otpRelay.pending()) await VA.otpRelay.ack();
        } catch (_) {}
    }

    // Stages that can only be reached AFTER the OTP was accepted — used as a
    // safety net for flows that don't render the appointment notice.
    const POST_OTP_STAGES = { otpSuccess: 1, popup: 1, upload: 1, confirm: 1, centre: 1, dates: 1, payment: 1 };

    // Discard every trace of a REJECTED code: the stored value, the panel cells,
    // and the phone-relay lease (acked server-side so the backend never serves
    // that code again). A fresh code can then be fetched or typed. Never resend.
    async function discardOtp() {
        VA.otpGuard.clearPending();
        VA.config.setOtp('');
        try { if (VA.ui && VA.ui.clearOtpDisplay) VA.ui.clearOtpDisplay(); } catch (_) {}
        try { if (VA.otpRelay && VA.otpRelay.discard) await VA.otpRelay.discard(); } catch (_) {}
    }
    function resetOtpGuard() { try { VA.otpGuard.reset(); } catch (_) {} }

    // ---- payment detection (R6 fallbacks 2 & 3) ----
    function paymentVisible() {
        try {
            if (PAYMENT_HINT.test(location.href) && !/ivacbd\.com/i.test(location.host)) return true;
        } catch (_) {}
        const frames = document.querySelectorAll('iframe[src]');
        for (const f of frames) { if (PAYMENT_HINT.test(f.src || '')) return true; }
        const links = document.querySelectorAll('a[href]');
        for (const a of links) {
            const h = a.getAttribute('href') || '';
            if (/^https?:\/\//.test(h) && PAYMENT_HINT.test(h) && !/ivacbd\.com/i.test(h)) return true;
        }
        return false;
    }
    function findVisiblePaymentUrl() {
        const frames = document.querySelectorAll('iframe[src]');
        for (const f of frames) { if (PAYMENT_HINT.test(f.src || '')) return f.src; }
        try { if (PAYMENT_HINT.test(location.href) && !/ivacbd\.com/i.test(location.host)) return location.href; } catch (_) {}
        return '';
    }

    // ---- reactive stage detection (R5: ordered, first-match-wins) ----
    function visibleDialog() {
        const dialogs = document.querySelectorAll('[role="dialog"], .swal2-popup, .modal.show, [class*="modal" i][class*="open" i]');
        for (const d of dialogs) { if (D.isVisible(d)) return true; }
        return false;
    }
    function detectStage() {
        if (VA.state.get('paymentUrl') || paymentVisible()) return 'payment';

        const hasPhone = !!document.querySelector(SEL.phone);
        const hasPass = !!document.querySelector(SEL.password);
        const otpBoxes = document.querySelectorAll(SEL.otpBoxes);
        const onCalendar = !!(VA.steps && VA.steps.dates && VA.steps.dates.atCalendar());

        if (visibleDialog() && !onCalendar) return 'popup';
        if (hasPhone && hasPass) return 'login';
        if ((otpBoxes.length || document.querySelector(SEL.otpBox)) && !hasPass) return 'otp';
        if (onCalendar) return 'dates';

        // Uploads verified — parked while awaiting the user's confirmation AND
        // while the confirm+save is in flight, so nothing else (e.g. the popup
        // handler) touches that dialog mid-handoff.
        const uc = VA.state.get('uploadConfirm');
        if (uc === 'waiting' || uc === 'confirmed') return 'confirm';

        // Upload page: a file input, or the on-page confirm button once all files landed.
        if (document.querySelector(SEL.fileInput) || D.findButtonByText(SEL.text.confirmInfo)) return 'upload';

        // Mission/Centre: the custom centre chevron or the confirm-mission button
        // (kept below upload so an upload-page control isn't misread as the centre).
        if (D.findButtonByText(SEL.text.confirmMission) ||
            document.querySelector(SEL.centreChevron) ||
            document.querySelector(SEL.centreSelect) ||
            document.querySelector(SEL.missionSelect)) return 'centre';

        if (document.querySelector(SEL.appointmentNotice)) return 'otpSuccess';
        return 'unknown';
    }

    // ---- round-robin booking rhythm (the primary task) ----
    // Walk the calendar back to the month the cycle started on, so every
    // cycle rescans months 1..N instead of drifting forward forever.
    async function resetToBaseMonth(ctx) {
        let n = VA.run.monthsScanned;
        while (n-- > 0) {
            const btn = document.querySelector(SEL.prevMonth);
            if (!btn || btn.disabled || !D.isVisible(btn)) break;
            D.click(btn);
            await D.sleep(500, ctx.signal);
            if (ctx.signal && ctx.signal.aborted) break;
        }
        VA.run.monthsScanned = 0;
    }

    function scheduleGap(reason) {
        const use429 = (Date.now() - (VA.run.last429At || 0)) < 8000;
        const wait = use429 ? (VA.config.get('backoff429') || 15000) : (VA.config.get('gap') || 2000);
        VA.run.nextAttemptAt = Date.now() + wait;
        VA.state.set({ nextIn: Math.ceil(wait / 1000) });
        VA.logger.waiting((use429 ? '429 backoff' : 'Round-robin gap') +
            ' — next attempt in ' + Math.ceil(wait / 1000) + 's' + (reason ? ' (' + reason + ')' : '') + '.');
    }

    async function bookingTick(gen) {
        reflect('dates', 'running');
        const ctx = ctxNow();
        if (Date.now() < VA.run.nextAttemptAt) return;   // inside the gap; countdown ticks separately

        // (re)build the candidate queue for this month — but NOT while a date
        // is mid-retry (current set), or an empty queue during a retry gap would
        // rescan and re-add the very date we're still cycling on.
        if (!VA.run.queue.length && !VA.run.current) {
            let cands = VA.steps.dates.scan();
            if (!cands.length) {
                const monthsToScan = Math.max(1, VA.config.get('monthsToScan') || 2);
                if (VA.run.monthsScanned < monthsToScan - 1 && await VA.steps.dates.gotoNextMonth(ctx)) {
                    if (!isCurrent(gen)) return;
                    VA.run.monthsScanned++;
                    VA.logger.info('No dates this month — advanced to next month.');
                    return;
                }
                await resetToBaseMonth(ctx);
                if (!isCurrent(gen)) return;
                VA.state.set({ cycle: VA.state.get('cycle') + 1, availableDates: [], trying: null });
                scheduleGap('no available dates');
                return;
            }
            cands = VA.steps.dates.order(cands, VA.config.get('preferredDates') || []);
            VA.run.queue = cands;
            VA.state.set({ availableDates: cands.map((c) => c.key) });
            VA.logger.ok('Found ' + cands.length + ' available date(s): ' + cands.map((c) => c.key).join(', '));
        }

        // Pick the date under retry. VA.run.current = { cand, tries } persists
        // across ticks/gaps so one date gets up to maxTries() full cycles
        // (select → Cloudflare → settle → Booking → check) before we give up on
        // it and move to another randomly-ordered date.
        if (!VA.run.current) {
            const next = VA.run.queue.shift();
            if (!next) { scheduleGap('empty queue'); return; }
            VA.run.current = { cand: next, tries: 0 };
        }
        const cur = VA.run.current;
        const cand = cur.cand;
        const MAX = maxTries();
        cur.tries++;
        VA.state.set({ trying: cand.key, attempts: VA.state.get('attempts') + 1, tryOf: cur.tries, tryMax: MAX });
        VA.logger.info('Attempt #' + VA.state.get('attempts') + ' → ' + cand.key +
            ' (try ' + cur.tries + '/' + MAX + ')');

        const res = await VA.steps.dates.attempt(cand, ctx);
        if (!isCurrent(gen)) return;

        if (res.status === 'success') {
            onPayment(VA.state.get('paymentUrl') || findVisiblePaymentUrl() || location.href);
            return;
        }
        if (res.status === 'moved') {
            VA.logger.ok('Moved past the calendar — following the flow forward.');
            reflect('dates', 'success');
            VA.run.queue = [];
            VA.run.current = null;
            VA.run.nextAttemptAt = 0;
            VA.state.set({ trying: null, tryOf: 0, tryMax: 0 });
            return;
        }
        if (res.status === 'aborted') return;

        if (res.status === 'manual') {
            // A human must clear Cloudflare — that's not the date's fault, so
            // don't burn a try. Keep the same date and re-attempt once unblocked.
            cur.tries--;
            manualWait('dates', 'Verification');
            scheduleGap('verification');
            return;
        }

        if (res.backoff) {
            // Server rate-limited us (429). Not the date's fault → don't count
            // the try; back off harder and retry the SAME date next gap.
            VA.run.last429At = Date.now();
            cur.tries--;
            VA.logger.warn('Rate-limited on ' + cand.key + ' — backing off (try not counted).');
            scheduleGap(res.reason);
            return;
        }

        // Ordinary failure for this date.
        VA.logger.warn('Date ' + cand.key + ' did not go through: ' + (res.reason || 'unknown') +
            ' (try ' + cur.tries + '/' + MAX + ').');
        if (cur.tries < MAX) {
            scheduleGap('retry ' + cand.key);          // same date again, spaced out
            return;
        }

        // Exhausted the tries — mark this date failed and move to another
        // (randomly-ordered) date; roll month/cycle when the pass ends.
        VA.logger.warn('Date ' + cand.key + ' failed ' + MAX + ' times — trying another date.');
        VA.run.current = null;
        if (!VA.run.queue.length) {
            const monthsToScan = Math.max(1, VA.config.get('monthsToScan') || 2);
            if (VA.run.monthsScanned < monthsToScan - 1 && await VA.steps.dates.gotoNextMonth(ctx)) {
                if (!isCurrent(gen)) return;
                VA.run.monthsScanned++;
            } else {
                await resetToBaseMonth(ctx);
                if (!isCurrent(gen)) return;
                VA.state.set({ cycle: VA.state.get('cycle') + 1 });
            }
        }
        scheduleGap(res.reason);
    }

    // ---- per-stage routing ----
    async function route(stage, gen) {
        // Skip This Page (Part 21-26): after a manual skip, do NOT re-act on the
        // same page/stage. The latch clears in tick() when location.href changes
        // (real navigation), so the NEXT page routes normally. A different stage
        // detected on the same href (SPA re-render) is NOT suppressed.
        if (VA.run._skippedHref === location.href && stage === VA.run._skippedStage) return;

        const t = VA.config.toggles();
        const ctx = ctxNow();

        // Page-only Auto Date Book: touch NOTHING except the calendar (and the
        // terminal payment capture). We never run login/upload/centre here, so
        // the operator can start the booking loop straight from the date page.
        if (VA.state.get('datesOnly') && stage !== 'dates' && stage !== 'payment') {
            reflect('dates', 'waiting');
            if (!VA.run.datesWaitNoticed) {
                VA.run.datesWaitNoticed = true;
                VA.logger.waiting('Page-only Auto Date Book — open the appointment calendar to begin. Login / upload / mission-centre are skipped in this mode.');
            }
            return;
        }

        // Safety net: standing on any stage past the OTP page means the code was
        // accepted — release the phone-relayed lease AND clear the anti-retry
        // guard. Idempotent, retried on later ticks if the ACK couldn't get through.
        if (POST_OTP_STAGES[stage]) {
            if (VA.otpGuard.pendingSubmit() || VA.otpGuard.attempts()) resetOtpGuard();
            if (VA.otpRelay && VA.otpRelay.pending()) {
                await confirmRelayedOtp();
                if (!isCurrent(gen)) return;
            }
        }

        switch (stage) {
            case 'payment':
                onPayment(VA.state.get('paymentUrl') || findVisiblePaymentUrl() || location.href);
                return;
            case 'login':
                if (!t.login) return manualWait('login', 'Auto Sign-In is OFF');
                reflect('login', 'running');
                applyResult('login', await VA.steps.login(ctx), gen);
                return;
            case 'otp': {
                if (!t.otp) return manualWait('otp', 'Auto OTP Fill is OFF');
                reflect('otp', 'running');

                // The site is telling us the account is throttled/locked. Any
                // further attempt risks a ban, so STOP and require a human.
                if (VA.steps.otpLockedText) {
                    const lock = VA.steps.otpLockedText();
                    if (lock) return pauseHard('otp', 'The site reports an OTP lock/throttle ("' + lock + '") — stopping to protect the account.');
                }

                // A code we just submitted may still be in flight — give the site
                // its grace window before judging it, and never resend meanwhile.
                if (VA.otpGuard.awaitingConfirm()) return;

                // Back on the OTP page after a submit ⇒ that code was rejected.
                // Discard it so the SAME code is never resent, and count the try.
                if (VA.otpGuard.pendingSubmit()) {
                    const used = VA.otpGuard.attempts();
                    VA.logger.warn('OTP rejected (' + used + '/' + VA.otpGuard.MAX_TRIES + ') — discarding it; a new code is required.');
                    await discardOtp();
                    if (!isCurrent(gen)) return;
                    if (VA.otpGuard.exhausted()) {
                        return pauseHard('otp', 'OTP rejected ' + used + ' times — stopping to avoid an account lock. Get a fresh code, then Resume.');
                    }
                }

                // Receive a fresh code from the paired phone app (if enabled and
                // we don't already hold one). On a hit this sets VA.config.otp()
                // so the filler below submits it. Manual entry stays available.
                if (!VA.config.otp() && t.otpPhone && VA.otpRelay) {
                    await VA.otpRelay.tryFetch();
                    if (!isCurrent(gen)) return;
                }
                const code = VA.config.otp();
                // Nothing yet: with the phone relay on, keep polling quietly.
                if (!code && t.otpPhone) return;
                if (!code) return manualWait('otp', 'Enter the OTP (from SMS) in the Run tab');

                // Never re-send a code already submitted on this OTP page.
                if (VA.otpGuard.alreadyTried(code)) {
                    VA.logger.warn('That OTP was already tried — waiting for a different code.');
                    await discardOtp();
                    return;
                }

                // Fill and submit. The relayed lease is released by the post-OTP
                // guard once the page demonstrably advances, so an accepted code
                // is never destroyed; a rejected one is discarded above.
                const res = await VA.steps.otp(ctx);
                if (res && res.submitted) VA.otpGuard.markSubmitted(code);
                applyResult('otp', res, gen);
                return;
            }
            case 'otpSuccess':
                reflect('otpSuccess', 'success');
                if (!t.navigate) return manualWait('otpSuccess', 'Auto Navigate is OFF');
                applyResult('otpSuccess', await VA.steps.navigate(ctx), gen);
                return;
            case 'popup':
                if (!t.popup) return manualWait('popup', 'Auto Close Popup is OFF');
                reflect('popup', 'running');
                applyResult('popup', await VA.steps.popup(ctx), gen);
                return;
            case 'upload':
                if (!t.upload) return manualWait('upload', 'Auto Upload is OFF');
                reflect('upload', 'running');
                applyResult('upload', await VA.steps.upload(ctx), gen);
                return;
            case 'centre':
                if (!t.centre) return manualWait('centre', 'Auto Centre/Mission is OFF');
                reflect('centre', 'running');
                applyResult('centre', await VA.steps.centre(ctx), gen);
                return;
            case 'confirm':
                // Parked: files verified. 'waiting' = awaiting the user's click;
                // 'confirmed' = confirmUploads() is driving the confirm+save dialog
                // right now, so mirror 'running' and touch nothing on the page.
                reflect('confirm', VA.state.get('uploadConfirm') === 'confirmed' ? 'running' : 'waiting');
                return;
            case 'dates':
                // Auto Date Book OFF → sit idle so the user can book by hand.
                // This is a SOFT wait: uploads/payment detection keep running,
                // and flipping the toggle back on resumes the loop instantly.
                VA.run.datesWaitNoticed = false;   // reached the calendar
                if (!t.book) return manualWait('dates', 'Auto Date Book is OFF — book manually, or switch it back on to resume');
                await bookingTick(gen);
                return;
            default:
                // Unknown/among transitions — gently nudge forward if allowed.
                if (t.navigate) await VA.steps.navigate(ctx);
                return;
        }
    }

    // ---- the single tick ----
    async function tick() {
        if (!VA.state.get('running') || VA.run.busy) return;
        if (VA.state.get('paused')) return;      // hard pause — await explicit Resume
        VA.run.busy = true;
        const gen = VA.state.get('runId');
        try {
            // SPA route change (pushState fires no event) — poll href (R5).
            if (location.href !== VA.run.lastHref) {
                VA.run.lastHref = location.href;
                VA.logger.info('Page: ' + VA.shortPath(location.href));
                VA.run.acted = null;
                VA.run.stableStage = null;
                VA.run.stableCount = 0;
                VA.run._skippedHref = null;    // advanced past a skipped page → resume normal routing
                VA.run._skippedStage = null;
            }

            const stage = detectStage();
            VA.state.set({ detected: stage });

            // auto-resume from a manual-wait once the page advances
            const wm = VA.state.get('waitingManual');
            if (wm && wm !== stage) {
                VA.state.set({ waitingManual: null });
                VA.logger.ok('Page advanced — resuming automation.');
            }

            // stability gate (dates/payment act immediately)
            if (stage !== VA.run.stableStage) { VA.run.stableStage = stage; VA.run.stableCount = 1; }
            else VA.run.stableCount++;
            // `upload` also acts immediately: VA.steps.upload is fully self-gating
            // (it awaits VA.verify.gate on the exact slot before attaching and
            // positively verifies each file's acceptance), so the extra stability
            // tick only delays the primary upload without adding any safety.
            const stable = VA.run.stableCount >= STABLE_TICKS ||
                stage === 'dates' || stage === 'payment' || stage === 'upload';
            if (!stable) return;

            // cooldown after a successful action (not for the dates loop)
            if (stage !== 'dates' && VA.run.acted && VA.run.acted.stage === stage &&
                (Date.now() - VA.run.acted.at) < COOLDOWN) return;

            await route(stage, gen);
        } catch (e) {
            VA.logger.err('Tick error: ' + (e && e.message ? e.message : e));
        } finally {
            if (gen === VA.state.get('runId')) VA.run.busy = false;
        }
    }

    function countdown() {
        if (!VA.state.get('running')) return;
        // The countdown only drives the panel's "next in Ns" readout. In a
        // background tab nobody sees it, so skip the 4-per-second state emit
        // (which re-renders the panel) entirely — the next visible tab tick
        // refreshes it. The booking maths use real timestamps, not this value.
        if (typeof document !== 'undefined' && document.hidden) return;
        const ms = VA.run.nextAttemptAt - Date.now();
        const s = ms > 0 ? Math.ceil(ms / 1000) : 0;
        if (s !== VA.state.get('nextIn')) VA.state.set({ nextIn: s });
    }

    // ---- payment terminal ----
    function onPayment(url) {
        if (!url) return;
        if (VA.state.get('paymentUrl') === url && !VA.state.get('running')) return;
        VA.state.set({ paymentUrl: url });
        reflect('payment', 'success');
        VA.logger.ok('Payment link captured — automation complete. Pay manually.');
        // Halt the aggressive loop but keep the captured URL on screen.
        VA.run.clearAll();
        VA.run.snap = null;              // run finished → unfreeze the profile
        VA.state.set({ running: false, waitingManual: null, nextIn: 0, trying: null });
        try { VA.attention && VA.attention.clear(); } catch (_) {}
    }

    // ---- spin up the run loop (shared by start / startDatesOnly) ----
    function launchRun(datesOnly) {
        if (VA.state.get('running')) { VA.logger.warn('Already running.'); return false; }
        // A full run needs the queued files; a page-only booking run does not.
        const needFiles = !datesOnly;
        if (!VA.ready.core || !VA.ready.config || (needFiles && !VA.ready.files)) {
            VA.logger.warn('Still loading saved settings — try again in a moment.');
            return false;
        }
        VA.run.clearAll();               // belt-and-suspenders before a fresh run
        try { VA.otpRelay && VA.otpRelay.reset(); } catch (_) {}
        resetOtpGuard();                 // fresh run ⇒ no codes tried yet
        VA.state.reset();
        VA.state.set({ running: true, runId: VA.state.get('runId') + 1, paymentUrl: '', datesOnly: !!datesOnly });
        // Freeze the active profile for the whole run (Part 16): steps.js and the
        // Run header read this snapshot, so a mid-run profile switch/edit changes
        // only the editable copy and the NEXT run — never this one.
        VA.run.snap = VA.config.snapshot();
        VA.run.ac = new AbortController();
        VA.run.lastHref = location.href;
        VA.run.nextAttemptAt = 0;
        VA.run.acted = null;
        VA.run.stableStage = null;
        VA.run.stableCount = 0;
        VA.run.datesWaitNoticed = false;
        VA.run._skippedHref = null;      // no page skipped yet this run
        VA.run._skippedStage = null;
        VA.run._uploadDone = 0;          // fresh run ⇒ nothing attached by us yet
        VA.run._uploadWaitSlot = null;
        VA.state.set({ uploadName: '', uploadPhase: '', trying: null, tryOf: 0, tryMax: 0 });
        VA.run.loopTimer = setInterval(tick, TICK_MS);
        VA.run.countdownTimer = setInterval(countdown, 250);
        VA.storage.setUi({ running: true, datesOnly: !!datesOnly });
        return true;
    }

    // ---- public control ----
    const controller = {
        paymentVisible,
        onPayment,
        detectStage,
        // License gate (Phase 41): a SYNCHRONOUS, cache-only check — never a
        // network call — so the hot path stays instant. Fail-closed: if the
        // license module is missing or the cache says not-usable, we refuse to
        // launch and surface the activation panel.
        _licenseOk() {
            if (VA.license && VA.license.isUsable()) return true;
            VA.logger.err('Activation required — enter your license key in the panel to start.');
            try { VA.ui && VA.ui.requireLicense && VA.ui.requireLicense(); } catch (_) {}
            return false;
        },
        start() {
            if (!this._licenseOk()) return;
            if (!launchRun(false)) return;
            VA.logger.ok('▶ START — continuous automation engaged.');
            tick();                          // act immediately, don't wait a full tick
        },
        // Start the booking loop RIGHT HERE on the date page — no login/upload/
        // centre. Reuses the exact same date-selection logic as a full run; the
        // route() guard simply ignores every non-booking stage in this mode.
        startDatesOnly() {
            if (!this._licenseOk()) return;
            if (!launchRun(true)) return;
            VA.config.setToggle('book', true);          // booking must be active in this mode
            const map = Object.assign({}, VA.state.get('stageStates'));
            ['login', 'otp', 'otpSuccess', 'popup', 'upload', 'confirm', 'centre']
                .forEach((k) => { map[k] = 'skipped'; });
            VA.state.set({ stageStates: map });
            VA.logger.ok('▶ START (this page only) — booking on the current page. Login / upload / mission-centre are skipped.');
            tick();
        },
        stop(reason) {
            if (!VA.state.get('running') && !VA.run.loopTimer) { return; }
            VA.state.set({ running: false, runId: VA.state.get('runId') + 1, nextIn: 0, datesOnly: false });
            VA.run.clearAll();               // aborts in-flight + clears every timer/observer
            VA.run.snap = null;              // run ended → unfreeze the profile (edits/switches take effect next run)
            try { VA.otpRelay && VA.otpRelay.reset(); } catch (_) {}
            resetOtpGuard();
            VA.storage.setUi({ running: false, datesOnly: false });
            try { VA.attention && VA.attention.clear(); } catch (_) {}
            VA.logger.warn('■ STOP' + (reason ? ' — ' + reason : '') + '.');
        },
        toggle() { VA.state.get('running') ? this.stop('user') : this.start(); },

        // Invoked from the panel's "Confirm & Continue" button after the user
        // has eyeballed the uploaded files. Fires the on-page confirm + save.
        async confirmUploads() {
            if (VA.state.get('uploadConfirm') !== 'waiting') { VA.logger.warn('Nothing to confirm yet.'); return; }
            // 'confirmed' parks the tick loop (detectStage → 'confirm', a no-op) so
            // nothing else touches the confirm/save dialog while we drive it.
            VA.state.set({ uploadConfirm: 'confirmed' });
            reflect('confirm', 'running');
            VA.logger.ok('User confirmed uploads — submitting.');
            const gen = VA.state.get('runId');
            const ctx = ctxNow();
            try {
                const r = await VA.steps.confirmUploads(ctx);
                if (!isCurrent(gen)) return;
                if (!r || r.status === 'wait') {
                    VA.state.set({ uploadConfirm: 'waiting' });   // release the park, let the user retry
                    reflect('confirm', 'waiting');
                    VA.logger.warn('Confirm button not ready yet — click "Confirm & Continue" again in a moment.');
                    return;
                }
                // Wait for the page to actually leave the upload/confirm context before
                // releasing the park — otherwise a stuck dialog would wedge the loop.
                const moved = await D.waitFor(function () {
                    const stillHere = document.querySelector(SEL.fileInput) || D.findButtonByText(SEL.text.confirmInfo);
                    return stillHere ? null : true;
                }, { signal: ctx.signal, timeout: 12000, interval: 400 });
                if (!isCurrent(gen)) return;
                if (moved) {
                    reflect('confirm', 'success');
                    VA.state.set({ uploadConfirm: 'idle' });       // park released → normal detection resumes (→ centre)
                    VA.logger.ok('Confirmed — moving on to mission & centre.');
                } else {
                    VA.state.set({ uploadConfirm: 'waiting' });     // never advanced; hand back to the user
                    reflect('confirm', 'waiting');
                    VA.logger.warn('Page did not advance after confirm — check the page, then click "Confirm & Continue" again.');
                }
            } catch (e) {
                VA.logger.err('Confirm failed: ' + (e && e.message ? e.message : e));
                VA.state.set({ uploadConfirm: 'waiting' });
                reflect('confirm', 'waiting');
            }
        },

        // Pause / resume ONLY the date-booking loop (the "Auto Date Book"
        // feature). Off → the run idles at the calendar so the user can book
        // by hand; on → the loop takes over again on the next tick. Payment
        // capture and everything else keep running either way.
        setBooking(on) {
            VA.config.setToggle('book', !!on);
            if (on) {
                if (VA.state.get('waitingManual') === 'dates') VA.state.set({ waitingManual: null });
                VA.run.nextAttemptAt = 0;               // don't sit inside a stale gap
                VA.logger.ok('▶ Auto Date Book resumed.');
                if (VA.state.get('running')) tick();    // act immediately, don't wait a tick
            } else {
                VA.logger.warn('⏸ Auto Date Book paused — book manually. Turn it back on to resume.');
            }
        },

        // Push the OTP typed in the panel into the page's OTP field(s) and
        // nudge Verify/Submit. Reuses VA.steps.otp — the exact same filler the
        // run loop uses — so it works whether or not a run is active, and is a
        // graceful no-op (with a note) if the OTP field isn't on this page yet.
        // Wired to the 6-box control: fires automatically on the 6th digit, and
        // manually via the "Verify OTP" button.
        async fillOtp() {
            const code = VA.config.otp();
            if (!code || code.length < 4) { VA.logger.warn('Enter the 6-digit OTP first.'); return; }
            try {
                const res = await VA.steps.otp(ctxNow());
                const st = res && res.status;
                if (st === 'ok') VA.logger.ok('OTP submitted to the page.');
                else if (st === 'wait') VA.logger.info('OTP saved — the OTP field isn’t on this page yet; it will fill automatically when the OTP step appears.');
                else if (st === 'manual') VA.logger.warn('OTP incomplete — ' + ((res && res.note) || 'enter all digits') + '.');
                // 'aborted' → run was cancelled mid-fill; stay silent.
            } catch (e) { VA.logger.err('OTP fill: ' + (e && e.message ? e.message : e)); }
        },

        // Invoked from the panel's Resume button to clear a hard pause once the
        // user has fixed whatever needed a human (upload error / centre mismatch).
        resumeManual() {
            const p = VA.state.get('paused');
            VA.state.set({ paused: null, error: null, waitingManual: null });
            if (p) {
                VA.logger.ok('▶ Resumed by user (was paused at ' + p.stage + ').');
                if (p.stage === 'upload' || p.stage === 'confirm') VA.state.set({ uploadConfirm: 'idle' });
            }
            if (VA.state.get('running')) tick();
        },

        // Skip This Page (Parts 21-26): cancel ONLY the current page's tasks and
        // let the automation continue from the NEXT page. This is NOT Stop (the
        // run keeps going, from where the page lands) and NOT Retry/Resume. It
        // never restarts from page 1, never changes the profile/PDFs/primary/
        // snapshot, and never marks an unfinished upload as successful.
        skipPage() {
            if (!VA.state.get('running')) { VA.logger.warn('Skip: nothing is running.'); return; }
            const stage = VA.state.get('detected') || VA.run.stableStage || 'unknown';

            // 1) Cancel this page's in-flight async work. Abort the signal every
            //    pending step await watches, then bump the generation so any
            //    continuation still in flight fails its isCurrent(gen) check and
            //    bails WITHOUT touching the page (so a half-done upload is never
            //    recorded as done). The run loop timers are left running.
            if (VA.run.ac) { try { VA.run.ac.abort(); } catch (_) {} }
            VA.run.timers.forEach((id) => clearTimeout(id)); VA.run.timers.clear();
            VA.run.observers.forEach((o) => { try { o.disconnect(); } catch (_) {} }); VA.run.observers.clear();
            VA.run.ac = new AbortController();                     // fresh signal for the next page
            VA.state.set({ runId: VA.state.get('runId') + 1 });   // invalidate in-flight continuations
            VA.run.busy = false;    // the aborted tick's finally won't reset it (its gen no longer matches)

            // 2) Clear ONLY per-page latches. Keep attempts/cycle/history and the
            //    profile + run snapshot exactly as they were.
            VA.run.acted = null;
            VA.run.stableStage = null;
            VA.run.stableCount = 0;
            VA.run.queue = [];
            VA.run.current = null;
            VA.run.nextAttemptAt = 0;
            VA.run.monthsScanned = 0;
            VA.run._uploadWaitSlot = null;
            // Release soft waits and the upload-confirm park so neither wedges the
            // next page. uploadConfirm→idle so detectStage stops returning 'confirm'.
            VA.state.set({ waitingManual: null, paused: null, error: null, uploadConfirm: 'idle',
                trying: null, tryOf: 0, tryMax: 0, nextIn: 0 });

            // 3) Mark the skipped stage with the distinct 'skipped' glyph — NOT
            //    'success' — so an unfinished upload is never shown as completed.
            if (stage && stage !== 'unknown') {
                const map = Object.assign({}, VA.state.get('stageStates'));
                map[stage] = 'skipped';
                VA.state.set({ stageStates: map });
            }

            // 4) Latch this page/stage as a no-op until the page actually advances
            //    (tick() clears the latch on the next href change).
            VA.run._skippedHref = location.href;
            VA.run._skippedStage = stage;
            VA.logger.warn('⏭ Skipped "' + stage + '" — automation continues from the next page.');
            if (VA.state.get('running')) tick();
        }
    };
    VA.controller = controller;

    // Payment can arrive from the network hook at any time (R6 primary).
    VA.net.on(function (evt) {
        if (evt && evt.webviewUrl) controller.onPayment(evt.webviewUrl);
    });

    // When the tab comes back to the foreground, refresh the countdown and take
    // a tick at once — the booking loop kept running in the background, so the
    // panel shouldn't sit on a stale "next in Ns" until the next interval fires.
    try {
        document.addEventListener('visibilitychange', function () {
            if (document.hidden) return;
            try { countdown(); } catch (_) {}
            if (VA.state.get('running')) { try { tick(); } catch (_) {} }
        });
    } catch (_) {}
})();
