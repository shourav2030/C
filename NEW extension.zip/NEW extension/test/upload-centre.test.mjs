// ============================================================
//  Regression tests for the two reported failures:
//
//   1) Auto-upload stalled after the primary file. Root cause: the
//      next box was chosen by INDEXING the page's applicant count, which
//      shifts as the page re-renders — so uploadInputAt(slot) kept
//      returning null (or the wrong box) and the loop sat waiting while
//      the manual "Use" button (which just takes the first OPEN box)
//      worked instantly.
//
//      Fix: drive the FILE from a run-local counter (_uploadDone) and the
//      BOX from first-open-box selection — the exact path "Use" uses.
//
//   2) Centre selection not working. Root cause: centreTrigger() accepted
//      the first chevron control that wasn't `.disabled`; the mission row
//      is a control disabled only via Tailwind classes (a <div>/<button>
//      with opacity-50 cursor-not-allowed), so the mission row was picked,
//      its text matched the centre loosely, and selection was skipped.
//
//      Fix: identify the CENTRE control by its own text ("IVAC"/"Select…"),
//      reject control rows that are disabled via classes, and require the
//      "already set" reading to actually look like a centre.
// ============================================================
import test from 'node:test';
import assert from 'node:assert/strict';
import { El, makeDocument, loadModules } from './harness.mjs';

const ctx = () => ({ signal: new AbortController().signal });

// A dropzone: outer container (positioned) wrapping a hidden file input.
function dropzone(root, { top, left, label } = {}) {
    const zone = new El('div', { class: 'w-full h-14 rounded-3xl border-dashed' });
    zone.setRect(top || 0, left || 0);
    if (label) { const s = new El('span'); s.textContent = label; zone.append(s); }
    const inp = new El('input', { type: 'file', class: 'hidden', accept: '.pdf' });
    zone.append(inp);
    root.append(zone);
    return inp;
}

function queued(n) {
    return Array.from({ length: n }, (_, i) => ({
        file: { name: `file${i + 1}.pdf` }, name: `file${i + 1}.pdf`, size: 1024, type: 'application/pdf'
    }));
}

function removeRoot(root, el) {
    root.children = root.children.filter((c) => c !== el);
}

// Drive upload() on the LIVE path with a REAL server confirmation: the page's
// own upload POST is observed as a 2xx a moment after we attach. That is the
// only thing that advances a file now — the old "held in the box" settle (which
// advanced with no server proof) has been removed.
async function uploadConfirmed(VA) {
    VA.net.isLive = () => true;
    const t = setTimeout(() => VA.net._ingest({
        method: 'POST', status: 200,
        url: 'https://api.ivacbd.com/iams/api/v1/file/upload-file-v453'
    }), 30);
    try { return await VA.steps.upload(ctx()); }
    finally { clearTimeout(t); }
}

// ------------------------------------------------------------
//  Box selection
// ------------------------------------------------------------
test('strictUploadInput: first OPEN box in primary-first visual order', () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const p = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant' });
    dropzone(root, { top: 120, left: 0, label: 'Additional File 1' });
    assert.equal(VA.site.strictUploadInput(), p, 'primary is first while it is open');
    p.files = [{ name: 'x.pdf' }];
    assert.notEqual(VA.site.strictUploadInput(), p, 'a filled box is skipped');
});

test('rawUploadInput: first non-panel, non-filled input, ignoring the locked heuristic', () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const p = dropzone(root, { top: 40, left: 0, label: 'Primary' });
    p.parentNode.setAttribute('class', 'w-full h-14 cursor-not-allowed opacity-60');
    assert.equal(VA.site.strictUploadInput(), null, 'locked box is not a strict pick');
    assert.equal(VA.site.rawUploadInput(), p, 'loose pick ignores the locked heuristic');
    p.files = [{ name: 'x.pdf' }];
    const a = dropzone(root, { top: 130, left: 0, label: 'Additional File 1' });
    assert.equal(VA.site.rawUploadInput(), a, 'filled boxes are still skipped');
});

test('upload selectors skip disabled duplicate inputs', () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const disabled = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant' });
    disabled.setAttribute('disabled', '');
    const enabled = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant' });

    assert.equal(VA.site.strictUploadInput(), enabled);
    assert.equal(VA.site.rawUploadInput(), enabled);
});

test('attachFile rejects a disabled input without populating it', () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const input = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant' });
    input.setAttribute('aria-disabled', 'true');

    const result = VA.attachFile(input, queued(1)[0].file);

    assert.equal(result.ok, false);
    assert.equal(input.files, null);
});

test('isControlDisabled: a control disabled only via Tailwind classes counts as disabled', () => {
    const { doc } = makeDocument();
    const VA = loadModules(doc);
    assert.equal(VA.dom.isControlDisabled(new El('div', { class: 'opacity-50 cursor-not-allowed' })), true);
    assert.equal(VA.dom.isControlDisabled(new El('button', { disabled: 'true' })), true);
    assert.equal(VA.dom.isControlDisabled(new El('button', { class: 'w-full text-left' })), false);
});

// ------------------------------------------------------------
//  Upload — attaches every file automatically, primary first
// ------------------------------------------------------------
test('upload: stale primary lock classes use the ordered PRIMARY, never raw DOM order', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    // Additional input is DOM-first, but PRIMARY is visually above it and must win.
    const extra = dropzone(root, { top: 140, left: 0, label: 'Additional File 1' });
    const primary = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    extra.parentNode.setAttribute('class', 'opacity-60 cursor-not-allowed');
    primary.parentNode.setAttribute('class', 'opacity-60 cursor-not-allowed');
    VA.verify._solverOff = true;
    VA.config._files = queued(1);
    VA.run._uploadDone = 0;

    const r = await uploadConfirmed(VA);

    assert.equal(r.status, 'ok');
    assert.equal(primary.files[0].name, 'file1.pdf', 'ordered primary gets the primary file');
    assert.equal(extra.files, null, 'raw DOM-first additional box is untouched');
});

test('upload: stale lock classes on file 2 use the loose fallback immediately', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const primary = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    primary.files = [{ name: 'file1.pdf' }];
    const second = dropzone(root, { top: 120, left: 0, label: 'Additional File 1' });
    second.parentNode.setAttribute('class', 'opacity-60 cursor-not-allowed');
    VA.verify._solverOff = true;
    VA.config._files = queued(2);
    VA.run._uploadDone = 1;

    const r = await uploadConfirmed(VA);

    assert.equal(r.status, 'ok');
    assert.equal(VA.run._uploadDone, 2);
    assert.equal(second.files[0].name, 'file2.pdf');
});

test('upload: missing next slot returns wait immediately instead of blocking 20 seconds', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const primary = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    primary.files = [{ name: 'file1.pdf' }];
    VA.verify._solverOff = true;
    VA.config._files = queued(2);
    VA.run._uploadDone = 1;
    const startedAt = Date.now();

    const result = await VA.steps.upload(ctx());

    assert.equal(result.status, 'wait');
    assert.ok(Date.now() - startedAt < 500, 'controller regains control promptly');
    assert.equal(VA.run._uploadDone, 1);
});
test('upload: primary → file 2 → file 3 → file 4, strictly in order', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const p = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    const a = dropzone(root, { top: 120, left: 0, label: 'Additional File 1' });
    const b = dropzone(root, { top: 200, left: 0, label: 'Additional File 2' });
    const c = dropzone(root, { top: 280, left: 0, label: 'Additional File 3' });
    VA.verify._solverOff = true;
    VA.config._files = queued(4);
    VA.run._uploadDone = 0;

    let r = await uploadConfirmed(VA);
    assert.equal(r.status, 'ok');
    assert.equal(r.more, true);
    assert.equal(VA.run._uploadDone, 1);
    assert.equal(p.files[0].name, 'file1.pdf', 'PRIMARY receives file 1 first');

    r = await uploadConfirmed(VA);
    assert.equal(VA.run._uploadDone, 2);
    assert.equal(a.files[0].name, 'file2.pdf');
    assert.equal(r.more, true);

    r = await uploadConfirmed(VA);
    assert.equal(VA.run._uploadDone, 3);
    assert.equal(b.files[0].name, 'file3.pdf');
    assert.equal(r.more, true);

    r = await uploadConfirmed(VA);
    assert.equal(VA.run._uploadDone, 4);
    assert.equal(c.files[0].name, 'file4.pdf');
    assert.equal(r.more, false);
});

test('upload: keeps going when the page REMOVES a filled box (the stall regression)', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const p = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant' });
    const a = dropzone(root, { top: 120, left: 0, label: 'Additional File 1' });
    dropzone(root, { top: 200, left: 0, label: 'Additional File 2' });
    VA.verify._solverOff = true;
    VA.config._files = queued(3);
    VA.run._uploadDone = 0;

    await uploadConfirmed(VA);
    assert.equal(VA.run._uploadDone, 1);

    // The page re-renders: the accepted primary dropzone disappears. Indices
    // now shift — index 1 would be applicant 3 — but "first open box" still
    // points at applicant 2. This is precisely what the old index math got wrong.
    removeRoot(root, p.parentNode);

    const r = await uploadConfirmed(VA);
    assert.equal(VA.run._uploadDone, 2, 'file 2 still attaches after the box was removed');
    assert.ok(a.files && a.files.length, 'it went to applicant 2, not applicant 3');
});

// Only the PRIMARY dropzone is locked behind Cloudflare; files 2-N attach to
// already-unlocked boxes exactly like the manual "Use" button. Running the heavy
// CF gate before them stalled the run (multi-second solve churn on a fresh
// challenge while the box sat ready — the "Waiting for upload slot 2 to unlock…"
// video). This pins that ONLY slot 0 enters the gate.
test('upload: only the PRIMARY waits behind the Cloudflare gate, files 2-N do not', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const p = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    const a = dropzone(root, { top: 120, left: 0, label: 'Additional File 1' });
    VA.verify._solverOff = true;
    VA.config._files = queued(2);
    VA.run._uploadDone = 0;

    // Spy on the gate, recording which slot was active each time it is entered.
    const gateSlots = [];
    const realGate = VA.verify.gate.bind(VA.verify);
    VA.verify.gate = (opts) => { gateSlots.push(VA.run._uploadDone); return realGate(opts); };

    await uploadConfirmed(VA);
    assert.equal(VA.run._uploadDone, 1);
    assert.ok(p.files && p.files.length, 'the primary attaches first');

    await uploadConfirmed(VA);
    assert.equal(VA.run._uploadDone, 2, 'file 2 attaches automatically');
    assert.ok(a.files && a.files.length);

    assert.deepEqual(gateSlots, [0], 'gate entered ONLY for the primary (slot 0), never for file 2');
});

// ------------------------------------------------------------
//  Network-verified upload — advance ONLY when the server confirms
//  (the page's own upload_file 2xx), and auto re-click "Use" until it
//  does. On the live site VA.net.isLive() is true from the first
//  request, so the degraded "held, no error" settle never runs; these
//  tests force it true to exercise the real, server-gated path.
// ------------------------------------------------------------
test('upload: on the LIVE path a file advances ONLY after the server upload POST, not on our attach', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const p = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    VA.verify._solverOff = true;
    VA.net.isLive = () => true;                 // force the live path (disable the degraded settle)
    VA.config._files = queued(1);
    VA.run._uploadDone = 0;

    let settled = false;
    const pr = VA.steps.upload(ctx()).then((r) => { settled = true; return r; });

    // Our File attaches almost immediately, but with no upload POST the run must
    // NOT advance — it waits for the server's own acceptance.
    await new Promise((r) => setTimeout(r, 300));
    assert.ok(p.files && p.files.length, 'the primary file did attach');
    assert.equal(settled, false, 'upload does NOT advance on our attach alone');
    assert.equal(VA.run._uploadDone, 0);

    // The page now POSTs the file and the server accepts it (200).
    VA.net._ingest({ method: 'POST', status: 200, url: 'https://x.ivacbd.com/iams/api/v1/file/upload_file_v321' });

    const r = await pr;
    assert.equal(r.status, 'ok');
    assert.equal(VA.run._uploadDone, 1, 'advances the instant the server confirms');
    assert.equal(VA.net.uploads, 1, 'the upload_file 2xx was counted; over-view would not be');
});

test('upload: a page-refresh POST (over-view) does NOT count as an upload confirmation', async () => {
    const { doc } = makeDocument();
    const VA = loadModules(doc);
    const base = VA.net.uploads;
    VA.net._ingest({ method: 'POST', status: 200, url: 'https://x.ivacbd.com/iams/api/v1/file/over-view-v421' });
    assert.equal(VA.net.uploads, base, 'over-view-v421 is a refresh, not an upload');
    VA.net._ingest({ method: 'POST', status: 200, url: 'https://x.ivacbd.com/iams/api/v1/file/upload_file_v321' });
    assert.equal(VA.net.uploads, base + 1, 'only upload_file counts');
});

test('upload: when the server never confirms, it AUTO re-clicks "Use" until a POST arrives', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const a = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    VA.verify._solverOff = true;
    VA.net.isLive = () => true;                 // live path — no degraded auto-confirm
    VA.config._files = queued(1);
    VA.config._data.uploadConfirmMs = 500;      // short confirm window so the re-click happens fast
    VA.run._uploadDone = 0;

    let reAttach = 0;
    const realWaiting = VA.logger.waiting.bind(VA.logger);
    VA.logger.waiting = (m) => { if (/re-click|re-attach/i.test(String(m))) reAttach++; return realWaiting(m); };

    // No POST for the first window (→ at least one auto re-click), then the
    // server accepts and the file is confirmed.
    setTimeout(() => VA.net._ingest({
        method: 'POST', status: 200, url: 'https://x.ivacbd.com/iams/api/v1/file/upload_file_v321'
    }), 700);

    const r = await VA.steps.upload(ctx());
    assert.equal(r.status, 'ok');
    assert.equal(VA.run._uploadDone, 1);
    assert.ok(reAttach >= 1, 'it re-clicked "Use" at least once while unconfirmed');
    assert.ok(a.files && a.files.length, 'the file is attached');
});

test('upload: while an upload is IN FLIGHT it WAITS (no duplicate re-click), then confirms on completion', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const a = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    VA.verify._solverOff = true;
    VA.net.isLive = () => true;                 // live path — no degraded auto-confirm
    VA.config._files = queued(1);
    VA.config._data.uploadConfirmMs = 400;      // short confirm window so the first window expires quickly
    VA.run._uploadDone = 0;

    let waitedInFlight = 0, reClicked = 0;
    const realWaiting = VA.logger.waiting.bind(VA.logger);
    VA.logger.waiting = (m) => {
        const s = String(m);
        if (/in progress/i.test(s)) waitedInFlight++;   // the intelligent "still uploading" wait
        if (/re-click|re-attach/i.test(s)) reClicked++;  // a duplicate "Use" click (must NOT happen here)
        return realWaiting(s);
    };

    // Before the first confirm window expires, the page's upload_file POST is
    // STARTED (in flight) — the server is just slow. It only completes (200)
    // well AFTER that window, so a naive loop would have re-clicked by then.
    setTimeout(() => VA.net._ingest({
        phase: 'start', inflight: 1, method: 'POST', url: 'https://x.ivacbd.com/iams/api/v1/file/upload_file_v321'
    }), 80);
    setTimeout(() => VA.net._ingest({
        inflight: 0, method: 'POST', status: 200, url: 'https://x.ivacbd.com/iams/api/v1/file/upload_file_v321'
    }), 650);

    const r = await VA.steps.upload(ctx());
    assert.equal(r.status, 'ok', 'confirmed once the in-flight upload completed');
    assert.equal(VA.run._uploadDone, 1);
    assert.ok(waitedInFlight >= 1, 'it WAITED on the in-flight upload instead of re-clicking');
    assert.equal(reClicked, 0, 'it did NOT re-click "Use" while the upload was genuinely in progress');
    assert.ok(a.files && a.files.length, 'the file stayed attached (not re-fired)');
});

test('upload: repeated red errors retry the SAME file twice, then pause without advancing', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const primary = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    VA.verify._solverOff = true;
    VA.net.isLive = () => true;
    VA.config._files = queued(1);
    VA.config._data.uploadConfirmMs = 500;
    VA.run._uploadDone = 0;

    // Keep production's bounded retry policy but skip the real 1.5s backoff in
    // this unit test. The stale red node deliberately remains visible.
    const realSleep = VA.dom.sleep;
    VA.dom.sleep = (ms, signal) => realSleep(ms === 1500 ? 1 : ms, signal);
    let retries = 0;
    const realWaiting = VA.logger.waiting.bind(VA.logger);
    VA.logger.waiting = (m) => {
        if (/retrying the same file/i.test(String(m))) retries++;
        return realWaiting(m);
    };
    setTimeout(() => {
        const e = new El('div', { class: 'text-red-500' });
        e.textContent = 'PDF file is too large — upload failed.';
        root.append(e);
    }, 120);

    const r = await VA.steps.upload(ctx());

    assert.equal(r.status, 'error', 'third failure pauses after the two automatic retries');
    assert.equal(retries, 2, 'exactly two bounded retries were attempted');
    assert.equal(VA.run._uploadRedRetry.count, 2);
    assert.equal(VA.run._uploadDone, 0, 'red retries never advance to the next file');
    assert.equal(primary.files[0].name, 'file1.pdf', 'every retry remains on the primary file');
});

// ------------------------------------------------------------
//  Centre — the CENTRE control is picked, never the mission row
// ------------------------------------------------------------
test('centre: picks the centre control, not the disabled mission row', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    VA.verify._solverOff = true;
    VA.config.set({ mission: 'Dhaka', centre: 'IVAC,Dhaka(JFP)' });

    let missionClicked = false;
    let centreClicked = false;

    // Mission row — disabled ONLY via classes (the shape that fooled the old
    // `.disabled` check), carrying its own chevron like the centre control.
    const mission = new El('button', { class: 'w-full h-25 opacity-50 cursor-not-allowed', disabled: 'true' });
    const mText = new El('span'); mText.textContent = 'Dhaka'; mission.append(mText);
    mission.append(new El('svg', { class: 'lucide lucide-chevron-down' }));
    mission.click = () => { missionClicked = true; };
    root.append(mission);

    // Centre control — text names it, and clicking opens the dropdown.
    const centre = new El('button', { class: 'w-full h-25 border rounded-3xl' });
    const cText = new El('span'); cText.textContent = 'Select IVAC Center'; centre.append(cText);
    centre.append(new El('svg', { class: 'lucide lucide-chevron-down' }));
    centre.click = () => {
        centreClicked = true;
        const opt = new El('button', { class: 'w-full px-6 py-4 text-left' });
        opt.textContent = 'IVAC, Dhaka(JFP)';
        root.append(opt);
    };
    root.append(centre);

    // Abort shortly after the click so the test stays fast; the assertion is
    // WHICH control was opened.
    const ac = new AbortController();
    setTimeout(() => ac.abort(), 300);
    await VA.steps.centre({ signal: ac.signal });

    assert.equal(missionClicked, false, 'the disabled mission row must never be treated as the centre control');
    assert.equal(centreClicked, true, 'the centre dropdown must actually be opened');
});

// ------------------------------------------------------------
//  Upload completion — applicant ROWS are not uploaded files
// ------------------------------------------------------------
//  The page renders one row (h-[82px]) per applicant and can render them
//  ALL the moment the primary lands. Those rows are not proof a file
//  reached the server. The old completion check trusted
//  `Math.max(uploadedCards(), filledUploadInputs())` and therefore clicked
//  "Confirm All Information is Correct" after a single PDF, silently
//  skipping every remaining file. Completion must require the files WE
//  attached/confirmed — never the page's static applicant rows.
test('upload: pre-rendered applicant rows never confirm early — every file still uploads', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const p = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    const a = dropzone(root, { top: 120, left: 0, label: 'Additional File 1' });
    dropzone(root, { top: 200, left: 0, label: 'Additional File 2' });
    dropzone(root, { top: 280, left: 0, label: 'Additional File 3' });

    // A visible applicant row for EVERY applicant, present before any upload.
    ['Primary Applicant', 'Applicant 02', 'Applicant 03', 'Applicant 04'].forEach((t, i) => {
        const row = new El('div', { role: 'button', class: 'w-full h-[82px] flex' });
        row.setRect(400 + i * 90, 0);
        const s = new El('span'); s.textContent = t; row.append(s);
        root.append(row);
    });
    assert.ok(VA.site.uploadedCards() >= 4, 'the rows are visible to uploadedCards()');

    VA.verify._solverOff = true;
    VA.config._files = queued(4);
    VA.run._uploadDone = 0;

    let confirmed = false;
    const realOk = VA.logger.ok.bind(VA.logger);
    VA.logger.ok = (m) => { if (/confirming automatically/i.test(String(m))) confirmed = true; return realOk(m); };

    const r1 = await uploadConfirmed(VA);
    assert.equal(r1.status, 'ok');
    assert.equal(VA.run._uploadDone, 1, 'the primary uploaded');
    assert.equal(confirmed, false, 'must NOT confirm while 3 files remain');
    assert.equal(VA.state.get('uploadedCount'), 1, 'progress counts the file, not the 4 applicant rows');

    const r2 = await uploadConfirmed(VA);
    assert.equal(r2.status, 'ok');
    assert.equal(VA.run._uploadDone, 2, 'file 2 still uploads instead of confirming');
    assert.equal(confirmed, false, 'still must NOT confirm');
    assert.ok(p.files && p.files.length, 'primary received file 1');
    assert.ok(a.files && a.files.length, 'file 2 went to the next box');
});

// A STRAGGLER card from the file we just committed must never confirm the NEXT
// file. This is the real-world skipped-upload regression: file N's applicant
// card renders a beat AFTER file N+1 has started, its count crossed the old
// `uploadedCards()+1` target, and file N+1 advanced WITHOUT ever being uploaded
// (the run logged "verified — a new applicant card rendered" while the server
// never received that PDF). The fix anchors the card target on the committed
// count (`slot`), so only a card that belongs to THIS file can reach it.
test('upload: a LATE card from the previous file does NOT confirm the next file', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const p = dropzone(root, { top: 40, left: 0, label: 'Primary Applicant Document' });
    const a = dropzone(root, { top: 120, left: 0, label: 'Additional File 1' });
    const b = dropzone(root, { top: 200, left: 0, label: 'Additional File 2' });
    p.files = [{ name: 'file1.pdf' }];
    a.files = [{ name: 'file2.pdf' }];          // files 1 & 2 already committed + attached
    VA.verify._solverOff = true;
    VA.net.isLive = () => true;
    VA.config._files = queued(3);
    VA.run._uploadDone = 2;                     // → this tick uploads file 3 (slot 2)
    VA.config._data.uploadConfirmMs = 300;      // short confirm window

    const addCard = (label) => {
        const row = new El('div', { role: 'button', class: 'w-full h-[82px] flex' });
        row.setRect(600, 0);
        const s = new El('span'); s.textContent = label; row.append(s);
        root.append(row);
    };
    // Only ONE committed card has rendered so far — file 2's card is still late.
    addCard('Applicant 02');
    assert.equal(VA.site.uploadedCards(), 1, 'the page lags one card behind');

    let settled = false;
    const pr = VA.steps.upload(ctx()).then((r) => { settled = true; return r; });

    // The commit for file 2 lands as a card DURING file 3's window (the straggler).
    await new Promise((r) => setTimeout(r, 80));
    addCard('Applicant 03');
    assert.equal(VA.site.uploadedCards(), 2, 'the straggler card is now visible');

    await new Promise((r) => setTimeout(r, 260));   // past one confirm window
    assert.equal(settled, false, 'the straggler card must NOT confirm file 3');
    assert.equal(VA.run._uploadDone, 2, 'file 3 has not advanced yet');

    // NOW the server actually accepts file 3's own upload.
    VA.net._ingest({
        method: 'POST', status: 200,
        url: 'https://api.ivacbd.com/iams/api/v1/file/upload-file-v453'
    });

    const r = await pr;
    assert.equal(r.status, 'ok');
    assert.equal(VA.run._uploadDone, 3, 'file 3 advances only on its OWN upload');
    assert.ok(b.files && b.files.length, 'file 3 really attached and was uploaded');
});

// ------------------------------------------------------------
//  Cloudflare master switch (Config → Auto Solve Cloudflare)
// ------------------------------------------------------------
test('gate: Auto Solve Cloudflare OFF is a no-op — no wait, no solve, no manual alert', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    // A genuine challenge is on the page (inline checkbox markup).
    const label = new El('label', { class: 'Nwax7' });
    root.append(label);
    assert.equal(VA.verify.hasWidget(), true, 'a challenge is actually present');

    VA.config.setToggle('cf', false);
    assert.equal(VA.verify.enabled(), false);

    const startedAt = Date.now();
    const res = await VA.verify.gate({ timeout: 60000, successWhen: () => false });

    assert.equal(res.ok, true, 'readiness is treated as satisfied');
    assert.equal(res.reason, 'cf-off');
    assert.ok(Date.now() - startedAt < 200, 'it does not wait for a solve');
    assert.notEqual(VA.state.get('turnstile'), 'manual needed', 'never asks a human');
});

test('gate: Auto Solve Cloudflare ON still drives the normal check', async () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const label = new El('label', { class: 'Nwax7' });
    root.append(label);
    VA.verify._solverOff = true;              // no 2Captcha in the sandbox
    assert.equal(VA.verify.enabled(), true, 'ON by default');

    // successWhen becomes true after a moment — the gate should observe it and pass.
    let ready = false;
    setTimeout(() => { ready = true; }, 60);
    const res = await VA.verify.gate({ timeout: 4000, successWhen: () => ready });

    assert.equal(res.ok, true);
    assert.notEqual(res.reason, 'cf-off', 'the off short-circuit is not taken');
    assert.equal(VA.state.get('turnstile'), 'verified ✓');
});

