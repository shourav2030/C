// ============================================================
//  OTP anti-retry guard — a rejected OTP must never be submitted
//  twice (repeated wrong codes get the account blocked). Covers the
//  policy object, the fill step's "did we actually submit?" signal,
//  the lock-banner detector, and the relay's discard().
// ============================================================
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeDocument, loadModulesFull } from './harness.mjs';

const INSTALL = '123e4567-e89b-42d3-a456-426614174000';

// ---------- policy object ----------
function policy() {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc, { modules: ['core.js'] });
    VA.otpGuard.reset();
    return VA.otpGuard;
}

test('a fresh guard has nothing tried and is not exhausted', () => {
    const g = policy();
    assert.equal(g.attempts(), 0);
    assert.equal(g.exhausted(), false);
    assert.equal(g.pendingSubmit(), false);
    assert.equal(g.alreadyTried('123456'), false);
});

test('a submitted code is remembered and can never be re-sent', () => {
    const g = policy();
    g.markSubmitted('123456', 1000);
    assert.equal(g.alreadyTried('123456'), true);
    assert.equal(g.pendingSubmit(), true);
    assert.equal(g.attempts(), 1);
});

test('grace window protects a just-submitted code, then lapses', () => {
    const g = policy();
    g.markSubmitted('123456', 1000);
    assert.equal(g.awaitingConfirm(1000 + g.GRACE_MS - 1), true, 'inside the window');
    assert.equal(g.awaitingConfirm(1000 + g.GRACE_MS), false, 'window lapsed → judged');
});

test('discarding a rejected code clears the pending latch but keeps it blocked', () => {
    const g = policy();
    g.markSubmitted('123456', 1000);
    g.clearPending();
    assert.equal(g.pendingSubmit(), false, 'no longer treated as in-flight');
    assert.equal(g.alreadyTried('123456'), true, 'still refused forever');
    assert.equal(g.attempts(), 1, 'the try is still counted');
});

test('the guard gives up after the cap instead of hammering the login', () => {
    const g = policy();
    assert.equal(g.MAX_TRIES, 3);
    g.markSubmitted('111111'); g.clearPending();
    g.markSubmitted('222222'); g.clearPending();
    assert.equal(g.exhausted(), false);
    g.markSubmitted('333333'); g.clearPending();
    assert.equal(g.attempts(), 3);
    assert.equal(g.exhausted(), true);
});

test('reset clears everything for a fresh run', () => {
    const g = policy();
    g.markSubmitted('123456');
    g.reset();
    assert.equal(g.attempts(), 0);
    assert.equal(g.pendingSubmit(), false);
    assert.equal(g.alreadyTried('123456'), false);
});

// ---------- fill step ----------
function stepsBoot(ids) {
    const { doc } = makeDocument();
    const cells = ids.map((id) => {
        const el = doc.createElement('input');
        el.setAttribute('id', id);
        doc.body.append(el);
        return el;
    });
    const btn = doc.createElement('button');
    btn.textContent = 'Verify';
    doc.body.append(btn);
    const { VA } = loadModulesFull(doc, { modules: ['core.js', 'verification.js', 'steps.js'] });
    VA.logger = { info() {}, ok() {}, warn() {}, err() {}, waiting() {} };
    return { VA, cells, btn };
}

test('otp(): a multi-box form auto-submits, and stale digits are wiped first', async () => {
    const { VA, cells } = stepsBoot(['otp-0', 'otp-1', 'otp-2', 'otp-3', 'otp-4', 'otp-5']);
    cells.forEach((c) => { c.value = '9'; });          // leftovers from a rejected code
    VA.config.setOtp('123456');

    const res = await VA.steps.otp({});
    assert.equal(res.status, 'ok');
    assert.equal(res.submitted, true, 'multi-box OTP forms auto-submit');
    assert.deepEqual(cells.map((c) => c.value), ['1', '2', '3', '4', '5', '6'],
        'each cell holds exactly one digit of the new code, none of the old');
});

test('otp(): a single field with no clickable button is NOT reported as submitted', async () => {
    const { doc } = makeDocument();
    const el = doc.createElement('input');
    el.setAttribute('id', 'otp-0');
    doc.body.append(el);
    const { VA } = loadModulesFull(doc, { modules: ['core.js', 'verification.js', 'steps.js'] });
    VA.logger = { info() {}, ok() {}, warn() {}, err() {}, waiting() {} };
    VA.config.setOtp('4321');

    const res = await VA.steps.otp({});
    assert.equal(res.status, 'ok');
    assert.equal(res.submitted, false, 'no auto-submit and no button → not a real attempt');
});

test('otp(): an incomplete code asks for manual entry', async () => {
    const { VA } = stepsBoot(['otp-0', 'otp-1', 'otp-2', 'otp-3', 'otp-4', 'otp-5']);
    VA.config.setOtp('');
    const res = await VA.steps.otp({});
    assert.equal(res.status, 'manual');
});

// ---------- lock-banner detector ----------
function lockedBoot(text) {
    const { doc } = makeDocument();
    if (text) {
        const n = doc.createElement('div');
        n.setAttribute('class', 'error');
        n.textContent = text;
        doc.body.append(n);
    }
    const { VA } = loadModulesFull(doc, { modules: ['core.js', 'verification.js', 'steps.js'] });
    return VA;
}

test('otpLockedText() detects an explicit lock/throttle banner', () => {
    assert.match(lockedBoot('Too many attempts. Please try again later.').steps.otpLockedText(), /too many attempts/i);
    assert.match(lockedBoot('Your account has been locked.').steps.otpLockedText(), /locked/i);
});

test('otpLockedText() ignores an ordinary page', () => {
    assert.equal(lockedBoot('').steps.otpLockedText(), '');
    assert.equal(lockedBoot('Enter the 6-digit code from SMS').steps.otpLockedText(), '');
});

// ---------- relay discard ----------
function relayBoot(responses) {
    const calls = [];
    const { doc } = makeDocument();
    const loaded = loadModulesFull(doc, {
        seed: { ivacInstallId: INSTALL },
        modules: ['core.js', 'otp-relay.js'],
        sendMessage(message, callback) {
            calls.push(message);
            const next = responses.shift();
            callback(typeof next === 'function' ? next(message) : next);
        },
    });
    loaded.VA.config._data.phone = '01712345678';
    return { ...loaded, calls };
}

test('discard() consumes a rejected delivery server-side and drops it locally', async () => {
    const { VA, calls } = relayBoot([
        { ok: true, data: { success: true, otp: '123456', deliveryId: 'd-1', pollAfterMs: 2000 } },
        { ok: true, data: { success: true, acknowledged: true } },
    ]);
    assert.equal(await VA.otpRelay.tryFetch(), true);
    assert.equal(VA.config.otp(), '123456');

    assert.equal(await VA.otpRelay.discard(), true);
    assert.equal(calls[1].endpoint, '/api/otp/ack', 'the spent delivery is acked so it is never served again');
    assert.equal(VA.config.otp(), '', 'the rejected code is gone');
    assert.equal(VA.otpRelay.pending(), null, 'the lease is released');
});

test('discard() is a safe no-op when nothing is leased (manually typed code)', async () => {
    const { VA, calls } = relayBoot([]);
    VA.config.setOtp('999999');
    assert.equal(await VA.otpRelay.discard(), false);
    assert.equal(calls.length, 0, 'no backend call for a manually typed code');
    assert.equal(VA.config.otp(), '', 'the code is still cleared locally');
});
