// Behavioral tests for the two highest-risk logic changes:
//   1. uploadInputs() orders primary first, then visual top→bottom/left→right
//   2. centreLocation() + matchName() flexible centre matching
import test from 'node:test';
import assert from 'node:assert/strict';
import { El, makeDocument, loadModules } from './harness.mjs';

// Compare node lists by identity (deepStrictEqual can't walk circular parentNode refs).
// Array.from (main realm) so the result isn't a VM-realm Array with a
// foreign prototype, which deepStrictEqual rejects even when contents match.
const ids = (arr) => Array.from(arr, (n) => n.__id);

function fileInput() {
    const inp = new El('input', { type: 'file', class: 'hidden', accept: '.pdf' });
    return inp;
}
// A dropzone: outer div (positioned) wrapping the hidden input + a label span.
function dropzone(root, { top, left, label }) {
    const zone = new El('div', { class: 'w-full h-14 rounded-3xl border-dashed' });
    zone.setRect(top, left);
    if (label) { const s = new El('span'); s.textContent = label; zone.append(s); }
    const inp = fileInput();
    zone.append(inp);
    root.append(zone);
    return inp;
}

test('uploadInputs: primary label pinned to slot 0 even when DOM-last', () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    // DOM order: three "additional" zones first, primary LAST — but primary
    // sits visually at the top of the screen.
    const add1 = dropzone(root, { top: 200, left: 0, label: 'Additional File 1' });
    const add2 = dropzone(root, { top: 200, left: 120, label: 'Additional File 2' });
    const add3 = dropzone(root, { top: 200, left: 240, label: 'Additional File 3' });
    const prim = dropzone(root, { top: 60, left: 0, label: 'Primary Applicant Document' });
    const ordered = VA.site.uploadInputs();
    assert.equal(ordered.length, 4);
    assert.equal(ordered[0], prim, 'primary must be slot 0');
    assert.deepEqual(ids(ordered.slice(1)), ids([add1, add2, add3]), 'rest left→right by position');
});

test('uploadInputs: no primary label falls back to pure visual order', () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const top = dropzone(root, { top: 50, left: 0, label: 'Document A' });
    const midL = dropzone(root, { top: 150, left: 0, label: 'Document B' });
    const midR = dropzone(root, { top: 150, left: 200, label: 'Document C' });
    const ordered = VA.site.uploadInputs();
    assert.deepEqual(ids(ordered), ids([top, midL, midR]));
});

test('uploadInputs: excludes inputs inside the extension panel host', () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const prim = dropzone(root, { top: 40, left: 0, label: 'Primary' });
    const host = new El('div', { id: 'va-panel-host' });
    const panelInput = fileInput();
    host.append(panelInput);
    root.append(host);
    const ordered = VA.site.uploadInputs();
    assert.deepEqual(ids(ordered), ids([prim]), 'panel file picker must be ignored');
});

test('filledUploadInputs / countApplicants track attached files', () => {
    const { doc, root } = makeDocument();
    const VA = loadModules(doc);
    const prim = dropzone(root, { top: 40, left: 0, label: 'Primary' });
    dropzone(root, { top: 120, left: 0, label: 'Additional File 1' });
    assert.equal(VA.site.filledUploadInputs(), 0);
    prim.files = [{ name: 'primary.pdf' }];
    assert.equal(VA.site.filledUploadInputs(), 1);
    assert.equal(VA.site.countApplicants(), 1);
});

test('matchName tolerant of punctuation / Chattogram spelling', () => {
    const { doc } = makeDocument();
    const VA = loadModules(doc);
    const m = VA.dom.matchName.bind(VA.dom);
    assert.ok(m('IVAC, Dhaka (JFP)', 'IVAC,Dhaka(JFP)'));
    assert.ok(m('IVAC, Chattogram', 'IVAC,Chittagong'), 'spelling canonicalized');
    assert.ok(!m('IVAC, Sylhet', 'IVAC,Dhaka(JFP)'));
});

test('classifyDatePill by color token / disabled', () => {
    const { doc } = makeDocument();
    const VA = loadModules(doc);
    const sel = new El('button', { class: 'w-9 h-9 bg-[#FF671F] text-white' });
    const avail = new El('button', { class: 'border border-[#004638] text-[#004638]' });
    const un = new El('button', { class: 'text-[#B0B0B0] cursor-not-allowed', disabled: true });
    assert.equal(VA.site.classifyDatePill(sel), 'selected');
    assert.equal(VA.site.classifyDatePill(avail), 'available');
    assert.equal(VA.site.classifyDatePill(un), 'unavailable');
});

test('config exposes the reduced timing values', () => {
    const { doc } = makeDocument();
    const VA = loadModules(doc);
    const g = (k) => VA.config.get(k);
    assert.equal(g('maxTriesPerDate'), 3);
    assert.equal(g('attemptTimeout'), 20000);
    assert.equal(g('verifyTimeout'), 45000);
    assert.equal(g('settleAfterVerify'), 1500);
    assert.equal(g('gap'), 2000);
    // The per-file upload confirmation window must stay short: a ready next
    // box must never be blocked for the old 20s.
    assert.ok(g('uploadConfirmMs') <= 5000, 'upload wait must be short, not the old 20s stall');
    // No lingering multi-minute default anywhere in the timing config.
    for (const k of ['gap', 'attemptTimeout', 'verifyTimeout', 'settleAfterVerify', 'backoff429', 'uploadConfirmMs']) {
        assert.ok(g(k) <= 45000, k + ' must not be a multi-minute delay');
    }
});

// The event-driven verify primitive behind the faster, card-gated upload
// (steps.js waits for the applicant card via VA.dom.waitForEvent). The harness
// MutationObserver is a no-op, so these exercise the resolve / timeout / abort
// contract via its safety poll — same guarantees as waitFor, lower latency live.
test('waitForEvent: resolves with the predicate value once it turns truthy', async () => {
    const { doc } = makeDocument();
    const VA = loadModules(doc);
    let n = 0;
    const res = await VA.dom.waitForEvent(() => (++n >= 3 ? 'card' : false),
        { timeout: 1000, fallback: 5 });
    assert.equal(res, 'card', 'returns the predicate value the moment it passes');
});

test('waitForEvent: resolves null on timeout when the predicate never passes', async () => {
    const { doc } = makeDocument();
    const VA = loadModules(doc);
    const res = await VA.dom.waitForEvent(() => false, { timeout: 40, fallback: 5 });
    assert.equal(res, null, 'null when acceptance is never observed');
});

test('waitForEvent: resolves null immediately when the signal is already aborted', async () => {
    const { doc } = makeDocument();
    const VA = loadModules(doc);
    const ac = new AbortController();
    ac.abort();
    const res = await VA.dom.waitForEvent(() => true, { signal: ac.signal, timeout: 1000, fallback: 5 });
    assert.equal(res, null, 'an aborted run never reports a false acceptance');
});
