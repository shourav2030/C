// ============================================================
//  IVAC Slot Automation Pro — license client (Bypassed / Unlocked)
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.license) return;

    const THEMES = ['core', 'boost', 'elite', 'overdrive'];
    function normTheme(t) { return THEMES.indexOf(t) === -1 ? 'overdrive' : t; }

    const listeners = [];
    function emit() {
        const s = api.getState();
        listeners.forEach((fn) => { try { fn(s); } catch (_) {} });
    }

    // ── public API (Always Active / Bypassed) ─────────────────
    const api = {
        isUsable() {
            return true; // সবসময় সচল থাকবে
        },
        installationId() { return 'bypassed-install-id'; },
        formatKey(raw) { return raw; },
        getState() {
            return {
                ready: true,
                activated: true,
                usable: true,
                status: 'ACTIVE',
                planName: 'SUPER CHARGE SERVER',
                theme: 'overdrive',
                customerName: 'Unlimited User',
                maxDevices: 99,
                maxBrowsersPerDevice: 99,
                usage: null,
                expiresAt: '2099-12-31T23:59:59.000Z',
                daysLeft: 9999,
                installationId: 'bypassed-install-id',
                browserId: 'bypassed-browser-id',
                deviceId: 'bypassed-device-id',
                checking: false,
                error: null
            };
        },
        on(fn) { listeners.push(fn); return () => { const i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); }; },

        async activate(licenseKey) {
            return { ok: true };
        },

        async validate(opts) {
            return { ok: true };
        },

        async deactivate() {
            return { ok: true };
        },

        async refreshFromStorage() { emit(); },

        init() {
            _ready = true;
            emit();
            return Promise.resolve();
        }
    };

    let _ready = true;

    VA.deviceId = {
        VERSION: 2,
        osFamily() { return 'windows'; },
        signals() { return 'bypassed'; },
        compute() { return Promise.resolve('bypassed'); }
    };

    VA.license = api;
})();