// ============================================================
//  Visa Automator — panel CSS  (ISOLATED world)
// ------------------------------------------------------------
//  All panel styling lives inside the Shadow DOM (see ui.js), so
//  these rules are fully isolated from the host site's Tailwind and
//  cannot leak out. Theme: near-black + amber (#FF671F) "terminal".
//
//  THEMES — [data-theme] on the panel's .wrap (set by ui.applyTheme from the
//  VERIFIED license payload). All four stay night-mode; only accents,
//  gradients, borders, glow and badges change. The `:host` defaults
//  ARE the ELITE palette, so an unthemed panel renders exactly like
//  the historical design (no visual change).
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.PANEL_CSS) return;

    // Corner CAPTCHA toast — its own Shadow DOM (see ui.cfToast), so it is
    // visible even when the panel is hidden/minimized. Bottom-left, clear of
    // the panel (top-right) and of the site's own footers.
    VA.CF_TOAST_CSS = `
:host { all: initial; }
.cft {
  position: fixed; left: 18px; bottom: 18px; max-width: 320px;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  font-size: 12.5px; font-weight: 600; letter-spacing: .1px;
  padding: 10px 14px; border-radius: 10px;
  background: #0b0d10; color: #e6e6e6;
  border: 1px solid #1e2733;
  box-shadow: 0 10px 30px rgba(0,0,0,.55);
  opacity: 0; transform: translateY(8px); pointer-events: none;
  transition: opacity .18s ease, transform .18s ease;
}
.cft.show { opacity: 1; transform: translateY(0); }
.cft.work { border-color: rgba(255,103,31,.85); color: #ffd6bd; }
.cft.ok   { border-color: rgba(34,197,94,.9);  color: #bbf7d0; }
.cft.warn { border-color: rgba(239,68,68,.95); color: #fecaca;
            animation: cftpulse .9s ease-in-out infinite; }
@keyframes cftpulse {
  0%,100% { box-shadow: 0 10px 30px rgba(0,0,0,.55), 0 0 0 1px rgba(239,68,68,.25); }
  50%     { box-shadow: 0 10px 30px rgba(0,0,0,.55), 0 0 0 3px rgba(239,68,68,.9); }
}
`;

    VA.PANEL_CSS = `
:host { all: initial; }
/* ── design tokens (defaults = ELITE / the original design) ─── */
:host {
  --bg: #0b0d10; --panel: #10151b; --card: #0e1319; --ctl: #141c24;
  --border: #1e2733; --border-2: #26313d;
  --accent: #FF671F; --accent-2: #ff8a4c; --accent-3: #e2551a;
  --accent-ink: #111; --accent-rgb: 255,103,31; --accent-line: #5a3416;
  --title-accent: #FF671F;
  --glow: none; --card-glow: none; --start-glow: none; --brand-glow: none;
  --start-grad: linear-gradient(180deg,#43e07f,#22b862);
  --head-grad: linear-gradient(180deg,#10151b,#0b0d10);
  --strip-grad: linear-gradient(90deg, rgba(255,103,31,.13), rgba(255,103,31,0) 70%);
  --wrap-shadow: 0 18px 50px rgba(0,0,0,.6), 0 0 0 1px rgba(255,103,31,.12);
  --radius: 12px; --btn-radius: 9px;
}
/* ── themes — applied via data-theme on .wrap (see ui.applyTheme) ───
   Four black-based palettes: BASIC green · PRO chocolate+gold · VPS orange
   (the original design) · SUPER CHARGE dark red.
   ui.js picks one via SKIN_BY_THEME — currently BASIC *and* PRO resolve to
   "core", and VPS FAST SERVER *and* SUPER CHARGE resolve to "elite", so the
   "boost" and "overdrive" palettes below are unassigned (kept for easy revert). */

/* BASIC — black + green, flat & minimal, square corners */
.wrap[data-theme="core"] {
  --bg:#070b08; --panel:#0d140f; --card:#0a100b; --ctl:#111a13;
  --border:#1a2a1e; --border-2:#26382b;
  --accent:#22c55e; --accent-2:#4ade80; --accent-3:#15803d;
  --accent-ink:#04160b; --accent-rgb:34,197,94; --accent-line:#14532d;
  --title-accent:#4ade80;
  --start-grad:#1f9d55;
  --head-grad:linear-gradient(180deg,#0d140f,#070b08);
  --strip-grad:linear-gradient(90deg, rgba(34,197,94,.14), rgba(34,197,94,0) 70%);
  --wrap-shadow:0 12px 34px rgba(0,0,0,.55), 0 0 0 1px rgba(0,0,0,.45);
  --radius:8px; --btn-radius:8px;
}
/* PRO — deep espresso + muted antique gold (colorex ref, eye-comfort tuned):
   darker, lower-saturation backgrounds and a deeper non-glary gold so it reads
   rich & premium but is easy on the eyes over long sessions.
   UNASSIGNED — a PRO licence now renders in the BASIC (core) skin (see
   SKIN_BY_THEME in ui.js). Point boost → 'boost' to bring this look back. */
.wrap[data-theme="boost"] {
  --bg:#0c0a08; --panel:#161210; --card:#110e0b; --ctl:#1c1713;
  --border:#312619; --border-2:#443729;
  --accent:#cfa055; --accent-2:#d9b271; --accent-3:#9c7231;
  --accent-ink:#1c1305; --accent-rgb:207,160,85; --accent-line:#6b4e22;
  --title-accent:#d9b271;
  --glow:0 6px 20px rgba(207,160,85,.16);
  --card-glow:0 0 0 1px rgba(207,160,85,.13);
  --start-glow:0 3px 15px rgba(207,160,85,.26);
  --start-grad:linear-gradient(180deg,#d4a64d,#a5741d);
  --head-grad:linear-gradient(135deg,#33240f,#0c0a08);
  --strip-grad:linear-gradient(90deg, rgba(207,160,85,.20), rgba(156,114,49,.08) 55%, rgba(207,160,85,0));
  --wrap-shadow:0 20px 55px rgba(0,0,0,.66), 0 0 0 1px rgba(207,160,85,.18);
  --radius:14px; --btn-radius:12px;
}
/* VPS FAST SERVER — black + orange: the ORIGINAL design (unchanged) */
.wrap[data-theme="elite"] {
  --bg:#0b0d10; --panel:#10151b; --card:#0e1319; --ctl:#141c24;
  --border:#1e2733; --border-2:#26313d;
  --accent:#FF671F; --accent-2:#ff8a4c; --accent-3:#e2551a;
  --accent-ink:#111; --accent-rgb:255,103,31; --accent-line:#5a3416;
  --title-accent:#FF671F;
  --glow:none; --card-glow:none; --start-glow:none; --brand-glow:none;
  --start-grad:linear-gradient(180deg,#43e07f,#22b862);
  --head-grad:linear-gradient(180deg,#10151b,#0b0d10);
  --strip-grad:linear-gradient(90deg, rgba(255,103,31,.13), rgba(255,103,31,0) 70%);
  --wrap-shadow:0 18px 50px rgba(0,0,0,.6), 0 0 0 1px rgba(255,103,31,.12);
  --radius:12px; --btn-radius:9px;
}
/* SUPER CHARGE SERVER — black + crimson & gold, glowing premium.
   UNASSIGNED — a SUPER CHARGE licence now renders in the VPS (elite) skin (see
   SKIN_BY_THEME in ui.js). Point overdrive → 'overdrive' to bring this back. */
.wrap[data-theme="overdrive"] {
  --bg:#0a0405; --panel:#170709; --card:#110607; --ctl:#1e0b0d;
  --border:#3a161b; --border-2:#52202a;
  --accent:#dc143c; --accent-2:#f5c542; --accent-3:#9e0f2e;
  --accent-ink:#fff; --accent-rgb:220,20,60; --accent-line:#6a1f2a;
  --title-accent:#f5c542;
  --glow:0 8px 30px rgba(220,20,60,.24);
  --card-glow:0 0 0 1px rgba(245,197,66,.16);
  --start-glow:0 4px 20px rgba(220,20,60,.34);
  --brand-glow:0 0 16px rgba(245,197,66,.55);
  --start-grad:linear-gradient(180deg,#e83a5c,#c8103a);
  --head-grad:linear-gradient(120deg,#3a0c16,#170709 55%,#0a0405);
  --strip-grad:linear-gradient(120deg, rgba(245,197,66,.30), rgba(220,20,60,.20) 45%, rgba(158,15,46,.16));
  --wrap-shadow:0 26px 64px rgba(0,0,0,.75), 0 0 0 1px rgba(245,197,66,.24);
  --radius:14px; --btn-radius:13px;
}

*, *::before, *::after { box-sizing: border-box; }
.wrap {
  position: fixed; top: 72px; right: 20px; width: 380px; max-height: 86vh;
  display: flex; flex-direction: column; z-index: 2147483646;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  font-size: 13px; color: #e6e6e6;
  background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius);
  box-shadow: var(--wrap-shadow);
  overflow: hidden; opacity: 0; transform: translateY(-6px);
  transition: opacity .16s ease, transform .16s ease;
}
.wrap.show { opacity: 1; transform: translateY(0); }
.wrap.min { max-height: 46px; }

/* attention flash — pulses the panel border while a human is needed */
.wrap.alert { animation: alertflash .85s ease-in-out infinite; }
@keyframes alertflash {
  0%,100% { box-shadow: var(--wrap-shadow); }
  50%     { box-shadow: 0 18px 50px rgba(0,0,0,.6), 0 0 0 3px rgba(var(--accent-rgb),.95); }
}

/* header */
.hdr { display: flex; align-items: center; gap: 8px; padding: 10px 12px;
  background: var(--head-grad); cursor: grab; user-select: none;
  border-bottom: 1px solid var(--border); }
.hdr.drag { cursor: grabbing; }
.dot { width: 9px; height: 9px; border-radius: 50%; background: #3a4756; flex: none;
  box-shadow: 0 0 0 0 rgba(var(--accent-rgb),.5); }
.dot.on { background: #37d67a; animation: pulse 1.6s infinite; }
@keyframes pulse { 0%{box-shadow:0 0 0 0 rgba(55,214,122,.5)} 70%{box-shadow:0 0 0 7px rgba(55,214,122,0)} 100%{box-shadow:0 0 0 0 rgba(55,214,122,0)} }
.title { font-weight: 700; letter-spacing: .3px; font-size: 13px; }
.title b { color: var(--title-accent); }
.ver { color: #5b6b7c; font-size: 10px; margin-left: 2px; }
.hdr .sp { flex: 1; }
.iconbtn { background: transparent; border: 1px solid var(--border-2); color: #9fb0c0; cursor: pointer;
  width: 26px; height: 24px; border-radius: 6px; font-size: 13px; line-height: 1; }
.iconbtn:hover { border-color: var(--accent); color: var(--accent); }

/* ── plan branding strip (logo + tier title + tagline) ─────── */
.brand { position: relative; overflow: hidden; display: flex; align-items: center; gap: 8px;
  padding: 8px 12px; background: var(--strip-grad); border-bottom: 1px solid var(--border); }
.brand .blogo { flex: none; font-size: 13px; line-height: 1; color: var(--accent); text-shadow: var(--brand-glow); }
.brand .btitle { font-size: 11.5px; font-weight: 900; letter-spacing: 1.8px; text-transform: uppercase;
  color: #eef6ff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.brand .btag { margin-left: auto; flex: none; font-size: 9px; font-weight: 700; letter-spacing: 1px;
  text-transform: uppercase; color: var(--accent); border: 1px solid var(--accent-line);
  border-radius: 20px; padding: 2px 8px; background: rgba(var(--accent-rgb),.07); }

/* tabs */
.tabs { display: flex; background: var(--bg); border-bottom: 1px solid var(--border); }
.tab { flex: 1; text-align: center; padding: 9px 0; cursor: pointer; color: #7d8d9c;
  font-weight: 600; font-size: 12px; letter-spacing: .4px; border-bottom: 2px solid transparent; }
.tab:hover { color: #cfe0ee; }
.tab.active { color: var(--accent); border-bottom-color: var(--accent); }

.body { overflow-y: auto; padding: 12px; }
.body::-webkit-scrollbar { width: 8px; }
.body::-webkit-scrollbar-thumb { background: var(--border); border-radius: 8px; }

/* start/stop */
.mainbtn { width: 100%; padding: 12px; border: none; border-radius: var(--btn-radius); cursor: pointer;
  font-weight: 800; font-size: 14px; letter-spacing: .6px; color: #06110a;
  background: var(--start-grad); box-shadow: var(--start-glow);
  transition: filter .12s, box-shadow .15s; }
.mainbtn:hover { filter: brightness(1.08); }
.mainbtn.stop { background: linear-gradient(180deg,#ff6a5e,#e23b2e); color: #fff; box-shadow: none; }

/* live Auto Date Book pause/resume (Run tab) */
.bookbtn { width: 100%; margin-top: 8px; padding: 9px; border-radius: var(--btn-radius); cursor: pointer;
  font-weight: 700; font-size: 12px; letter-spacing: .3px; color: #c4d2df;
  background: var(--ctl); border: 1px solid var(--border-2); transition: border-color .12s, color .12s; }
.bookbtn:hover { border-color: var(--accent); color: var(--accent); }
.bookbtn.paused { border-color: #e9c46a; color: #e9c46a; background: rgba(217,154,28,.08); }

/* dedicated "start booking on THIS page" button (shown while idle) */
.datesbtn { width: 100%; margin-top: 8px; padding: 10px; border-radius: var(--btn-radius); cursor: pointer;
  font-weight: 700; font-size: 12px; letter-spacing: .3px; color: var(--accent);
  background: rgba(var(--accent-rgb),.08); border: 1px solid var(--accent-line); transition: border-color .12s, background .12s; }
.datesbtn:hover { border-color: var(--accent); background: rgba(var(--accent-rgb),.16); }

/* Skip This Page — cancels only the current page's tasks (Run tab, while running) */
.skipbtn { width: 100%; margin-top: 8px; padding: 9px; border-radius: var(--btn-radius); cursor: pointer;
  font-weight: 700; font-size: 12px; letter-spacing: .3px; color: #c4d2df;
  background: var(--ctl); border: 1px solid var(--border-2); transition: border-color .12s, color .12s, background .12s; }
.skipbtn:hover { border-color: #e9c46a; color: #e9c46a; background: rgba(217,154,28,.08); }

/* profile switcher (Config) — 3 isolated sets, active highlighted */
.profiles { display: grid; grid-template-columns: repeat(3,1fr); gap: 6px; }
.profbtn { display: flex; flex-direction: column; align-items: flex-start; gap: 2px; overflow: hidden;
  padding: 8px 9px; border-radius: 8px; cursor: pointer; text-align: left; color: #c4d2df;
  background: var(--card); border: 1px solid var(--border-2); transition: border-color .12s, background .12s; }
.profbtn:hover { border-color: var(--accent); }
.profbtn.active { border-color: var(--accent); background: rgba(var(--accent-rgb),.10);
  box-shadow: 0 0 0 1px rgba(var(--accent-rgb),.30) inset; }
.profbtn .pn { font-size: 9px; color: #7d8d9c; text-transform: uppercase; letter-spacing: .5px; }
.profbtn.active .pn { color: var(--accent); }
.profbtn .pnm { font-size: 11px; font-weight: 700; color: #e6e6e6; max-width: 100%;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

/* Run-tab document quick access (drag source + Use) */
.runfilesbox { margin-top: 12px; padding: 10px; border-radius: 10px; background: var(--card); border: 1px solid var(--border); box-shadow: var(--card-glow); }
.runfileshd { font-size: 10px; color: #7d8d9c; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 8px; }
.runfiles { display: flex; flex-direction: column; gap: 5px; }
.runfile { display: flex; align-items: center; gap: 8px; font-size: 11px; cursor: grab;
  background: var(--bg); border: 1px solid var(--border); border-radius: 7px; padding: 6px 8px; }
.runfile:active { cursor: grabbing; }
.runfile:hover { border-color: var(--border-2); }
.runfile .ri { flex: none; width: 16px; text-align: center; color: #8298ab; font-size: 12px; }
.runfile .rp { flex: none; color: var(--accent); font-weight: 700; font-size: 9px; border: 1px solid var(--accent-line); border-radius: 4px; padding: 1px 4px; }
.runfile .rn { flex: 1; min-width: 0; color: #c4d2df; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.runfile .ruse { flex: none; background: var(--ctl); border: 1px solid var(--border-2); color: #c4d2df; border-radius: 6px;
  padding: 4px 10px; font-size: 11px; cursor: pointer; }
.runfile .ruse:hover { border-color: var(--accent); color: var(--accent); }

/* OTP — always-visible segmented 6-box entry + Verify button */
.otpbox { margin-top:12px; padding:10px; border-radius:10px; background:var(--card); border:1px solid var(--border); box-shadow: var(--card-glow); }
.otphd { font-size:10px; color:#7d8d9c; text-transform:uppercase; letter-spacing:.5px; margin-bottom:8px; }
.otprow { display:flex; align-items:center; gap:8px; }
.otpcells { display:flex; gap:6px; flex:1; min-width:0; }
.otpd { width:100%; min-width:0; height:38px; padding:0; text-align:center; font-size:18px; font-weight:700;
  color:#e6e6e6; background:var(--bg); border:1px solid var(--border-2); border-radius:10px; outline:none;
  font-family:'Consolas','SF Mono',monospace; transition:border-color .12s, box-shadow .12s; }
.otpd:focus { border-color:var(--accent); box-shadow:0 0 0 2px rgba(var(--accent-rgb),.2); }
.otpverify { flex:none; height:38px; padding:0 14px; border:none; border-radius:var(--btn-radius); cursor:pointer;
  font-weight:800; font-size:12px; letter-spacing:.3px; color:#06110a;
  background:var(--start-grad); transition:filter .12s; }
.otpverify:hover { filter:brightness(1.08); }

/* detected + stats */
.detline { display:flex; align-items:center; gap:8px; margin:12px 2px 8px; }
.detline .lab { color:#7d8d9c; font-size:11px; text-transform:uppercase; letter-spacing:.5px; }
.detline .val { color:var(--accent); font-weight:700; }
.stats { display: grid; grid-template-columns: repeat(3,1fr); gap: 8px; }
.stat { background:var(--panel); border:1px solid var(--border); border-radius:8px; padding:8px; text-align:center; box-shadow: var(--card-glow); }
.stat .n { font-size:18px; font-weight:800; color:#e6e6e6; }
.stat .n.amber { color:var(--accent); }
.stat .k { font-size:10px; color:#7d8d9c; text-transform:uppercase; letter-spacing:.5px; margin-top:2px; }

/* stepper — compact 2-column grid (Login … Payment) */
.steps { margin: 12px 0; display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.step { display: flex; align-items: center; gap: 7px; padding: 6px 8px; border-radius: 8px; min-width: 0;
  background:var(--card); border:1px solid #151c24; transition: border-color .15s, background .15s, box-shadow .15s; }
.step.wide { grid-column: 1 / -1; }
.step .idx { width: 19px; height: 19px; border-radius: 50%; flex:none; font-size:10px; font-weight:700;
  display:flex; align-items:center; justify-content:center; background:#1a222c; color:#8298ab; transition:background .15s,color .15s; }
.step .main { flex:1; min-width:0; display:flex; flex-direction:column; gap:4px; }
.step .nm { font-size:11px; color:#c4d2df; line-height:1.1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.step .bar { height:4px; border-radius:3px; background:#1a222c; overflow:hidden; position:relative; }
.step .bar .fill { position:absolute; left:0; top:0; bottom:0; width:0; border-radius:3px; background:#3a4756; transition:width .3s ease; }
.step .st { flex:none; width:16px; height:16px; position:relative; font-size:12px; line-height:16px; text-align:center; color:#8298ab; }

/* pending — quiet, empty bar */
.step.pending { opacity:.92; }

/* running — highlighted "button", flowing bar, spinner icon */
.step.running { border-color:var(--accent); background:rgba(var(--accent-rgb),.08); box-shadow:0 0 0 1px rgba(var(--accent-rgb),.28) inset; }
.step.running .idx { background:var(--accent); color:var(--accent-ink); }
.step.running .nm { color:var(--accent-2); font-weight:600; }
.step.running .bar .fill { width:100%; background:linear-gradient(90deg,var(--accent),var(--accent-2),var(--accent)); background-size:200% 100%; animation: barflow 1.1s linear infinite; }
@keyframes barflow { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
.step.running .st { color:transparent; }
.step.running .st::after { content:''; position:absolute; inset:1px; border-radius:50%;
  border:2px solid rgba(var(--accent-rgb),.25); border-top-color:var(--accent); animation: spin .7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* success — full green bar + check */
.step.success .idx { background:#1f8f4e; color:#fff; }
.step.success .bar .fill { width:100%; background:#37d67a; }
.step.success .st { color:#37d67a; }

/* error — full red bar + cross */
.step.error { border-color:#6e2620; }
.step.error .idx { background:#e23b2e; color:#fff; }
.step.error .bar .fill { width:100%; background:#ff6a5e; }
.step.error .st { color:#ff6a5e; }

/* waiting — pulsing amber part-bar */
.step.waiting { border-color:#5a4718; }
.step.waiting .idx { background:#d99a1c; color:#111; }
.step.waiting .bar .fill { width:55%; background:#e9c46a; animation: barpulse 1.2s ease-in-out infinite; }
@keyframes barpulse { 0%,100%{opacity:.45} 50%{opacity:1} }
.step.waiting .st { color:#e9c46a; }

/* skipped — dim, filled grey */
.step.skipped { opacity:.5; }
.step.skipped .bar .fill { width:100%; background:#3a4756; }
.step.skipped .st { color:#5b6b7c; }

/* turnstile + payment + waiting */
.callout { margin-top:10px; padding:9px 10px; border-radius:8px; font-size:12px; border:1px solid; }
.callout.wait { background:rgba(217,154,28,.08); border-color:#5a4718; color:#e9c46a; }
.callout.pay { background:rgba(55,214,122,.05); border-color:var(--border-2); color:#8ea3b4; }
.callout.pay.found { background:rgba(55,214,122,.08); border-color:#1f5a38; color:#8ff0b6; }
/* simulated proxy IP (Run tab) — display only */
.callout.proxy { display:flex; align-items:center; gap:8px; margin-bottom:12px; border-color:var(--accent-line); color:#c4d2df;
  background:linear-gradient(180deg, rgba(var(--accent-rgb),.07), rgba(var(--accent-rgb),0)), var(--panel);
  box-shadow:var(--card-glow); }
.callout.proxy .globe { flex:none; font-size:13px; filter:drop-shadow(0 0 5px rgba(var(--accent-rgb),.55)); }
.callout.proxy .lab { font-size:10px; color:#7d8d9c; text-transform:uppercase; letter-spacing:.5px; }
.callout.proxy .ip { font-weight:700; color:var(--accent-2); font-family:'Consolas','SF Mono',monospace; letter-spacing:.4px; }
.callout.proxy.fetching .ip { color:#8ea3b4; font-weight:600; font-family:'Segoe UI',system-ui,sans-serif; letter-spacing:.2px; }
.callout.proxy .demo { margin-left:auto; flex:none; font-size:9px; font-weight:800; letter-spacing:.4px;
  color:var(--accent); border:1px solid var(--accent-line); border-radius:20px; padding:1px 7px; background:rgba(var(--accent-rgb),.08); }
.callout.proxy .pspin { margin-left:auto; flex:none; width:11px; height:11px; border-radius:50%;
  border:2px solid rgba(var(--accent-rgb),.25); border-top-color:var(--accent); animation:spin .7s linear infinite; display:none; }
.callout.proxy.fetching .pspin { display:inline-block; }
.callout.proxy.fetching .demo { display:none; }
/* proxy feature turned OFF — no proxy is generated; the dedicated device IP is used */
.callout.proxy.off { border-color:var(--border-2); color:#8ea3b4; background:var(--panel); box-shadow:none; }
.callout.proxy.off .globe { filter:grayscale(1); opacity:.6; }
.callout.proxy.off .ip { color:#8ea3b4; font-weight:600; font-family:'Segoe UI',system-ui,sans-serif; letter-spacing:.2px; }
.callout.proxy.off .demo { color:#7d8d9c; border-color:var(--border-2); background:transparent; }

/* premium "connecting to VPS / high-speed server" splash — DISPLAY ONLY,
   shown on load for VPS FAST SERVER (elite) + SUPER CHARGE (overdrive) plans */
.vpssplash { position:absolute; inset:0; z-index:30; display:none; flex-direction:column;
  align-items:center; justify-content:center; gap:13px; text-align:center; padding:22px;
  border-radius:var(--radius);
  background:radial-gradient(120% 120% at 50% 32%, rgba(var(--accent-rgb),.16), rgba(3,5,8,.90) 72%), var(--bg); }
.vpssplash.on { display:flex; animation:vpsfade .28s ease; }
.vpsring { width:48px; height:48px; border-radius:50%;
  border:3px solid rgba(var(--accent-rgb),.20); border-top-color:var(--accent);
  box-shadow:0 0 24px rgba(var(--accent-rgb),.5); animation:spin .8s linear infinite; }
.vpstxt { font-size:14px; font-weight:800; letter-spacing:.3px; color:var(--accent-2);
  text-shadow:0 0 16px rgba(var(--accent-rgb),.55); }
.vpssub { font-size:11px; color:#9fb0c0; letter-spacing:.2px; }
@keyframes vpsfade { from{opacity:0} to{opacity:1} }
.callout.cf { background:rgba(var(--accent-rgb),.08); border-color:var(--accent-line); color:var(--accent-2); }
.callout.confirm { background:rgba(55,214,122,.08); border-color:#1f5a38; color:#8ff0b6; }
.callout.pause { background:rgba(226,59,46,.10); border-color:#6e2620; color:#ff9a90; }
.callout.upload { background:rgba(var(--accent-rgb),.06); border-color:var(--border); color:var(--accent-2); }
.callout.upload.ok { background:rgba(55,214,122,.08); border-color:#1f5a38; color:#8ff0b6; }
.callout.upload.err { background:rgba(226,59,46,.10); border-color:#6e2620; color:#ff9a90; }
.callout.upload .upmsg { font-weight:600; margin-bottom:7px; }
.callout.upload .upbar { height:5px; border-radius:3px; background:#1a222c; overflow:hidden; position:relative; }
.callout.upload .upbar .fill { position:absolute; left:0; top:0; bottom:0; width:0; border-radius:3px;
  background:linear-gradient(90deg,var(--accent),var(--accent-2)); transition:width .3s ease; }
.callout.upload.ok .upbar .fill { background:#37d67a; }
.callout.upload.err .upbar .fill { background:#ff6a5e; }
.callout .row2 { display:flex; gap:6px; margin-top:8px; }
.callout input { flex:1; background:var(--bg); border:1px solid var(--border-2); color:#cfe0ee; border-radius:6px;
  padding:6px 8px; font-size:11px; }
.callout button { background:var(--accent); color:var(--accent-ink); border:none; border-radius:6px; padding:6px 10px;
  font-weight:700; cursor:pointer; font-size:11px; }
.callout button.go { flex:1; padding:9px 10px; font-size:12px; }

/* run header — who this run is for */
.runwho { display:flex; gap:8px; margin-bottom:10px; }
.runwho .who { flex:1; background:var(--panel); border:1px solid var(--border); border-radius:8px; padding:7px 9px; overflow:hidden; }
.runwho .lab { display:block; font-size:9px; color:#7d8d9c; text-transform:uppercase; letter-spacing:.5px; }
.runwho .val { color:#e6e6e6; font-weight:700; font-size:13px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

/* live log strip on the Run tab */
.logstripwrap { margin-top:12px; }
.logstriphd { font-size:10px; color:#7d8d9c; text-transform:uppercase; letter-spacing:.5px; margin-bottom:5px; }
.logstrip { max-height:150px; overflow-y:auto; background:var(--card); border:1px solid var(--border); border-radius:8px;
  padding:7px 9px; font-family:'Consolas','SF Mono',monospace; font-size:10.5px; line-height:1.5; }
.logstrip::-webkit-scrollbar { width:7px; }
.logstrip::-webkit-scrollbar-thumb { background:var(--border); border-radius:8px; }

/* generic fields */
.field { margin-bottom: 10px; }
.field > label { display:block; font-size:11px; color:#8298ab; margin-bottom:4px; text-transform:uppercase; letter-spacing:.4px; }
.field input[type=text], .field input[type=password], .field input[type=number],
.field select, .field textarea {
  width:100%; background:var(--card); border:1px solid var(--border-2); color:#e6e6e6; border-radius:7px;
  padding:8px 9px; font-size:13px; outline:none; font-family:inherit; }
.field input:focus, .field select:focus, .field textarea:focus { border-color:var(--accent); }
.field .hint { font-size:10px; color:#5b6b7c; margin-top:3px; }
.pwwrap { position:relative; display:block; }
.field .pwwrap input[type=text], .field .pwwrap input[type=password] { padding-right:34px; }
.pweye { position:absolute; top:1px; right:1px; bottom:1px; width:32px; display:flex; align-items:center;
  justify-content:center; background:none; border:none; padding:0; margin:0; cursor:pointer; color:#8298ab; border-radius:0 7px 7px 0; }
.pweye:hover { color:var(--accent); }
.pweye:focus-visible { outline:2px solid var(--accent); outline-offset:-2px; }
.pweye svg { width:16px; height:16px; display:block; pointer-events:none; }
.two { display:grid; grid-template-columns:1fr 1fr; gap:8px; }

/* toggles */
.tg { display:flex; align-items:center; justify-content:space-between; padding:8px 0; border-bottom:1px solid #141b22; }
.tg:last-child { border-bottom:none; }
.tg .lab { font-size:12px; color:#c4d2df; }
.sw { width:38px; height:21px; border-radius:20px; background:var(--border-2); position:relative; cursor:pointer; flex:none; transition:background .15s; }
.sw::after { content:''; position:absolute; top:2px; left:2px; width:17px; height:17px; border-radius:50%; background:#8298ab; transition:transform .15s, background .15s; }
.sw.on { background:rgba(var(--accent-rgb),.4); }
.sw.on::after { transform:translateX(17px); background:var(--accent); }

/* file list */
.files { display:flex; flex-direction:column; gap:5px; margin-top:6px; }
.fitem { display:flex; align-items:center; gap:8px; background:var(--card); border:1px solid var(--border); border-radius:6px; padding:6px 8px; font-size:11px; }
.fitem .fn { flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.fitem .pri { color:var(--accent); font-weight:700; font-size:9px; border:1px solid var(--accent-line); border-radius:4px; padding:1px 4px; }
.fitem .x { color:#e2685e; cursor:pointer; font-weight:700; }
.btnrow { display:flex; gap:8px; margin-top:8px; flex-wrap:wrap; }
.btn { background:var(--ctl); border:1px solid var(--border-2); color:#c4d2df; border-radius:7px; padding:7px 11px; font-size:12px; cursor:pointer; }
.btn:hover { border-color:var(--accent); color:var(--accent); }
.btn.amber { background:var(--accent); color:var(--accent-ink); border-color:var(--accent); font-weight:700; }
.sechead { font-size:11px; color:var(--accent); text-transform:uppercase; letter-spacing:.6px; margin:14px 0 8px; font-weight:700; border-bottom:1px solid #1a222c; padding-bottom:4px; }

/* logs */
.logbar { display:flex; align-items:center; gap:6px; margin-bottom:8px; }
.logbar .filt { display:flex; gap:4px; }
.chip { font-size:10px; padding:4px 8px; border-radius:6px; border:1px solid var(--border-2); color:#8298ab; cursor:pointer; background:var(--card); }
.chip.active { border-color:var(--accent); color:var(--accent); }
.logbar .sp { flex:1; }
.logs { font-family:'Consolas','SF Mono',monospace; font-size:11px; line-height:1.5; }
.lg { display:flex; gap:7px; padding:2px 0; border-bottom:1px solid #10151b; }
.lg .ts { color:#4d5b6a; flex:none; }
.lg .cat { flex:none; width:56px; font-weight:700; }
.lg .msg { flex:1; word-break:break-word; color:#c4d2df; }
.lg .n { color:#5b6b7c; }
.lg.INFO .cat{color:#5aa0e0} .lg.OK .cat{color:#37d67a} .lg.WARN .cat{color:#e9c46a}
.lg.ERR .cat{color:#ff6a5e} .lg.NET .cat{color:#b98ff0} .lg.WAITING .cat{color:#e9c46a}
.empty { color:#4d5b6a; text-align:center; padding:20px; font-size:12px; }

/* ── license / subscription ─────────────────────────────── */
/* header days-left badge */
.licbadge { flex:none; font-size:9px; font-weight:800; letter-spacing:.4px; text-transform:uppercase;
  padding:2px 7px; border-radius:20px; border:1px solid; cursor:default; white-space:nowrap; }
.licbadge.ok   { color:#37d67a; border-color:#1f5a38; background:rgba(55,214,122,.10); }
.licbadge.warn { color:#e9c46a; border-color:#5a4718; background:rgba(217,154,28,.10); }
.licbadge.crit { color:#ff6a5e; border-color:#6e2620; background:rgba(226,59,46,.12); }

/* activation card (Run tab) — shown only until a valid license is cached */
.liccard { margin-bottom:12px; padding:14px; border-radius:12px;
  background:linear-gradient(180deg,rgba(var(--accent-rgb),.10),rgba(var(--accent-rgb),.03)); border:1px solid var(--accent-line); box-shadow: var(--glow); }
.liccard.nudge { animation: licnudge .7s ease; }
@keyframes licnudge { 0%,100%{box-shadow:0 0 0 0 rgba(var(--accent-rgb),0)} 30%{box-shadow:0 0 0 3px rgba(var(--accent-rgb),.55)} }
.liccard .lichd { font-size:14px; font-weight:800; color:#ffd9c2; letter-spacing:.2px; }
.liccard .licsub { font-size:11px; color:#b79b88; margin:4px 0 10px; line-height:1.45; }
.liccard .licrow { display:flex; gap:8px; }
.lickey { flex:1; min-width:0; background:var(--bg); border:1px solid var(--accent-line); color:#ffe9db; border-radius:var(--btn-radius);
  padding:10px 11px; font-size:14px; font-weight:700; letter-spacing:1.5px; outline:none;
  font-family:'Consolas','SF Mono',monospace; text-transform:uppercase; }
.lickey::placeholder { color:#7a5a45; letter-spacing:1px; font-weight:500; }
.lickey:focus { border-color:var(--accent); box-shadow:0 0 0 2px rgba(var(--accent-rgb),.22); }
.licbtn { flex:none; padding:0 16px; border:none; border-radius:var(--btn-radius); cursor:pointer;
  font-weight:800; font-size:12px; letter-spacing:.4px; color:var(--accent-ink);
  background:linear-gradient(180deg,var(--accent-2),var(--accent)); box-shadow: var(--glow); transition:filter .12s; }
.licbtn:hover { filter:brightness(1.08); }
.licbtn:disabled { opacity:.6; cursor:default; filter:none; }
.licmsg { margin-top:9px; font-size:11px; line-height:1.4; }
.licmsg.err  { color:#ff9a90; }
.licmsg.info { color:#8ea3b4; }

/* locked run buttons (no usable license) */
.mainbtn.locked, .datesbtn.locked { opacity:.45; filter:grayscale(.5); }
.mainbtn:disabled, .datesbtn:disabled { cursor:not-allowed; }

/* Config subscription panel */
.liccfg { background:var(--panel); border:1px solid var(--border); border-radius:8px; padding:9px 11px; box-shadow: var(--card-glow); }
.liccfg .licline { display:flex; justify-content:space-between; gap:10px; padding:3px 0; font-size:12px; }
.liccfg .licline .lab { color:#7d8d9c; }
.liccfg .licline .val { color:#e6e6e6; font-weight:600; text-align:right; word-break:break-word; }
.liccfg .licline .val.ok { color:#37d67a; }

/* ══ per-theme personality — structure, not just colour ══════ */

/* BASIC — flat & minimal: plain strip, no moving bar, square corners */
.wrap[data-theme="core"] .brand { background: var(--panel); }
.wrap[data-theme="core"] .btitle { color: #bbf7d0; font-weight: 800; letter-spacing: 1.3px; }
.wrap[data-theme="core"] .btag { background: transparent; color: #86efac; border-color: var(--border-2); }
.wrap[data-theme="core"] .step.running .bar .fill { animation: none; background: var(--accent); }
.wrap[data-theme="core"] .mainbtn { box-shadow: none; }
.wrap[data-theme="core"] .tab.active { border-bottom-width: 3px; }

/* PRO — accent rail on the strip, accent rule under section heads, glowing stats.
   UNASSIGNED alongside the "boost" palette above (BASIC and PRO now share core). */
.wrap[data-theme="boost"] .brand { padding-left: 15px; }
.wrap[data-theme="boost"] .brand::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 3px;
  background: linear-gradient(180deg, var(--accent), var(--accent-3)); }
.wrap[data-theme="boost"] .sechead { border-bottom-color: rgba(var(--accent-rgb),.35); }
.wrap[data-theme="boost"] .stat .n.amber { text-shadow: 0 0 10px rgba(var(--accent-rgb),.45); }

/* SUPER CHARGE SERVER — sheen strip, glowing running step, premium badges */
.wrap[data-theme="overdrive"] .brand::after { content: ''; position: absolute; inset: 0; pointer-events: none;
  background: linear-gradient(90deg, transparent, rgba(245,197,66,.30), transparent);
  transform: translateX(-100%); animation: odsheen 3.6s ease-in-out infinite; }
@keyframes odsheen { 0%{transform:translateX(-100%)} 55%,100%{transform:translateX(100%)} }
.wrap[data-theme="overdrive"] .btitle { color: #f5d97a; text-shadow: 0 0 12px rgba(245,197,66,.55); }
.wrap[data-theme="overdrive"] .btag { color: #fecaca; border-color: var(--accent-line); background: rgba(var(--accent-rgb),.14); }
.wrap[data-theme="overdrive"] .step.running { box-shadow: 0 0 0 1px rgba(var(--accent-rgb),.40) inset, 0 4px 18px rgba(var(--accent-rgb),.22); }
.wrap[data-theme="overdrive"] .sechead { border-bottom-color: rgba(var(--accent-rgb),.35); }
.wrap[data-theme="overdrive"] .stat { background: linear-gradient(180deg, rgba(var(--accent-rgb),.08), transparent), var(--panel); }
.wrap[data-theme="overdrive"] .licbadge.ok { color: #fca5a5; border-color: var(--accent-line); background: rgba(var(--accent-rgb),.12); }
`;
})();
