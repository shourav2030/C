// ============================================================
//  Device fingerprint — one PC = one device, across browsers.
// ------------------------------------------------------------
//  The whole point of the fingerprint is that DIFFERENT browsers on
//  the SAME computer MUST derive the SAME deviceId, otherwise each
//  browser is charged a separate device slot. Browsers expose the
//  machine differently (Chrome has userAgentData + deviceMemory;
//  Firefox has neither and spells the platform "Win32" not
//  "Windows"), so those signals are deliberately excluded.
//  (See osFamily / deviceSignals / ensureDevice in ../src/license.js.)
// ============================================================
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeDocument, loadModulesFull } from './harness.mjs';

function helpers() {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc, { modules: ['core.js', 'license.js'] });
    assert.ok(VA.deviceId, 'license.js must expose VA.deviceId for tests');
    return VA.deviceId;
}

const SCREEN = { width: 1920, height: 1080, colorDepth: 24 };
const TZ = 'Asia/Dhaka';

// Four browsers, ONE physical machine. Note how each reports the platform
// differently, and which optional signals it does / doesn't have.
const SAME_PC = {
    chrome: { nav: { userAgentData: { platform: 'Windows' }, platform: 'Win32', deviceMemory: 8, hardwareConcurrency: 8 }, scr: SCREEN },
    edge: { nav: { userAgentData: { platform: 'Windows' }, platform: 'Win32', deviceMemory: 8, hardwareConcurrency: 4 }, scr: SCREEN },
    brave: { nav: { userAgentData: { platform: 'Windows' }, platform: 'Win32' }, scr: SCREEN },
    firefox: { nav: { platform: 'Win32', hardwareConcurrency: 16 }, scr: SCREEN } // no userAgentData, no deviceMemory
};

test('Chrome / Edge / Brave / Firefox on one PC derive the SAME deviceId', async () => {
    const { compute } = helpers();
    const ids = {};
    for (const [name, env] of Object.entries(SAME_PC)) ids[name] = await compute(env.nav, env.scr, TZ);

    for (const name of Object.keys(ids)) assert.match(ids[name], /^[a-f0-9]{64}$/, `${name} id is a sha256 hex`);
    assert.equal(new Set(Object.values(ids)).size, 1, 'all four browsers must collapse to ONE device');
});

test('a different machine (screen / timezone / OS) derives a DIFFERENT deviceId', async () => {
    const { compute } = helpers();
    const a = await compute(SAME_PC.chrome.nav, SCREEN, TZ);
    const b = await compute(SAME_PC.chrome.nav, { width: 2560, height: 1440, colorDepth: 24 }, TZ);
    const c = await compute(SAME_PC.chrome.nav, SCREEN, 'Europe/London');
    const d = await compute({ userAgentData: { platform: 'macOS' }, platform: 'MacIntel' }, SCREEN, TZ);

    for (const other of [b, c, d]) assert.notEqual(a, other);
});

test('osFamily collapses the many platform spellings to one family', () => {
    const { osFamily } = helpers();
    for (const p of ['Windows', 'Win32', 'Win64', 'win32']) assert.equal(osFamily(p), 'windows', p);
    for (const p of ['MacIntel', 'Macintosh', 'macOS']) assert.equal(osFamily(p), 'macos', p);
    for (const p of ['Linux x86_64', 'Linux', 'Ubuntu', 'X11']) assert.equal(osFamily(p), 'linux', p);
    assert.equal(osFamily('Android'), 'android');
    assert.equal(osFamily('iPhone'), 'ios');
    assert.equal(osFamily(''), 'unknown');
});

test('the fingerprint carries the algorithm version tag (forces a re-key on change)', () => {
    const h = helpers();
    assert.equal(h.VERSION, 2);
    assert.ok(h.signals(SAME_PC.chrome.nav, SCREEN, TZ).startsWith('v2|'));
});
