// ============================================================
//  Visa Automator — steps  (ISOLATED world)
// ------------------------------------------------------------
//  Pure stage mechanics. Each handler assumes the controller has
//  already confirmed we are on its page (see controller.detectStage)
//  and performs exactly that stage's work, returning a small status
//  object. No scheduling / looping lives here — that is the
//  controller's job. Every handler is cancellable via ctx.signal and
//  bails on generation mismatch through the controller's guard.
//
//  Status vocabulary:
//    ok      — did the work / made progress
//    wait    — blocked on a normal page condition; try again next tick
//    manual  — needs a human (toggle off, or Cloudflare escalation)
//    retry   — attempt failed, try the next candidate/next tick
//    success — booking broke through to payment (terminal)
//    moved   — left this page moving forward (controller re-detects)
//    aborted — run stopped
//    noop    — nothing to do here
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.steps) return;
    const SEL = VA.SELECTORS;
    const D = VA.dom;

    const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june',
        'july', 'august', 'september', 'october', 'november', 'december'];

    function aborted(ctx) { return !ctx || (ctx.signal && ctx.signal.aborted); }

    // ------------------------------------------------------------
    //  Attach a File to a site <input type="file"> so that a React
    //  dropzone actually registers it.
    //
    //  Setting `input.files` alone is not enough on React builds: the
    //  library reads the value through the property DESCRIPTOR and
    //  listens for a real (trusted-shaped) change event, so a naive
    //  assignment + synthetic Event is silently dropped — which is
    //  exactly why the automatic upload appeared to do nothing.
    //
    //  Strategy, most-native first:
    //    1) DataTransfer FileList assigned via the prototype setter,
    //    2) redefine the own `files` property when the setter is absent,
    //    3) dispatch change AND input as bubbling+composed events, so
    //       React's delegated root listener sees them,
    //    4) also fire a `drop` event carrying the same DataTransfer for
    //       dropzones that only wire drag-and-drop.
    //  Returns { ok, error }.
    // ------------------------------------------------------------
    function attachFile(input, file) {
        if (!input) return { ok: false, error: 'no input element' };
        if (VA.site.inputDisabled(input)) return { ok: false, error: 'input is disabled' };
        if (!file) return { ok: false, error: 'no file' };
        // Build a real FileList via DataTransfer (what a genuine file pick
        // produces). If the API is missing, fall back to a FileList-shaped
        // object — enough for `files[0]` / `files.length` consumers.
        let dt = null, fileList = null;
        try {
            dt = new DataTransfer();
            dt.items.add(file);
            fileList = dt.files;
        } catch (_) {
            fileList = {
                0: file, length: 1,
                item: (i) => (i === 0 ? file : null),
                [Symbol.iterator]: function* () { yield file; }
            };
        }

        // (1)/(2) put the FileList on the element.
        let set = false;
        try {
            const desc = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'files');
            if (desc && desc.set) { desc.set.call(input, fileList); set = true; }
        } catch (_) { /* fall through */ }
        if (!set) {
            try {
                input.files = fileList;
                set = !!(input.files && input.files.length);
            } catch (_) {}
        }
        if (!set) {
            try {
                Object.defineProperty(input, 'files', {
                    configurable: true, enumerable: true, get: () => fileList
                });
                set = true;
            } catch (e) { return { ok: false, error: 'cannot set files: ' + (e && e.message) }; }
        }

        // Confirm the element really reports our file before claiming success.
        try {
            if (!input.files || !input.files.length) return { ok: false, error: 'input rejected the file' };
        } catch (_) { /* opaque — continue and let the card check decide */ }

        // (3) notify React. `composed` matters when the input sits in a
        //     shadow tree; bubbling matters for React's delegated listener.
        const fire = (type, init) => {
            try { input.dispatchEvent(new Event(type, Object.assign({ bubbles: true, composed: true }, init))); }
            catch (_) {}
        };
        try { input.focus(); } catch (_) {}
        fire('input');
        fire('change');

        // (4) drag-and-drop-only dropzones: replay the same payload as a drop.
        //     Needs the real DataTransfer — skipped when it wasn't available.
        try {
            const zone = input.closest('label, div, button') || input.parentElement;
            if (zone && dt && window.DragEvent) {
                ['dragenter', 'dragover', 'drop'].forEach((type) => {
                    try {
                        zone.dispatchEvent(new DragEvent(type, {
                            bubbles: true, cancelable: true, composed: true, dataTransfer: dt
                        }));
                    } catch (_) {}
                });
            }
        } catch (_) { /* best-effort */ }

        return { ok: true, error: '' };
    }
    VA.attachFile = attachFile;

    // Text that indicates the last action failed (best-effort, for logging).
    const FAIL_HINTS = /(not available|no longer|already (booked|taken|selected)|sold out|unavailable|try again|failed|expired|invalid|limit)/i;
    function findFailText() {
        const nodes = document.querySelectorAll('[role="alert"], .toast, .alert, .error, .swal2-title, .swal2-html-container, [class*="toast" i], [class*="error" i]');
        for (const n of nodes) {
            if (!D.isVisible(n)) continue;
            const t = (n.textContent || '').trim();
            if (t && FAIL_HINTS.test(t)) return t.slice(0, 120);
        }
        return '';
    }

    // Explicit lock / throttle banners on the OTP page. Deliberately narrow: a
    // false positive pauses the run, so this matches only clear lock phrasing.
    // Used to STOP at once instead of risking an account ban from retries.
    const OTP_LOCK_HINTS = /(too many (otp )?attempts|maximum (otp )?attempts|account (has been )?(locked|blocked|suspended)|temporarily (locked|blocked)|try again (after|later))/i;
    function otpLockedText() {
        const nodes = document.querySelectorAll('[role="alert"], .toast, .alert, .error, .swal2-title, .swal2-html-container, [class*="toast" i], [class*="error" i]');
        for (const n of nodes) {
            if (!D.isVisible(n)) continue;
            const t = (n.textContent || '').trim();
            if (t && OTP_LOCK_HINTS.test(t)) return t.slice(0, 140);
        }
        return '';
    }

    // ---- generic forward motion (notice link / "I Agree" only) ----
    // Confirmations, Save & Continue, Confirm Mission and Continue Booking are
    // each handled by their own verified stage handler — NEVER blindly here.
    async function clickForward(ctx) {
        let acted = false;
        const btn = D.findButtonByText(SEL.text.agree);
        if (btn && D.isVisible(btn) && !btn.disabled) {
            D.click(btn);
            VA.logger.info('Clicked "' + (btn.textContent || '').trim().slice(0, 40) + '"');
            acted = true;
            await D.sleep(700, ctx.signal);
        }
        const notice = document.querySelector(SEL.appointmentNotice);
        if (notice && D.isVisible(notice)) { D.click(notice); acted = true; await D.sleep(700, ctx.signal); }
        return acted;
    }

    // ---- close modals / banners / cookie bars ----
    // Mirrors the original's broad close-button sweep, plus dialog OK/close.
    function autoCloseAnyBanner() {
        let closed = false;
        // (a) explicit close controls anywhere on the page (proven patterns)
        const closeButtons = document.querySelectorAll(
            'button[aria-label="Close" i], .modal-close, svg.lucide-x, [class*="close" i]'
        );
        closeButtons.forEach((btn) => {
            if (btn.closest('#va-panel-host')) return;   // never our own panel
            if (!D.isVisible(btn)) return;
            const target = btn.closest('button, a, [role="button"]') || btn;
            try { target.click(); closed = true; } catch (_) {}
        });
        // (b) dialog confirm/dismiss buttons by text
        const affirm = D.findButtonByText(['OK', 'Got it', 'Dismiss', 'Close', 'Continue']);
        if (affirm && D.isVisible(affirm) && !affirm.closest('#va-panel-host')) {
            const dlg = affirm.closest('[role="dialog"], .modal, .swal2-popup');
            if (dlg) { D.click(affirm); closed = true; }
        }
        return closed;
    }

    // Fires the on-page "Confirm All Information is Correct" + the follow-up
    // "Save & Continue" popup, then waits for the page to actually leave the
    // upload/confirm context. Shared by the auto-upload path (all files verified
    // this run) and the resumed-session path (page already fully uploaded).
    async function confirmAndAdvance(ctx, files) {
        VA.logger.ok('All ' + files.length + ' file(s) uploaded — confirming automatically…');

        const confirmBtn = () => D.findButtonByText(SEL.text.confirmInfo);
        const saveBtn = () => D.findButtonByText(SEL.text.saveContinue);
        const ready = (b) => !!(b && D.isVisible(b) && !b.disabled);

        // Cloudflare can re-challenge here. Wait until EITHER the Confirm button
        // OR the Save button is clickable — the latter means Confirm was already
        // pressed on an earlier tick, so re-entry is safe.
        const gate = await VA.verify.gate({
            signal: ctx.signal, timeout: 60000,
            successWhen: () => ready(confirmBtn()) || ready(saveBtn())
        });
        if (gate.reason === 'aborted') return { status: 'aborted' };
        if (!gate.ok) return { status: 'manual', note: 'Verification (confirm)' };

        // Click Confirm (idempotent — skipped if we're already past it).
        if (ready(confirmBtn())) {
            D.click(confirmBtn());
            VA.logger.ok('Clicked "Confirm All Information is Correct".');
        }

        // Follow-up "Save & Continue" popup (present in most builds).
        const save = await D.waitForButtonText(SEL.text.saveContinue, { signal: ctx.signal, timeout: 10000 });
        if (save) { D.click(save); VA.logger.ok('Clicked "Save & Continue".'); }
        else VA.logger.info('No Save & Continue popup — continuing.');
        await D.sleep(400, ctx.signal);
        if (aborted(ctx)) return { status: 'aborted' };

        // Only advance once we've actually left the upload/confirm page —
        // otherwise re-tick and click again idempotently.
        const moved = await D.waitFor(
            () => (document.querySelector(SEL.fileInput) || ready(confirmBtn())) ? null : true,
            { signal: ctx.signal, timeout: 12000, interval: 400 }
        );
        if (aborted(ctx)) return { status: 'aborted' };
        if (moved) { VA.logger.ok('Upload confirmed — moving on to mission & centre.'); return { status: 'ok' }; }
        return { status: 'wait' };
    }

    VA.steps = {
        // Best-effort read of the site's OTP lock/throttle banner ('' if none).
        otpLockedText,

        // ── Stage 1 — Login ─────────────────────────────────────
        async login(ctx) {
            if (aborted(ctx)) return { status: 'aborted' };
            const { phone, password } = VA.config.creds();
            if (!phone || !password) {
                return { status: 'manual', note: 'Enter phone & password in Config' };
            }
            const phoneEl = document.querySelector(SEL.phone);
            const passEl = document.querySelector(SEL.password);
            if (!phoneEl || !passEl) return { status: 'wait' };

            if (phoneEl.value !== phone) D.fill(phoneEl, phone);
            if (passEl.value !== password) D.fill(passEl, password);

            // Turnstile frequently guards the login submit.
            const g = await VA.verify.gate({ signal: ctx.signal, timeout: 45000 });
            if (g.reason === 'aborted') return { status: 'aborted' };
            if (!g.ok) return { status: 'manual', note: 'Verification' };

            const submit = await D.waitForClickable(SEL.submit, { signal: ctx.signal, timeout: 6000 });
            if (!submit) return { status: 'wait' };
            D.click(submit);
            VA.logger.ok('Submitted login (credentials not logged).');
            return { status: 'ok' };
        },

        // ── Stage 2 — OTP ───────────────────────────────────────
        async otp(ctx) {
            if (aborted(ctx)) return { status: 'aborted' };
            const code = VA.config.otp();
            if (!code || code.length < 4) {
                return { status: 'manual', note: 'Enter the OTP (from SMS) in the Run tab' };
            }
            const boxes = document.querySelectorAll(SEL.otpBoxes);
            if (boxes && boxes.length) {
                // Wipe any digits the page still holds so a NEW code is never
                // merged with a previously-rejected one (the boxes are not always
                // cleared when the site bounces us back to this page).
                for (let i = 0; i < boxes.length; i++) D.fill(boxes[i], '');
                if (boxes.length === 1) {
                    D.fill(boxes[0], code);
                } else {
                    for (let i = 0; i < boxes.length && i < code.length; i++) {
                        if (aborted(ctx)) return { status: 'aborted' };
                        D.fill(boxes[i], code[i]);
                        boxes[i].dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: code[i] }));
                    }
                }
                VA.logger.ok('Filled OTP (value not logged).');
                await D.sleep(400, ctx.signal);
                // Some flows auto-submit; otherwise nudge a verify/submit button.
                const submit = D.findButtonByText(['Verify', 'Submit', 'Continue']) || document.querySelector(SEL.submit);
                const clicked = !!(submit && D.isVisible(submit) && !submit.disabled && D.click(submit));
                // A multi-box OTP form auto-submits on the last digit; a single
                // field only submits if we actually found and clicked a button.
                // The controller uses `submitted` so it never marks a code as
                // "tried" (and thus blocks it) when nothing was really sent.
                return { status: 'ok', submitted: clicked || boxes.length > 1 };
            }
            const single = document.querySelector(SEL.otpBox);
            if (single) { D.fill(single, code); return { status: 'ok', submitted: false }; }
            return { status: 'wait' };
        },

        // ── Stage 3/4 — OTP-success landing & popups ────────────
        async popup(ctx) {
            if (aborted(ctx)) return { status: 'aborted' };
            const closed = autoCloseAnyBanner();
            if (closed) { VA.logger.info('Closed a popup/banner.'); await D.sleep(400, ctx.signal); }
            const moved = await clickForward(ctx);
            return { status: (closed || moved) ? 'ok' : 'wait' };
        },

        // ── Stage 5 — File upload (PRIMARY FIRST, strictly sequential) ──
        // One file per tick, driven by the page's own verified applicant count
        // so ordering can never slip and a slow server never causes a skip.
        async upload(ctx) {
            if (aborted(ctx)) return { status: 'aborted' };
            const files = VA.config.files();
            if (!files.length) return { status: 'manual', note: 'Add 1–4 PDF files in Config' };
            VA.state.set({ expectedCount: files.length });

            // Which queued file to attach next is decided by how many files THIS
            // run has attached & verified — never by indexing the page's own
            // applicant count. That count shifts as the page re-renders, and
            // indexing into it was what stalled uploads after the primary (the
            // manual "Use" button works precisely because it does no such math).
            const done = VA.run._uploadDone || 0;

            // Page-side signals. `cards` = applicant ROWS on the page (NOT proof
            // of a completed upload — the page renders one row per applicant and
            // can render them all the instant the primary lands). `filled` =
            // inputs physically holding a file.
            const cards = VA.site.uploadedCards();
            const filled = VA.site.filledUploadInputs();

            // Progress shown to the operator counts only files that are ACTUALLY
            // attached (held in an input) or confirmed by us this run. Counting
            // the applicant rows made the panel read "All N uploaded" while only
            // one file had landed.
            const attached = Math.max(filled, done);
            if (attached !== VA.state.get('uploadedCount')) VA.state.set({ uploadedCount: attached });
            VA.logger.info('[UPLOAD] ' + done + '/' + files.length + ' attached this run · page: ' +
                cards + ' row(s) / ' + filled + ' input(s) held · ' +
                VA.site.uploadInputs().length + ' box(es) visible');

            // (a) Every queued file was confirmed by the SERVER this run → confirm.
            if (done >= files.length) return await confirmAndAdvance(ctx, files);

            // (b) Resumed session / files already on the page.
            //
            // Our OWN attached Files (filled inputs) are NOT proof the server
            // accepted them — trusting that is exactly what let the run click
            // "Confirm", leave the page, and log success while nothing had
            // actually landed. Advance only on the page's OWN accepted-upload
            // evidence: an applicant card per queued file AND no empty/unlocked
            // box left to fill. Applicant rows alone are still not enough (they
            // can pre-render before any upload), which is why `filled` is required
            // too — but `filled` can never satisfy this on its own.
            if (cards >= files.length && filled >= files.length && !VA.site.activeUploadInput()) {
                return await confirmAndAdvance(ctx, files);
            }

            // The page shows rows for applicants whose files are NOT attached yet.
            // Never treat that as completion — keep uploading. Warn once per run
            // so a genuinely stuck page is visible in the log.
            if (cards >= files.length && VA.run._uploadRowWarnAt !== VA.state.get('runId')) {
                VA.run._uploadRowWarnAt = VA.state.get('runId');
                VA.logger.warn('Page shows ' + cards + ' applicant row(s) but only ' + filled +
                    ' of ' + files.length + ' file(s) are attached — continuing the upload, not confirming.');
            }

            // Red-marked upload errors are handled by the bounded same-file
            // retry loop below. They never advance the queue.

            // THIS tick attaches the next queued file (done===0 is the primary,
            // which per spec must always land first). The BOX is chosen the same
            // way the panel's working "Use" button chooses it — the slot-indexed
            // box when usable, else the first open box in primary-first visual
            // order — so the automatic path behaves exactly like the manual one.
            const slot = done;
            const rec = files[slot];

            // Match the working Run-tab "Use" path without sacrificing primary
            // order. The site can leave stale lock classes on a functional input:
            // strict selection then returns null even though attaching works.
            const verificationClear = () => (VA.verify.enabled && !VA.verify.enabled()) ||
                !VA.verify.hasWidget() || VA.verify.hasSuccessMark() || VA.verify.isChecked();
            const nextInput = () => {
                const strict = VA.site.strictUploadInput();
                if (strict) return strict;
                if (slot > 0) return VA.site.rawUploadInput();
                // rawUploadInput() is DOM-ordered, so never use it for primary.
                // uploadInputs()[0] is label/visual-order sorted and guarantees
                // that file 1 still lands in the primary box.
                const primary = VA.site.uploadInputs()[0];
                if (VA.site.inputDisabled(primary) || (primary.files && primary.files.length)) return null;
                return verificationClear() ? primary : null;
            };

            // Only the primary may be genuinely Cloudflare-locked. Its gate now
            // accepts the same safe candidate that "Use" can attach to, avoiding
            // a 60s wait caused solely by stale opacity/cursor classes.
            let input;
            if (slot === 0) {
                const g = await VA.verify.gate({
                    signal: ctx.signal, timeout: 60000,
                    successWhen: () => !!nextInput()
                });
                if (g.reason === 'aborted') return { status: 'aborted' };
                if (!g.ok) return { status: 'manual', note: 'Verification (upload)' };
                input = nextInput();
            } else {
                input = nextInput();
                if (aborted(ctx)) return { status: 'aborted' };
            }

            // Attach ONLY to a genuinely READY (unlocked, empty) box — exactly
            // what the manual "Use" button does (VA.site.activeUploadInput).
            // Attaching into a still-locked box does nothing on the page (the
            // server-side upload request never fires) yet leaves our File sitting
            // in the input. If no ready box exists yet we WAIT and re-check,
            // exactly like a user waiting for the next box before clicking "Use".
            if (!input) {
                // Slot not mounted/unlocked yet. Log once per slot so a stuck
                // primary dropzone is visible instead of silently spinning.
                if (VA.run._uploadWaitSlot !== slot) {
                    VA.run._uploadWaitSlot = slot;
                    VA.logger.waiting('Waiting for upload slot ' + (slot + 1) +
                        (slot === 0 ? ' (primary)' : '') + ' to unlock…');
                }
                return { status: 'wait' };
            }
            VA.run._uploadWaitSlot = null;

            // Assert the primary-first invariant so a layout change that ever
            // broke it surfaces in the log instead of silently swapping files.
            if (slot === 0 && VA.site.uploadInputs().length > 1) {
                let zoneTxt = '';
                try { zoneTxt = ((input.closest('label, div, button') || input).textContent || '').toLowerCase(); } catch (_) {}
                if (zoneTxt && !/primary/.test(zoneTxt))
                    VA.logger.warn('Primary-slot check: the first upload slot is not labelled "primary"; attaching the primary file to the top-most dropzone by position.');
            }
            VA.state.set({ uploadName: rec.name, uploadPhase: 'uploading' });
            VA.logger.info('Uploading file ' + (slot + 1) + ' of ' + files.length + ': ' +
                rec.name + (slot === 0 ? ' (primary — must be first)' : ''));

            // ── Attach, then advance ONLY when the SERVER confirms the upload ──
            // Our File sitting in the box is NOT proof it reached the server. A
            // file now advances on the page's OWN upload POST 2xx (VA.net.uploads
            // rising) or a NEW rendered applicant card; if neither lands within
            // uploadConfirmMs we AUTOMATICALLY re-click "Use" and keep re-clicking
            // until the server confirms. Only a red upload error pauses
            // (Stop/Skip abort the signal and break out too).
            //
            // Order is never at risk: files 0..N-1 are already confirmed, so the
            // first OPEN box is always THIS file's slot; the primary stays slot 0
            // and CF-gated above; _uploadDone never advances until confirmed.
            // A NEW card ⇒ this file accepted. The baseline is the number of
            // files ALREADY committed this run (`slot`), NOT the raw DOM card
            // count — cards render a beat after their upload, so a late card
            // from the file we just committed could otherwise cross a too-low
            // `uploadedCards()+1` target and falsely confirm THIS file, letting
            // it advance without ever being uploaded (the skipped-file bug).
            // Using max(DOM, committed) means the target can only be reached by
            // a card that belongs to this file — never by a straggler.
            const target = Math.max(VA.site.uploadedCards(), slot) + 1;
            const base = VA.net.uploads;                  // server-confirmed uploads before we start
            // Clamp the wait: a stale high value saved in an existing profile
            // (the old 20s default) must not re-introduce the long stall now that
            // the window is meant to be short.
            const confirmMs = Math.min(5000, Math.max(500, (VA.config.get('uploadConfirmMs') | 0) || 2000));
            // While a real upload is IN FLIGHT (the page's upload_file POST has
            // started but not answered — a slow/busy server still receiving the
            // file) we keep WAITING up to this long instead of re-clicking, so we
            // never fire a duplicate mid-upload. Capped so a truly hung request
            // still eventually falls back to a re-click.
            const inflightMaxMs = Math.max(confirmMs, (VA.config.get('uploadInflightMaxMs') | 0) || 90000);
            const MAX_RED_RETRIES = 2;
            const RED_RETRY_DELAY = 1500;
            const runId = VA.state.get('runId');
            let retry = VA.run._uploadRedRetry;
            if (!retry || retry.runId !== runId || retry.slot !== slot) {
                retry = VA.run._uploadRedRetry = { runId, slot, count: 0 };
            }
            let staleRed = '';
            let redArmed = true;
            const currentRed = () => {
                const err = VA.site.findUploadError();
                if (!err) { redArmed = true; staleRed = ''; return ''; }
                if (!redArmed && err === staleRed) return '';
                return err;
            };
            const redReason = (err) => (slot === 0
                ? 'PRIMARY file (' + rec.name + ') was rejected: '
                : 'File ' + (slot + 1) + ' (' + rec.name + ') was rejected: ') + err;
            let box = input;                              // the first attach uses the box found above
            let needAttach = true;                        // false when we're only WAITING on an in-flight upload (do NOT re-fire)

            for (;;) {
                if (aborted(ctx)) return { status: 'aborted' };

                if (needAttach) {
                    // On a retry round, re-find the box: re-fire on the SAME box if it
                    // still holds our file (a slow/stuck upload), else the first open
                    // box — which, with earlier files confirmed, is exactly this file's
                    // slot. Never re-fire on a detached node.
                    if (!box) {
                        box = (input && input.isConnected !== false && input.files && input.files.length)
                            ? input : nextInput();
                        if (!box) {
                            box = await D.waitForEvent(() => nextInput() || null,
                                { signal: ctx.signal, timeout: confirmMs, fallback: 200 });
                            if (aborted(ctx)) return { status: 'aborted' };
                            if (!box) continue;               // no ready box yet → keep waiting
                        }
                    }

                    const attached = attachFile(box, rec.file);   // this IS "click Use"
                    if (!attached.ok) {
                        VA.state.set({ uploadPhase: 'failed' });
                        return { status: 'error', reason: 'Could not attach ' + rec.name + ': ' + attached.error };
                    }
                    input = box;                                   // remember for a same-box re-fire
                }

                // Wait up to confirmMs for the SERVER's verdict. A file advances
                // ONLY on real proof: the page's own upload POST 2xx (net) or a
                // NEW applicant card rendering (card). There is deliberately no
                // "held in the box" fallback any more — advancing on our own
                // attach is what let the run confirm and leave the page while the
                // files had not actually reached the server.
                const verdict = await D.waitForEvent(() => {
                    if (VA.net.uploads > base) return 'net';                    // page's upload 2xx ✓ (network proof)
                    if (VA.site.uploadedCards() >= target) return 'card';       // a NEW applicant card rendered ✓
                    const err = currentRed();
                    if (err) return { type: 'error', error: err };              // red rejection
                    return false;
                }, { signal: ctx.signal, timeout: confirmMs, fallback: 150 });
                if (aborted(ctx)) return { status: 'aborted' };

                if (verdict && verdict.type === 'error') {
                    // A request already in flight may still succeed despite the
                    // page's early red paint; never duplicate it mid-request.
                    if (VA.net.inflightUpload() && VA.net.inflightAgeMs() < inflightMaxMs) {
                        needAttach = false;
                        continue;
                    }
                    if (retry.count >= MAX_RED_RETRIES) {
                        VA.state.set({ uploadPhase: 'failed' });
                        return { status: 'error', reason: redReason(verdict.error) };
                    }
                    retry.count++;
                    staleRed = verdict.error;
                    redArmed = false;
                    VA.logger.waiting('File ' + (slot + 1) + ' of ' + files.length +
                        ' was rejected — retrying the same file (' + retry.count + '/' + MAX_RED_RETRIES + ')…');
                    await D.sleep(RED_RETRY_DELAY, ctx.signal);
                    if (aborted(ctx)) return { status: 'aborted' };
                    box = null;
                    needAttach = true;
                    continue;
                }

                if (verdict === 'net' || verdict === 'card') {
                    VA.run._uploadDone = slot + 1;
                    VA.run._uploadRedRetry = null;
                    VA.state.set({
                        // Count only files WE confirmed. Using uploadedCards() here
                        // made the panel claim "all uploaded" off the page's static
                        // applicant rows.
                        uploadedCount: Math.max(VA.site.filledUploadInputs(), slot + 1),
                        uploadPhase: (slot + 1) >= files.length ? 'done' : 'uploaded'
                    });
                    // Say HOW it was confirmed so the operator watching the logs can
                    // trust the NETWORK proof vs. the DOM-card fallback.
                    const how = verdict === 'net' ? 'server confirmed the upload (HTTP 200 upload response).'
                        : 'a new applicant card rendered on the page.';
                    VA.logger.ok('File ' + (slot + 1) + ' of ' + files.length + ' verified' +
                        (slot === 0 ? ' — primary uploaded first ✓' : ' ✓') + ' — ' + how);
                    // `more` lets the controller attach the next file at once (no
                    // cooldown) — still strictly one file per call.
                    return { status: 'ok', more: (slot + 1) < files.length };
                }

                // Not confirmed within the window. Decide INTELLIGENTLY (user rule):
                //   • If this file's upload_file POST is still IN FLIGHT (a slow/busy
                //     server is genuinely receiving it), DON'T re-fire — that would
                //     duplicate the upload. Wait another window for it to finish,
                //     capped by inflightMaxMs so a truly hung request still falls
                //     back to a re-click.
                //   • Otherwise nothing is uploading → re-click "Use".
                if (VA.net.inflightUpload() && VA.net.inflightAgeMs() < inflightMaxMs) {
                    VA.logger.waiting('File ' + (slot + 1) + ' of ' + files.length +
                        ' — server is slow but the upload is still in progress; waiting for it to finish…');
                    needAttach = false;   // just wait again — do NOT re-attach (no duplicate)
                    continue;
                }

                // Nothing is in flight (or it hung past the cap): retry promptly.
                // The old path waited another full confirmMs for Cloudflare here,
                // turning one missed confirmation into 20s + 20s. nextInput()
                // already protects a genuinely challenged primary and mirrors the
                // working Use-button fallback for files 2-N.
                const freshErr = currentRed();
                const rawErr = VA.site.findUploadError();
                // If the page never removes its old red message, don't treat it
                // as a brand-new failure immediately after reattach; consume one
                // retry only when this full confirmation window also expires.
                const err = freshErr || (!redArmed && staleRed && rawErr === staleRed ? staleRed : '');
                if (err) {
                    if (retry.count >= MAX_RED_RETRIES) {
                        VA.state.set({ uploadPhase: 'failed' });
                        return { status: 'error', reason: redReason(err) };
                    }
                    retry.count++;
                    staleRed = err;
                    redArmed = false;
                    VA.logger.waiting('File ' + (slot + 1) + ' of ' + files.length +
                        ' was rejected — retrying the same file (' + retry.count + '/' + MAX_RED_RETRIES + ')…');
                    await D.sleep(RED_RETRY_DELAY, ctx.signal);
                    if (aborted(ctx)) return { status: 'aborted' };
                } else {
                    VA.logger.waiting('File ' + (slot + 1) + ' of ' + files.length +
                        ' not confirmed and nothing is uploading — re-clicking "Use" automatically…');
                }
                box = null;         // force a re-find at the top of the loop
                needAttach = true;  // and re-attach on the next round
            }
        },

        // Invoked by the controller ONLY after the user clicks "Confirm &
        // Continue" in the panel. Fires the on-page confirm, then the follow-up
        // Save & Continue popup, and verifies we leave the upload page.
        async confirmUploads(ctx) {
            if (aborted(ctx)) return { status: 'aborted' };
            const confirm = await D.waitForButtonText(SEL.text.confirmInfo, { signal: ctx.signal, timeout: 8000 });
            if (!confirm) return { status: 'wait' };
            D.click(confirm);
            VA.logger.ok('Clicked "Confirm All Information is Correct".');

            const save = await D.waitForButtonText(SEL.text.saveContinue, { signal: ctx.signal, timeout: 10000 });
            if (save) { D.click(save); VA.logger.ok('Clicked "Save & Continue".'); }
            else VA.logger.info('No Save & Continue popup detected — continuing.');
            await D.sleep(800, ctx.signal);
            return { status: 'ok' };
        },

        // ── Stage 6 — Mission & Centre (verify mission, name-match centre) ──
        // Mission is normally pre-filled + disabled → we VERIFY it equals the
        // configured mission. Centre is a click-to-open dropdown → we open it
        // and pick the option whose name matches the configured centre. Any
        // mismatch is a HARD pause (controller), never a guess.
        async centre(ctx) {
            if (aborted(ctx)) return { status: 'aborted' };
            const cfg = VA.config.get();

            // (1) Verify mission against configuration.
            const missionText = detectMissionText();
            if (missionText) VA.state.set({ missionText: missionText });
            if (cfg.mission && missionText && !D.matchName(missionText, cfg.mission)) {
                return { status: 'error', reason: 'Mission on page is "' + missionText +
                    '" but Config says "' + cfg.mission + '". Fix it on the page, then Resume.' };
            }

            // (2) Centre selection.
            const trig = centreTrigger();
            const current = readCentreText(trig);
            if (current) VA.state.set({ centreText: current });

            // Already correct only when the control genuinely reads like a CENTRE
            // — a bare mission name ("Dhaka") must never satisfy a centre match,
            // which is exactly how the mis-picked mission row used to skip
            // selection entirely and advance with no centre set.
            const looksLikeCentre = (t) => {
                const s = (t || '').trim();
                if (!s) return false;
                if (/\bivac\b/i.test(s)) return true;
                if (VA.MISSIONS.some((m) => D.normalize(s) === D.normalize(m))) return false;
                return !!centreLocation(s);
            };
            const alreadyOk = looksLikeCentre(current) && (!cfg.centre || D.matchName(current, cfg.centre) ||
                centreLocation(current) === centreLocation(cfg.centre));
            if (alreadyOk) {
                VA.logger.info('Centre already set to "' + current + '".');
            } else {
                if (!trig) return { status: 'wait' };            // control not mounted yet
                D.click(trig);                                   // open the dropdown
                const opts = await D.waitFor(() => {
                    const o = centreOptions();
                    return o.length ? o : null;
                }, { signal: ctx.signal, timeout: 5000, interval: 200 });
                if (aborted(ctx)) return { status: 'aborted' };
                if (!opts) return { status: 'wait' };            // didn't open — re-tick

                let match;
                if (opts.length === 1) {
                    // Only one centre available → take it immediately, no
                    // name-match needed (spec: don't wait for a predefined match).
                    match = opts[0];
                    VA.logger.info('Only one centre available — selecting it.');
                } else if (cfg.centre) {
                    // Multiple options → match on the LOCATION WORD (Dhaka,
                    // Chittagong, …) so minor formatting differences don't block.
                    const wantLoc = centreLocation(cfg.centre);
                    match = opts.find((o) => D.matchName(o.text, cfg.centre)) ||
                            (wantLoc && opts.find((o) => centreLocation(o.text) === wantLoc));
                }

                if (!match) {
                    try { D.click(trig); } catch (_) {}          // close dropdown
                    const names = opts.map((o) => o.text).join(', ');
                    return { status: 'error', reason: (cfg.centre
                        ? 'No centre matches "' + cfg.centre + '". '
                        : 'Multiple centres available and none configured. ') +
                        'Options: ' + names + '. Select it manually, then Resume.' };
                }
                D.click(match.el);
                VA.logger.ok('Selected centre: ' + match.text + '.');
                // Verify the trigger actually reflects the choice BEFORE Continue.
                // React can re-render a tick late, and confirming while the trigger
                // still reads "Select…" would advance with no centre set. If it
                // hasn't reflected, re-tick (re-open + re-select) instead of
                // confirming blind.
                const reflected = await D.waitFor(() => {
                    const now = readCentreText(centreTrigger());
                    return now && D.matchName(now, match.text) ? now : null;
                }, { signal: ctx.signal, timeout: 3000, interval: 200 });
                if (aborted(ctx)) return { status: 'aborted' };
                if (!reflected) {
                    VA.logger.warn('Centre "' + match.text + '" not reflected on the control yet — re-checking before continuing.');
                    return { status: 'wait' };
                }
                VA.state.set({ centreText: reflected });
            }

            // (3) Confirm Mission & IVAC Center → advance to the calendar.
            let confirm = await D.waitForButtonText(SEL.text.confirmMission, { signal: ctx.signal, timeout: 6000 });
            if (!confirm) confirm = await D.waitForClickable(SEL.submit, { signal: ctx.signal, timeout: 3000 });
            if (!confirm) return { status: 'wait' };
            D.click(confirm);
            VA.logger.ok('Confirmed mission & centre.');
            await D.sleep(800, ctx.signal);
            return { status: 'ok' };
        },

        // ── Stage 3 alt — generic navigate ──────────────────────
        async navigate(ctx) {
            if (aborted(ctx)) return { status: 'aborted' };
            const moved = await clickForward(ctx);
            return { status: moved ? 'ok' : 'wait' };
        },

        // ── Stage 7 — booking mechanics (scheduled by controller) ──
        dates: {
            // On the calendar if the month arrows exist or any day pill renders.
            atCalendar() {
                if (document.querySelector(SEL.nextMonth) || document.querySelector(SEL.prevMonth)) return true;
                return this.pills().length > 0;
            },

            // Parse "August 2026" (or similar) shown near the calendar header.
            readMonth() {
                const nodes = document.querySelectorAll('h1,h2,h3,h4,span,div,p,button');
                for (const n of nodes) {
                    if (n.children.length) continue;
                    const t = (n.textContent || '').trim();
                    const m = t.toLowerCase().match(/^([a-z]+)\s+(\d{4})$/);
                    if (m && MONTHS.indexOf(m[1]) !== -1) {
                        return { month: MONTHS.indexOf(m[1]), year: +m[2], label: t };
                    }
                }
                return null;
            },

            // Every day pill in the visible month (available, selected AND
            // unavailable). Pills are round 9×9 controls whose text is a day
            // number; the wrapper is a <div>, the day itself a <button> (or a
            // disabled <div> when unavailable). classifyDatePill sorts them.
            pills() {
                const out = [];
                document.querySelectorAll('button, div').forEach((el) => {
                    if (el.closest && el.closest('#va-panel-host')) return;
                    const cls = el.getAttribute('class') || '';
                    if (!/rounded-full/.test(cls) || !/w-9|h-9/.test(cls)) return;
                    const t = (el.textContent || '').trim();
                    if (!/^\d{1,2}$/.test(t)) return;
                    const day = parseInt(t, 10);
                    if (day < 1 || day > 31) return;
                    out.push({ el: el, day: day });
                });
                return out;
            },

            // Available (green) days only, keyed YYYY-MM-DD, minus skipDates and
            // Fri/Sat (defense-in-depth — the site already greys those out).
            scan() {
                const mo = this.readMonth();
                const skip = VA.config.get('skipDates') || [];
                const out = [];
                this.pills().forEach((p) => {
                    if (VA.site.classifyDatePill(p.el) !== 'available') return;
                    const key = mo
                        ? mo.year + '-' + String(mo.month + 1).padStart(2, '0') + '-' + String(p.day).padStart(2, '0')
                        : 'day-' + p.day;
                    if (skip.indexOf(key) !== -1) return;
                    if (mo) {
                        const dow = new Date(mo.year, mo.month, p.day).getDay();
                        if (dow === 5 || dow === 6) return;      // Fri / Sat
                    }
                    out.push({ key: key, day: p.day, el: p.el });
                });
                return out;
            },

            // Randomized attempt order (spec: select an available date at
            // random — it need not start from the first). Any user-preferred
            // dates still float to the front (also shuffled) so an explicit
            // preference wins without making the rest deterministic.
            order(cands, preferred) {
                const shuffle = (a) => {
                    for (let i = a.length - 1; i > 0; i--) {
                        const j = Math.floor(Math.random() * (i + 1));
                        const t = a[i]; a[i] = a[j]; a[j] = t;
                    }
                    return a;
                };
                if (!preferred || !preferred.length) return shuffle(cands.slice());
                const pref = [], rest = [];
                cands.forEach((c) => (preferred.indexOf(c.key) !== -1 ? pref : rest).push(c));
                return shuffle(pref).concat(shuffle(rest));
            },

            async gotoNextMonth(ctx) {
                const btn = document.querySelector(SEL.nextMonth);
                if (!btn || btn.disabled || !D.isVisible(btn)) return false;
                const before = (this.readMonth() || {}).label || '';
                D.click(btn);
                // Wait for the header to actually change.
                const changed = await D.waitFor(() => {
                    const now = (this.readMonth() || {}).label || '';
                    return now && now !== before ? now : null;
                }, { signal: ctx.signal, timeout: 4000, interval: 200 });
                return !!changed;
            },

            /**
             * One booking attempt against a single candidate date:
             * select → verify it turns orange → Cloudflare gate → click
             * "Continue Booking" ONCE → wait on the site's own network
             * response (heavy-traffic friendly) raced against a DOM change.
             * Returns { status: success|moved|retry|manual|aborted, reason?, backoff? }.
             */
            async attempt(cand, ctx) {
                if (aborted(ctx)) return { status: 'aborted' };
                const cfg = VA.config.get();
                const CF_T = cfg.verifyTimeout || 45000;         // CF gate cap (legit slow-CF wait)
                const RES_T = Math.min(cfg.attemptTimeout || 20000, 20000); // result-wait AFTER CF — hard ≤20s/date even if an old 25s value is still stored (user rule)
                const attemptNo = (VA.run.current && VA.run.current.tries) || 1;
                const maxTries = cfg.maxTriesPerDate || 3;
                const tag = '[DATE] ' + cand.key + ' [ATTEMPT] ' + attemptNo + '/' + maxTries + ' ';
                VA.logger.info(tag + '[STATUS] selecting date');

                // (a) select the day
                D.click(cand.el);

                // (b) verify it actually became the selected (orange) date —
                //     never proceed on a click that didn't take.
                const selected = await D.waitFor(() => {
                    if (VA.site.classifyDatePill(cand.el) === 'selected') return true;
                    const btn = cand.el.querySelector && cand.el.querySelector('button');
                    if (btn && VA.site.classifyDatePill(btn) === 'selected') return true;
                    return null;
                }, { signal: ctx.signal, timeout: 4000, interval: 200 });
                if (aborted(ctx)) return { status: 'aborted' };
                if (!selected) return { status: 'retry', reason: 'date ' + cand.key + ' did not select' };
                VA.logger.info(tag + '[STATUS] selected — verifying');

                // (c) Cloudflare must pass — gate on "Continue Booking" enabling.
                //     This wait is legitimate (a slow CF challenge), not busywork:
                //     the gate solves via 2Captcha / clicks the inline checkbox and
                //     only alerts a human as a last resort.
                const contEnabled = () => {
                    const b = D.findButtonByText(SEL.text.continueBooking);
                    return !!(b && D.isVisible(b) && !b.disabled && b.getAttribute('aria-disabled') !== 'true');
                };
                const g = await VA.verify.gate({ signal: ctx.signal, timeout: CF_T, successWhen: contEnabled });
                if (g.reason === 'aborted') return { status: 'aborted' };
                if (!g.ok) return { status: 'manual', reason: 'verification' };

                // (c2) Brief settle after CF passes so the token/slot registers,
                //      then go — the old fixed 20s sleep was the main time sink and
                //      is gone. Abort-aware so Stop stays instant.
                await D.sleep(cfg.settleAfterVerify || 1500, ctx.signal);
                if (aborted(ctx)) return { status: 'aborted' };

                // Cloudflare can re-challenge during the settle — re-gate briefly so
                // we never click Booking without a fresh verification.
                if (VA.verify.hasWidget() && !VA.verify.isPassed(contEnabled).ok) {
                    const g2 = await VA.verify.gate({ signal: ctx.signal, timeout: CF_T, successWhen: contEnabled });
                    if (g2.reason === 'aborted') return { status: 'aborted' };
                    if (!g2.ok) return { status: 'manual', reason: 'verification' };
                }

                // (d) click Continue Booking exactly once
                const cont = await D.waitForButtonText(SEL.text.continueBooking, { signal: ctx.signal, timeout: 5000 });
                if (!cont) return { status: 'retry', reason: 'no Continue button' };
                D.click(cont);
                VA.logger.info(tag + '[STATUS] booking clicked — awaiting result');

                // (e) evaluate — race the site's own API verdict vs a DOM change,
                //     capped at attemptTimeout so a dead attempt is declared TIMEOUT
                //     (→ retry) instead of hanging. This is what holds a date attempt
                //     to ~20-25s under heavy traffic.
                const netVerdict = VA.net.awaitNext((evt) => {
                    if (!evt) return false;
                    if (evt.webviewUrl) return true;               // payment link!
                    if (evt.status === 429) return true;           // rate limited
                    if (evt.status >= 400) return true;            // server refused
                    return false;
                }, { signal: ctx.signal, timeout: RES_T });

                const self = this;
                const domVerdict = D.waitFor(() => {
                    if (VA.state.get('paymentUrl')) return 'payment';
                    if (VA.controller && VA.controller.paymentVisible && VA.controller.paymentVisible()) return 'payment';
                    if (!self.atCalendar() && !document.querySelector(SEL.password)) return 'moved';
                    return null;
                }, { signal: ctx.signal, timeout: RES_T, interval: 400 });

                const winner = await Promise.race([
                    netVerdict.then((e) => ({ kind: 'net', e: e })),
                    domVerdict.then((d) => ({ kind: 'dom', d: d }))
                ]);
                if (aborted(ctx)) return { status: 'aborted' };

                if (winner.kind === 'net' && winner.e) {
                    if (winner.e.webviewUrl) { VA.logger.ok(tag + '[STATUS] SUCCESS (payment link)'); return { status: 'success' }; }
                    if (winner.e.status === 429) { VA.logger.warn(tag + '[STATUS] FAILED (429 rate limit) [RETRY]'); return { status: 'retry', reason: 'rate limited (429)', backoff: true }; }
                    if (winner.e.status >= 400) { VA.logger.warn(tag + '[STATUS] FAILED (server ' + winner.e.status + ') [RETRY]'); return { status: 'retry', reason: 'server ' + winner.e.status }; }
                }
                if (winner.kind === 'dom' && winner.d === 'payment') { VA.logger.ok(tag + '[STATUS] SUCCESS (payment)'); return { status: 'success' }; }
                if (winner.kind === 'dom' && winner.d === 'moved') { VA.logger.ok(tag + '[STATUS] SUCCESS (moved past calendar)'); return { status: 'moved' }; }

                // Neither resolved decisively within attemptTimeout → TIMEOUT.
                if (VA.state.get('paymentUrl')) return { status: 'success' };
                if (!this.atCalendar()) return { status: 'moved' };
                const fail = findFailText();
                VA.logger.warn(tag + '[STATUS] TIMEOUT (' + (fail || 'no confirmation') + ') [RETRY]');
                return { status: 'retry', reason: fail || 'no confirmation' };
            }
        }
    };

    // ---- Mission / Centre helpers (custom controls, not <select>) ----

    // The mission the page shows (normally a disabled, pre-filled control).
    // Exact normalized match so the centre "IVAC,Dhaka(JFP)" can't be
    // mistaken for the mission "Dhaka".
    function detectMissionText() {
        const rows = document.querySelectorAll('button[disabled], [aria-disabled="true"], button, [role="button"]');
        for (const el of rows) {
            if (el.closest && el.closest('#va-panel-host')) continue;
            if (!D.isVisible(el)) continue;
            const t = (el.textContent || '').trim();
            if (!t || t.length > 30) continue;
            for (const m of VA.MISSIONS) {
                if (D.normalize(t) === D.normalize(m)) return m;
            }
        }
        return '';
    }

    // The city/location word inside a centre name ("IVAC, Dhaka(JFP)" → "dhaka").
    // Used for flexible matching so punctuation/spacing/suffix differences
    // ("IVAC,Dhaka(JFP)" vs "IVAC, Dhaka (JFP)") never block auto-selection.
    function centreLocation(name) {
        if (!name) return '';
        const norm = D.normalize(name);   // lowercased, chattogram→chittagong, alnum only
        const cities = ['dhaka', 'chittagong', 'sylhet', 'rajshahi', 'khulna'];
        for (const c of cities) if (norm.indexOf(c) !== -1) return c;
        return '';
    }

    // The clickable row that opens the CENTRE dropdown.
    //
    // The mission row is rendered as the same chevron control, marked disabled
    // only via Tailwind classes (opacity-50 cursor-not-allowed) — and a <div> has
    // no `disabled` property, so the old check silently accepted it and the
    // "centre" control was really the mission row. Clicking it opened nothing,
    // and its mission text then satisfied the loose centre match. We now
    // positively identify the CENTRE control by its text ("IVAC" / "Select…")
    // and explicitly reject any control that merely repeats a mission name.
    function centreTrigger() {
        const isMissionText = (el) => {
            const t = D.normalize(el.textContent || '');
            return !!t && VA.MISSIONS.some((m) => t === D.normalize(m));
        };
        const looksCentre = (el) => {
            const t = ((el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
            return /\bivac\b|select/.test(t);
        };

        const cands = [];
        document.querySelectorAll(SEL.centreChevron).forEach((chev) => {
            const trig = chev.closest('button, [role="button"], div');
            if (!trig || (trig.closest && trig.closest('#va-panel-host'))) return;
            if (!D.isVisible(trig)) return;
            cands.push(trig);
        });

        // Prefer an enabled, visible control that reads like the centre picker
        // and is not just the mission row.
        const pick = cands.find((el) => looksCentre(el) && !isMissionText(el) && !D.isControlDisabled(el))
            || cands.find((el) => looksCentre(el) && !isMissionText(el))
            || cands.find((el) => !isMissionText(el) && !D.isControlDisabled(el));
        if (pick) return pick;

        // No usable chevron — fall back to the row whose own text names the
        // centre picker (some builds drop the lucide icon).
        const rows = document.querySelectorAll('button, [role="button"], div');
        for (const el of rows) {
            if (el.closest && el.closest('#va-panel-host')) continue;
            if (!D.isVisible(el)) continue;
            const t = (el.textContent || '').trim();
            if (!t || t.length > 80) continue;
            if (/\bivac\b/i.test(t) && /(centre|center|select)/i.test(t) && !D.isControlDisabled(el)) return el;
        }
        return null;
    }

    // Current centre shown on the trigger, '' while it still says "Select…".
    function readCentreText(trig) {
        if (!trig) return '';
        const t = (trig.textContent || '').trim();
        if (!t || /select\s+ivac/i.test(t)) return '';
        return t;
    }

    // Visible centre options once the dropdown is open.
    //
    // Must return ONLY genuine option rows. The old scan's `/ivac/i` fallback
    // also grabbed the dropdown's own trigger ("Select IVAC center") and the
    // orange "Confirm Mission & IVAC Center" button, so a SINGLE real centre
    // looked like three → the run false-paused "Multiple centres available…".
    // We positively reject the trigger (it carries the chevron), any
    // action/placeholder control ("Select…/Confirm…"), and bare mission names,
    // then de-dupe by city so one centre echoed in two nodes counts once.
    function centreOptions() {
        const trig = centreTrigger();
        const isOption = (b) => {
            if (b.closest && b.closest('#va-panel-host')) return false;
            if (!D.isVisible(b)) return false;
            if (b === trig) return false;                                            // the picker itself
            if (b.querySelector && b.querySelector(SEL.centreChevron)) return false; // triggers carry the chevron; options don't
            const t = (b.textContent || '').trim();
            if (!t || t.length > 80) return false;
            if (/\b(select|confirm|continue|save|next|back|cancel|proceed|submit)\b/i.test(t)) return false; // action/placeholder rows
            if (VA.MISSIONS.some((m) => D.normalize(t) === D.normalize(m))) return false;                    // bare mission name
            return true;
        };
        const out = [];
        const push = (b) => { if (isOption(b)) out.push({ el: b, text: (b.textContent || '').trim() }); };
        document.querySelectorAll('button[class*="rounded-t-2xl"], button[class*="FFF4E6"], button[class*="text-left"], [role="option"]').forEach(push);
        if (!out.length) {
            // Fallback: only visible rows that name an actual IVAC centre (has a city).
            document.querySelectorAll('button, [role="button"]').forEach((b) => {
                if (/\bivac\b/i.test(b.textContent || '') && centreLocation(b.textContent || '')) push(b);
            });
        }
        // De-dupe by centre location so one centre echoed in two nodes counts once.
        const seen = new Set();
        const uniq = [];
        out.forEach((o) => {
            const key = centreLocation(o.text) || D.normalize(o.text);
            if (!seen.has(key)) { seen.add(key); uniq.push(o); }
        });
        return uniq;
    }

    // Expose a couple of helpers the UI uses (Load Centres From Session).
    VA.steps.scrapeCentres = function () {
        const sel = document.querySelector(SEL.centreSelect);
        if (!sel) return [];
        return Array.from(sel.options).map((o) => (o.textContent || '').trim()).filter(Boolean);
    };
    VA.steps.scrapeMissions = function () {
        const sel = document.querySelector(SEL.missionSelect);
        if (!sel) return [];
        return Array.from(sel.options).map((o) => (o.textContent || '').trim()).filter(Boolean);
    };
})();
