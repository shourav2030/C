// ============================================================
//  Phase A regression tests: 3 isolated profiles, non-destructive
//  legacy migration, run-start snapshot FREEZE, and Skip-This-Page
//  cancelling ONLY the current page (the run keeps going).
//
//  These lock in the plan's "Phase A verification" items:
//    • profile isolation   — editing one set never touches another
//    • migration           — legacy config/files → Set 1, non-destructive
//    • snapshot freeze      — config reads return the frozen run profile
//                             while the live working copy changes (Part 16),
//                             with the `book` toggle staying LIVE
//    • skipPage             — stage→'skipped', running stays true, per-page
//                             latches cleared, profile/snapshot/attempts kept
// ============================================================
import test from 'node:test';
import assert from 'node:assert/strict';
import { makeDocument, loadModulesFull } from './harness.mjs';

// load(cb)/switchProfile(id,cb) finish on a microtask (hydrateFileRecs is
// async) — promisify so tests can await them.
const loaded = (VA) => new Promise((res) => VA.config.load(res));
const switched = (VA, id) => new Promise((res) => VA.config.switchProfile(id, res));

// ------------------------------------------------------------
//  Migration (Parts 3-5): legacy single profile → Set 1, others
//  default, legacy keys preserved (non-destructive).
// ------------------------------------------------------------
test('migration: legacy config seeds Set 1, Set 2/3 default, legacy keys preserved', async () => {
    const { doc } = makeDocument();
    const legacyFiles = [
        { name: 'primary.pdf', size: 111, type: 'application/pdf', dataUrl: 'data:application/pdf;base64,AAAA' },
        { name: 'second.pdf', size: 222, type: 'application/pdf', dataUrl: 'data:application/pdf;base64,BBBB' },
    ];
    const { VA } = loadModulesFull(doc, {
        seed: {
            visaAutomatorConfig: { applicantName: 'Alice Legacy', phone: '01710000000', mission: 'Dhaka' },
            visaAutomatorFiles: legacyFiles,
        },
    });
    await loaded(VA);

    // Active profile mirrors the migrated legacy data.
    assert.equal(VA.config.activeId, 'set1');
    assert.equal(VA.config.getLive('applicantName'), 'Alice Legacy');
    assert.equal(VA.config.getLive('phone'), '01710000000');
    assert.equal(VA.config.getLive('mission'), 'Dhaka');

    // The new 3-profile shape is persisted; Set 2/3 are empty defaults.
    let profiles;
    VA.storage.getProfiles((p) => { profiles = p; });
    assert.equal(profiles.active, 'set1');
    assert.equal(profiles.sets.set1.applicantName, 'Alice Legacy');
    assert.equal(profiles.sets.set2.applicantName, '');
    assert.equal(profiles.sets.set3.applicantName, '');

    // Legacy files were copied into the Set 1 files key…
    let set1Files;
    VA.storage.getFilesFor('set1', (f) => { set1Files = f; });
    assert.equal(set1Files.length, 2);
    assert.equal(set1Files[0].name, 'primary.pdf');

    // …and the ORIGINAL legacy keys are still intact (Part 5: non-destructive).
    let legacyCfg, legacyFilesAfter;
    VA.storage.getConfig((c) => { legacyCfg = c; });
    VA.storage.getFiles((f) => { legacyFilesAfter = f; });
    assert.equal(legacyCfg.applicantName, 'Alice Legacy');
    assert.equal(legacyFilesAfter.length, 2);
});

test('migration: no legacy data → all three sets start from defaults', async () => {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc);
    await loaded(VA);
    assert.equal(VA.config.activeId, 'set1');
    assert.equal(VA.config.profileName('set1'), 'Set 1');
    assert.equal(VA.config.profileName('set2'), 'Set 2');
    assert.equal(VA.config.profileName('set3'), 'Set 3');
});

test('normalize: a partial profiles blob fills missing sets and validates active', async () => {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc, {
        seed: { visaAutomatorProfiles: { active: 'set2', sets: { set1: { applicantName: 'Only One' } } } },
    });
    await loaded(VA);
    assert.equal(VA.config.activeId, 'set2');            // requested active honoured
    assert.equal(VA.config.getLive('applicantName'), ''); // set2 was missing → default
    assert.equal(VA.config.profileName('set1'), 'Only One');
    assert.equal(VA.config.profileName('set3'), 'Set 3'); // missing → default name
});

// ------------------------------------------------------------
//  Isolation (Parts 1-6): editing one set never mutates another.
// ------------------------------------------------------------
test('isolation: editing Set 1 never changes Set 2 or Set 3', async () => {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc);
    await loaded(VA);

    VA.config.set({ applicantName: 'One', phone: '100' });
    await switched(VA, 'set2');
    assert.equal(VA.config.getLive('applicantName'), '', 'Set 2 must not inherit Set 1 edits');

    VA.config.set({ applicantName: 'Two', phone: '200' });
    await switched(VA, 'set1');
    assert.equal(VA.config.getLive('applicantName'), 'One', 'Set 1 must be unchanged after editing Set 2');
    assert.equal(VA.config.getLive('phone'), '100');

    await switched(VA, 'set2');
    assert.equal(VA.config.getLive('applicantName'), 'Two');
    assert.equal(VA.config.getLive('phone'), '200');

    // Names reflect each set's applicantName; the untouched set keeps its default.
    assert.equal(VA.config.profileName('set1'), 'One');
    assert.equal(VA.config.profileName('set2'), 'Two');
    assert.equal(VA.config.profileName('set3'), 'Set 3');

    // Persisted shape agrees.
    let profiles;
    VA.storage.getProfiles((p) => { profiles = p; });
    assert.equal(profiles.sets.set1.applicantName, 'One');
    assert.equal(profiles.sets.set2.applicantName, 'Two');
    assert.equal(profiles.sets.set3.applicantName, '');
});

test('isolation: each set persists its files under its OWN key', async () => {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc);
    await loaded(VA);

    // Write directly to the per-set file keys and confirm they don't bleed.
    VA.storage.setFilesFor('set1', [{ name: 's1.pdf', size: 1, type: 'application/pdf', dataUrl: 'data:,' }]);
    VA.storage.setFilesFor('set2', [{ name: 's2.pdf', size: 2, type: 'application/pdf', dataUrl: 'data:,' }]);
    let f1, f2, f3;
    VA.storage.getFilesFor('set1', (f) => { f1 = f; });
    VA.storage.getFilesFor('set2', (f) => { f2 = f; });
    VA.storage.getFilesFor('set3', (f) => { f3 = f; });
    assert.equal(f1[0].name, 's1.pdf');
    assert.equal(f2[0].name, 's2.pdf');
    assert.equal(f3.length, 0);
});

// ------------------------------------------------------------
//  Snapshot freeze (Part 16): during a run, snapshot-aware reads
//  return the FROZEN profile while the live working copy changes.
//  The `book` toggle is the one exception — it stays live so Auto
//  Date Book can be paused/resumed mid-run.
// ------------------------------------------------------------
test('snapshot freeze: get/creds/files return the frozen profile mid-run; book toggle stays live', async () => {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc);
    await loaded(VA);

    VA.config.set({ applicantName: 'Frozen', phone: '999', toggles: { login: true, book: true } });
    VA.config._files = [{ file: {}, name: 'p.pdf', size: 1, type: 'application/pdf' }];

    // Run starts → freeze the active profile.
    VA.run.snap = VA.config.snapshot();

    // Operator edits the profile and toggles mid-run.
    VA.config.set({ applicantName: 'Changed', phone: '888' });
    VA.config.setToggle('login', false);
    VA.config.setToggle('book', false);
    VA.config._files.push({ file: {}, name: 'x.pdf', size: 2, type: 'application/pdf' });

    // Snapshot-aware reads see the FROZEN values (what steps.js reads).
    assert.equal(VA.config.get('applicantName'), 'Frozen');
    assert.equal(VA.config.creds().phone, '999');
    assert.equal(VA.config.files().length, 1, 'frozen file list must not grow mid-run');
    assert.equal(VA.config.toggles().login, true, 'non-book toggles freeze with the run');
    assert.equal(VA.config.toggles().book, false, 'book stays LIVE for mid-run pause/resume');

    // Live reads always see the editable working copy.
    assert.equal(VA.config.getLive('applicantName'), 'Changed');
    assert.equal(VA.config.filesLive().length, 2);

    // Run ends → reads unfreeze back to the live copy.
    VA.run.snap = null;
    assert.equal(VA.config.get('applicantName'), 'Changed');
    assert.equal(VA.config.files().length, 2);
    assert.equal(VA.config.toggles().login, false);
});

// ------------------------------------------------------------
//  Skip This Page (Parts 21-26): cancel the current page only.
//  Loads controller.js too. The trailing tick() inside skipPage()
//  short-circuits at the stability gate on an empty non-payment
//  page, so no stage is acted on.
// ------------------------------------------------------------
test('skipPage: cancels the page only — run keeps going, stage marked skipped, workflow not reset', async () => {
    const { doc } = makeDocument();
    const { VA, sandbox } = loadModulesFull(doc, {
        modules: ['core.js', 'verification.js', 'steps.js', 'controller.js'],
    });
    await loaded(VA);

    // Park on a non-payment upload page so the trailing tick() is inert.
    sandbox.location.href = 'https://www.ivacbd.com/upload';
    sandbox.location.host = 'www.ivacbd.com';
    sandbox.location.hostname = 'www.ivacbd.com';

    // Simulate an active run mid-upload, with real per-page state to clear.
    VA.run.snap = VA.config.snapshot();          // run froze a profile
    VA.run.ac = new AbortController();
    VA.run.lastHref = sandbox.location.href;      // we've been on this page (no SPA change)
    VA.run.acted = { stage: 'upload', at: Date.now() };
    VA.run.queue = [{ cand: 'x' }];
    VA.run.current = { cand: 'x', tries: 1 };
    VA.run.stableStage = 'upload';
    VA.run.stableCount = 2;
    VA.run.nextAttemptAt = Date.now() + 5000;
    VA.run.monthsScanned = 2;
    VA.run._uploadWaitSlot = 1;
    VA.state.set({
        running: true, runId: 3, detected: 'upload', uploadConfirm: 'waiting',
        waitingManual: 'upload', paused: null, trying: '2026-09-20', tryOf: 2, tryMax: 3, nextIn: 7,
        stageStates: { upload: 'running' }, attempts: 5, cycle: 2,
    });

    const snapBefore = VA.run.snap;
    VA.controller.skipPage();

    // The run KEEPS GOING — never stopped, never restarted.
    assert.equal(VA.state.get('running'), true, 'skip must not stop the run');
    assert.equal(VA.state.get('runId'), 4, 'generation bumped to invalidate in-flight work');
    assert.equal(VA.run.snap, snapBefore, 'profile snapshot preserved (same run)');
    assert.equal(VA.state.get('attempts'), 5, 'attempts preserved');
    assert.equal(VA.state.get('cycle'), 2, 'cycle preserved');

    // The skipped stage is marked 'skipped' — NOT success (unfinished upload
    // must never look completed).
    assert.equal(VA.state.get('stageStates').upload, 'skipped');

    // Per-page latches cleared so the next page routes cleanly.
    assert.equal(VA.run.acted, null);
    assert.equal(VA.run.queue.length, 0);   // reset (VM-realm array — compare length, not deepEqual)
    assert.equal(VA.run.current, null);
    assert.equal(VA.run.nextAttemptAt, 0);
    assert.equal(VA.run.monthsScanned, 0);
    assert.equal(VA.run._uploadWaitSlot, null);
    assert.equal(VA.run.busy, false);
    assert.equal(VA.state.get('uploadConfirm'), 'idle', 'upload-confirm park released');
    assert.equal(VA.state.get('waitingManual'), null);
    assert.equal(VA.state.get('trying'), null);
    assert.equal(VA.state.get('tryOf'), 0);

    // The same page/stage is latched as a no-op until the URL changes.
    assert.equal(VA.run._skippedHref, 'https://www.ivacbd.com/upload');
    assert.equal(VA.run._skippedStage, 'upload');
});

test('skipPage: no-op (warns) when nothing is running', async () => {
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc, {
        modules: ['core.js', 'verification.js', 'steps.js', 'controller.js'],
    });
    await loaded(VA);
    VA.state.set({ running: false, runId: 1 });
    VA.controller.skipPage();
    assert.equal(VA.state.get('runId'), 1, 'skip must be inert when not running');
});
