// ============================================================
//  IVAC Slot Automation Pro — license client  (ISOLATED world)
// ------------------------------------------------------------
//  Gates the automation behind a signed subscription license.
//
//  Security model (locked — do not weaken):
//    • The ECDSA P-256 PUBLIC key is embedded here; the PRIVATE key
//      lives ONLY on the licensing server. The extension can VERIFY a
//      signed license but can never MINT one.
//    • No database, no secrets, no origins here. Every network call is
//      relayed through background.js (which owns the API base URL and
//      the host permission) — the content script never fetches the API
//      directly. That avoids page-origin CORS and keeps the base in one
//      trusted place.
//    • isUsable() is SYNCHRONOUS and reads ONLY the in-memory VERIFIED
//      payload. It sits on the hot path (START) and must never touch the
//      network (Phase 41). Online re-validation happens on a ~24h
//      chrome.alarms schedule inside background.js — never inline.
//    • Two INDEPENDENT, license-wide limits are enforced by the server:
//      unique devices and unique browsers. A coarse, privacy-conscious machine
//      fingerprint (deviceId) groups browsers on the same machine into one
//      device — no invasive hardware probing, just OS family + display geometry
//      + timezone hashed with SHA-256, using ONLY signals every browser reports
//      identically (see deviceSignals). A durable browser id (browserId)
//      identifies this browser across reinstalls so it reuses its slot, and a
//      versioned fingerprint lets the server re-key older deviceIds instead of
//      charging a new slot.
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.license) return;

    // ── embedded verifier config ─────────────────────────────
    //  Public key (SPKI, base64) used ONLY to verify signatures, plus the
    //  key id it corresponds to. Regenerate the pair with
    //  scripts/generate-keys.mjs and paste the printed PUBLIC SPKI here;
    //  the private half goes in the server .env and NEVER in this file.
    const PUBLIC_KEY_SPKI_B64 =
        'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE9PEblsweNWkv2/NvrK9E2wX4PNkxzLtirR6Bw1bmrrzOQT0CKtkoE7d3XBN+m3cC8mYip8BIJEbbY/6ajgKIug==';
    const LICENSE_KEY_ID = 'k1';
    // Highest payload version we understand. We ACCEPT v1 or v2 tokens: v1 was
    // maxDevices-only; v2 adds maxBrowsersPerDevice. A device activated before the
    // server bumped to v2 keeps working until its next revalidate hands back a v2.
    const PAYLOAD_VERSION = 2;

    // UI themes the backend may bake into the signed payload. Anything missing
    // or unknown falls back to 'core' (UI/branding only — never a permission).
    const THEMES = ['core', 'boost', 'elite', 'overdrive'];
    function normTheme(t) { return THEMES.indexOf(t) === -1 ? 'core' : t; }

    // Fallback windows used ONLY until the server tells us the real ones
    // (it returns validationIntervalMs + graceMs on every activate/validate).
    const DEFAULT_INTERVAL_MS = 24 * 60 * 60 * 1000;   // re-check ~daily
    const DEFAULT_GRACE_MS = 72 * 60 * 60 * 1000;      // offline tolerance

    const CACHE_KEY = 'ivacLicenseCache';
    const INSTALL_KEY = 'ivacInstallId';
    const DEVICE_KEY = 'ivacDeviceId';           // machine fingerprint (SHA-256 hex)
    const DEVICE_VERSION_KEY = 'ivacDeviceIdV';  // which algorithm produced DEVICE_KEY
    const DEVICE_VERSION = 2;                    // v2 = browser-agnostic signals (see deviceSignals)
    const DEVICE_ID_RE = /^[a-f0-9]{64}$/i;
    const BROWSER_KEY = 'ivacBrowserId';         // durable browser id (UUID)
    const BROWSER_ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

    // ── base64 / bytes helpers ───────────────────────────────
    function b64ToBytes(b64) {
        const bin = atob(String(b64 || ''));
        const out = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
        return out;
    }
    function b64urlToBytes(b64url) {
        let s = String(b64url || '').replace(/-/g, '+').replace(/_/g, '/');
        while (s.length % 4) s += '=';
        return b64ToBytes(s);
    }

    // ── module state ─────────────────────────────────────────
    let _cryptoKey = null;      // imported CryptoKey (verify only)
    let _payload = null;        // last VERIFIED signed payload — the sync source of truth
    let _cache = null;          // { token, licenseId, validationIntervalMs, graceMs, lastValidatedAt, savedAt }
    let _install = '';          // installation UUID (wiped on uninstall)
    let _device = '';           // machine fingerprint (groups browsers on one machine)
    let _browser = '';          // durable browser id — survives a reinstall
    let _usage = null;          // { activeDeviceCount, browsersOnThisDevice } from last server reply
    let _ready = false;         // init finished
    let _checking = false;      // a network op is in flight
    let _error = null;          // last user-safe error message
    let _initPromise = null;    // idempotent init

    const listeners = [];
    function emit() {
        const s = api.getState();
        listeners.forEach((fn) => { try { fn(s); } catch (_) {} });
    }

    // ── storage (own keys; mirrors VA.storage's defensive style) ──
    function getLocal(key) {
        return new Promise((resolve) => {
            try { chrome.storage.local.get(key, (r) => resolve((r && r[key]) || null)); }
            catch (_) { resolve(null); }
        });
    }
    function setLocal(key, val) { try { chrome.storage.local.set({ [key]: val }); } catch (_) {} }
    function removeLocal(key) { try { chrome.storage.local.remove(key); } catch (_) {} }

    // ── verification ─────────────────────────────────────────
    async function ensureKey() {
        if (_cryptoKey) return _cryptoKey;
        _cryptoKey = await crypto.subtle.importKey(
            'spki', b64ToBytes(PUBLIC_KEY_SPKI_B64),
            { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']
        );
        return _cryptoKey;
    }
    // Verify a signed token → its payload object, or null when the signature
    // is bad / malformed / issued for another key or another installation.
    async function verifyToken(token) {
        try {
            const parts = String(token || '').split('.');
            if (parts.length !== 2 || !parts[0] || !parts[1]) return null;
            const data = b64urlToBytes(parts[0]);
            const sig = b64urlToBytes(parts[1]);
            const key = await ensureKey();
            const good = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, sig, data);
            if (!good) return null;
            const payload = JSON.parse(new TextDecoder().decode(data));
            // Accept any version we know (1..PAYLOAD_VERSION); reject only newer/unknown.
            if (!payload || !(payload.v >= 1 && payload.v <= PAYLOAD_VERSION)) return null;
            if (payload.keyId && payload.keyId !== LICENSE_KEY_ID) return null;
            if (_install && payload.installationId && payload.installationId !== _install) return null;
            return payload;
        } catch (_) { return null; }
    }

    // ── time / status helpers ────────────────────────────────
    function daysLeft(iso) {
        if (!iso) return 0;
        const ms = Date.parse(iso) - Date.now();
        return ms <= 0 ? 0 : Math.ceil(ms / 86400000);
    }
    function expired(p) { return !!(p && p.expiresAt && Date.now() > Date.parse(p.expiresAt)); }
    // Validated recently enough to still trust the cache offline (interval + grace)?
    function withinGrace() {
        if (!_cache) return false;
        const interval = _cache.validationIntervalMs || DEFAULT_INTERVAL_MS;
        const grace = _cache.graceMs || DEFAULT_GRACE_MS;
        return (Date.now() - (_cache.lastValidatedAt || 0)) <= (interval + grace);
    }
    // Past the normal re-check interval (still within grace)?
    function revalidationDue() {
        if (!_cache) return false;
        const interval = _cache.validationIntervalMs || DEFAULT_INTERVAL_MS;
        return (Date.now() - (_cache.lastValidatedAt || 0)) > interval;
    }

    // Normalize whatever the user pastes to canonical XXXX-XXXX-XXXX-XXXX.
    function formatKey(raw) {
        const clean = String(raw || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
        if (clean.length === 16) return clean.replace(/(.{4})(.{4})(.{4})(.{4})/, '$1-$2-$3-$4');
        return String(raw || '').trim().toUpperCase();
    }

    // ── network relay (every license fetch goes through background.js) ──
    function bgFetch(endpoint, body) {
        return new Promise((resolve) => {
            let done = false;
            const finish = (v) => { if (!done) { done = true; resolve(v); } };
            try {
                chrome.runtime.sendMessage({ action: 'license_fetch', endpoint, body }, (resp) => {
                    if (chrome.runtime.lastError) { finish({ ok: false, error: 'Cannot reach the licensing server.' }); return; }
                    finish(resp || { ok: false, error: 'No response from the server.' });
                });
            } catch (_) { finish({ ok: false, error: 'Cannot reach the licensing server.' }); }
            setTimeout(() => finish({ ok: false, error: 'The server took too long to respond.' }), 30000);
        });
    }

    // Attach our identities to a request body when we have valid ones. Both are
    // optional: an old server (or a lookup failure) simply omits them and the
    // backend falls back to installationId.
    //  • deviceId  — the machine, so N browsers on one PC = 1 device. When it
    //    changes for a browser that already activated (fingerprint upgrade), the
    //    server notices the drift against the row it stored and re-keys the slot.
    //  • browserId — the durable browser, so a reinstall reuses its slot.
    function withDevice(body) {
        if (_device && DEVICE_ID_RE.test(_device)) body.deviceId = _device;
        if (_browser && BROWSER_ID_RE.test(_browser)) body.browserId = _browser;
        return body;
    }

    // Persist a fresh activate/validate result: verify the token, then cache it.
    async function adopt(data) {
        if (!data || !data.signedLicense) return { ok: false, error: 'The server sent a malformed response.' };
        const payload = await verifyToken(data.signedLicense);
        if (!payload) return { ok: false, error: 'The server response failed its signature check.' };
        _payload = payload;
        _usage = (data.usage && typeof data.usage === 'object') ? data.usage : null;
        _cache = {
            token: data.signedLicense,
            licenseId: payload.licenseId,
            validationIntervalMs: data.validationIntervalMs || DEFAULT_INTERVAL_MS,
            graceMs: data.graceMs || DEFAULT_GRACE_MS,
            lastValidatedAt: Date.now(),
            savedAt: Date.now()
        };
        setLocal(CACHE_KEY, _cache);
        return { ok: true };
    }

    function clearCache() { _payload = null; _cache = null; _usage = null; removeLocal(CACHE_KEY); }

    const HARD_CODES = ['REVOKED', 'BLOCKED', 'SUSPENDED', 'EXPIRED', 'INVALID_KEY', 'NOT_FOUND'];

    // ── public API ───────────────────────────────────────────
    const api = {
        // Synchronous hot-path gate — cache only, never network (Phase 41).
        isUsable() {
            if (!_payload) return false;
            if (_payload.status !== 'ACTIVE') return false;
            if (expired(_payload)) return false;
            if (!withinGrace()) return false;
            return true;
        },
        installationId() { return _install; },
        formatKey,
        getState() {
            const p = _payload;
            return {
                ready: _ready,
                activated: !!p,
                usable: this.isUsable(),
                status: p ? p.status : null,
                planName: p ? p.planName : '',
                theme: normTheme(p && p.theme),
                customerName: p ? p.customerName : '',
                maxDevices: p ? p.maxDevices : 0,
                // LICENSE-WIDE browser limit (total across all devices — NOT per
                // device). v1 tokens have no browser field ⇒ treat as 1.
                maxBrowsersPerDevice: p ? (p.maxBrowsersPerDevice || 1) : 0,
                usage: _usage,
                expiresAt: p ? p.expiresAt : null,
                daysLeft: p ? daysLeft(p.expiresAt) : 0,
                installationId: _install,
                browserId: _browser,
                deviceId: _device,
                checking: _checking,
                error: _error
            };
        },
        on(fn) { listeners.push(fn); return () => { const i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); }; },

        // Activate this device against a license key.
        async activate(licenseKey) {
            const key = formatKey(licenseKey);
            if (!key) { _error = 'Enter your activation key.'; emit(); return { ok: false, error: _error }; }
            _checking = true; _error = null; emit();
            try {
                await ensureInstall();
                await ensureDevice();
                await ensureBrowser();
                const resp = await bgFetch('/api/license/activate', withDevice({
                    licenseKey: key, installationId: _install, extensionVersion: VA.VERSION
                }));
                const data = (resp && resp.data) || null;
                if (!resp || (!resp.ok && !data)) {
                    _error = (resp && resp.error) || 'Cannot reach the licensing server.';
                    return { ok: false, error: _error };
                }
                if (!resp.ok || !data || data.success === false) {
                    _error = (data && data.error) || 'Activation failed.';
                    return { ok: false, code: data && data.code, error: _error };
                }
                const adopted = await adopt(data);
                if (!adopted.ok) { _error = adopted.error; return { ok: false, error: _error }; }
                _error = null;
                VA.logger.ok('License activated — ' + (_payload.planName || 'subscription') + ', ' + daysLeft(_payload.expiresAt) + ' day(s) left.');
                scheduleRevalidation();
                return { ok: true };
            } finally {
                _checking = false; emit();
            }
        },

        // Periodic (~24h) online re-check. Slides the offline window forward on
        // success; on a hard rejection it drops the cache and stops the run.
        async validate(opts) {
            opts = opts || {};
            if (!_payload || !_payload.licenseId) return { ok: false, error: 'Not activated.' };
            _checking = true; if (!opts.silent) emit();
            try {
                await ensureInstall();
                await ensureDevice();
                await ensureBrowser();
                const resp = await bgFetch('/api/license/validate', withDevice({
                    licenseId: _payload.licenseId, installationId: _install, extensionVersion: VA.VERSION
                }));
                const data = (resp && resp.data) || null;
                if (resp && resp.ok && data && data.success !== false) {
                    await adopt(data);
                    _error = null;
                    return { ok: true };
                }
                if (data && HARD_CODES.indexOf(data.code) !== -1) {
                    clearCache();
                    _error = data.error || 'This license is no longer active.';
                    VA.logger.err('License check failed — ' + _error);
                    try { VA.controller && VA.controller.stop && VA.controller.stop('license invalid'); } catch (_) {}
                    return { ok: false, code: data.code, error: _error };
                }
                // Soft failure (offline / server hiccup): keep the cache — grace covers us.
                return { ok: false, soft: true, error: (data && data.error) || 'Could not reach the server.' };
            } finally {
                _checking = false; if (!opts.silent) emit();
            }
        },

        // Release this device's slot so the key can be used on another machine.
        async deactivate() {
            _checking = true; emit();
            try {
                if (_payload && _payload.licenseId) {
                    await ensureInstall();
                    await ensureDevice();
                    await ensureBrowser();
                    await bgFetch('/api/license/deactivate-device', withDevice({
                        licenseId: _payload.licenseId, installationId: _install
                    }));
                }
                clearCache();               // locally deactivate regardless of the server outcome
                _error = null;
                try { VA.controller && VA.controller.stop && VA.controller.stop('device deactivated'); } catch (_) {}
                VA.logger.warn('This device has been deactivated. Re-enter your key to use automation again.');
                return { ok: true };
            } finally {
                _checking = false; emit();
            }
        },

        // Re-read the cache from storage (e.g. after background.js revalidated
        // on its alarm and wrote a fresh token) and notify the UI.
        async refreshFromStorage() { await loadCache(); emit(); },

        // Idempotent: safe to call from both the standalone boot and the resume path.
        init() {
            if (_initPromise) return _initPromise;
            _initPromise = (async () => {
                await ensureInstall();
                await ensureDevice();
                await ensureBrowser();
                await loadCache();
                _ready = true;
                emit();
                // Overdue for a check? Kick one off in the background — NEVER block;
                // isUsable() has already answered from cache.
                if (_payload && revalidationDue()) { api.validate({ silent: true }); }
                // Reflect a cache rewritten by background.js (alarm revalidation).
                try {
                    chrome.storage.onChanged.addListener((changes, area) => {
                        if (area === 'local' && changes[CACHE_KEY]) { loadCache().then(emit); }
                    });
                } catch (_) {}
            })();
            return _initPromise;
        }
    };

    function randomUuid() {
        try { return crypto.randomUUID(); }
        catch (_) {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
                const r = Math.random() * 16 | 0;
                return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });
        }
    }

    async function ensureInstall() {
        if (_install) return _install;
        const existing = await getLocal(INSTALL_KEY);
        if (existing && typeof existing === 'string') { _install = existing; return _install; }
        _install = randomUuid();
        setLocal(INSTALL_KEY, _install);
        return _install;
    }

    // ── durable browser identity (browserId) ─────────────────
    //  INSTALL_KEY lives in chrome.storage.local, which Chrome WIPES on
    //  uninstall — so after a reinstall the install UUID is new and the server
    //  would treat the same browser as an extra one, eventually hitting the
    //  browser limit. We mirror browserId into the HOST PAGE's localStorage
    //  (which survives an extension reinstall), so the same browser is
    //  recognised and reuses its existing activation instead of claiming a new
    //  slot. Best-effort: if the page store is unavailable/unusable we fall back
    //  to a fresh id and simply behave like a new browser.
    function readBrowserFromPage() {
        try { const v = localStorage.getItem(BROWSER_KEY); return (v && BROWSER_ID_RE.test(v)) ? v : ''; }
        catch (_) { return ''; }
    }
    function writeBrowserToPage(id) {
        try { localStorage.setItem(BROWSER_KEY, id); } catch (_) {}
    }
    async function ensureBrowser() {
        if (_browser) return _browser;
        let id = await getLocal(BROWSER_KEY);
        if (!id || typeof id !== 'string' || !BROWSER_ID_RE.test(id)) id = readBrowserFromPage();
        if (!id) id = randomUuid();
        _browser = id;
        setLocal(BROWSER_KEY, id);
        writeBrowserToPage(id);
        return _browser;
    }

    // ── machine fingerprint (deviceId) ───────────────────────
    function bytesToHex(buf) {
        const b = new Uint8Array(buf);
        let s = '';
        for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
        return s;
    }
    async function sha256Hex(str) {
        const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
        return bytesToHex(digest);
    }
    // Collapse a browser-reported platform string to its OS FAMILY. This is what
    // makes DIFFERENT browsers on ONE PC agree: Chrome reports "Windows" (via
    // userAgentData) while Firefox reports "Win32" — both must map to "windows".
    function osFamily(platform) {
        const p = String(platform || '').toLowerCase();
        if (/iphone|ipad|ipod|ios/.test(p)) return 'ios';
        if (/android/.test(p)) return 'android';
        if (/win/.test(p)) return 'windows';
        if (/mac/.test(p)) return 'macos';
        if (/linux|x11|ubuntu|fedora|debian/.test(p)) return 'linux';
        return p || 'unknown';
    }
    // Browser-AGNOSTIC machine signals. Deliberately EXCLUDES everything each
    // browser reports differently — the platform-string spelling, deviceMemory
    // (Chromium-only; Firefox has none) and hardwareConcurrency (browsers cap it
    // differently) — because ANY of those would split one PC into several
    // "devices", which is exactly the bug this fixes. What remains (OS family +
    // display geometry + OS timezone) is identical for every browser on the same
    // machine. Trade-off: two identical-spec PCs in one timezone can collide; the
    // backend's admin device controls remain the escape hatch.
    function deviceSignals(nav, scr, tz) {
        nav = nav || {}; scr = scr || {};
        const platform = (nav.userAgentData && nav.userAgentData.platform) || nav.platform || '';
        return [
            'v' + DEVICE_VERSION,
            osFamily(platform),
            (scr.width || 0) + 'x' + (scr.height || 0) + 'x' + (scr.colorDepth || 0),
            tz || ''
        ].join('|');
    }
    async function computeDeviceId(nav, scr, tz) {
        return sha256Hex(deviceSignals(nav, scr, tz));
    }
    async function ensureDevice() {
        if (_device) return _device;
        const existing = await getLocal(DEVICE_KEY);
        const hasExisting = !!(existing && typeof existing === 'string' && DEVICE_ID_RE.test(existing));
        // A cached id from an OLDER algorithm must be recomputed: this browser
        // then reports its new fingerprint, and the backend re-keys its existing
        // device slot (matched by browserId) instead of charging a new one.
        const version = await getLocal(DEVICE_VERSION_KEY);
        if (hasExisting && version === DEVICE_VERSION) { _device = existing; return _device; }

        let id = '';
        try {
            let tz = '';
            try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (_) {}
            id = await computeDeviceId(navigator || {}, (typeof screen !== 'undefined' && screen) || {}, tz);
        } catch (_) { id = ''; }
        // Fingerprinting unavailable → hash the install id so we still send a
        // well-formed deviceId (this browser then counts as its own device).
        if (!DEVICE_ID_RE.test(id)) {
            try { id = await sha256Hex('install:' + (_install || 'unknown')); }
            catch (_) { _device = ''; return ''; }
        }
        _device = id;
        setLocal(DEVICE_KEY, id);
        setLocal(DEVICE_VERSION_KEY, DEVICE_VERSION);
        return _device;
    }

    async function loadCache() {
        const raw = await getLocal(CACHE_KEY);
        if (!raw || !raw.token) { _payload = null; _cache = null; return; }
        const payload = await verifyToken(raw.token);
        if (!payload) { _payload = null; _cache = null; return; }   // tampered / foreign → ignore
        _payload = payload;
        _cache = {
            token: raw.token,
            licenseId: payload.licenseId,
            validationIntervalMs: raw.validationIntervalMs || DEFAULT_INTERVAL_MS,
            graceMs: raw.graceMs || DEFAULT_GRACE_MS,
            lastValidatedAt: raw.lastValidatedAt || 0,
            savedAt: raw.savedAt || 0
        };
    }

    function scheduleRevalidation() {
        // Ask background.js to (re)arm its ~24h alarm to match the server cadence.
        try {
            chrome.runtime.sendMessage({
                action: 'license_schedule',
                intervalMs: (_cache && _cache.validationIntervalMs) || DEFAULT_INTERVAL_MS
            }, () => { void chrome.runtime.lastError; });
        } catch (_) {}
    }

    // Pure device-fingerprint helpers — exposed for unit tests only (no network,
    // no state). Kept in sync with ensureDevice() above.
    VA.deviceId = {
        VERSION: DEVICE_VERSION,
        osFamily,
        signals: deviceSignals,
        compute: computeDeviceId
    };

    VA.license = api;
})();
