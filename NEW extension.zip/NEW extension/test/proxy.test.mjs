// ============================================================
//  Proxy routing client — dynamic routing from the backend.
// ------------------------------------------------------------
//  The Run tab's "Proxy IP" card prefers the IP served by the
//  backend (VA.proxy.ip → /api/proxy/ip via the service worker)
//  and falls back to the local generator when the server has none
//  or is unreachable. VA.proxy.shift() exposes the rotation API
//  (not wired into the panel yet) for when the endpoint goes live.
// ============================================================
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeDocument, loadModulesFull } from './harness.mjs';

function boot(responses) {
    const calls = [];
    const { doc } = makeDocument();
    const { VA } = loadModulesFull(doc, {
        modules: ['core.js', 'proxy.js'],
        sendMessage(message, callback) {
            calls.push(message);
            const next = responses.shift();
            callback(typeof next === 'function' ? next(message) : next);
        },
    });
    return { VA, calls };
}

test('backend IP is used when the server returns a valid dotted-quad', async () => {
    const { VA, calls } = boot([{ ok: true, ip: '103.15.42.201', source: 'server' }]);
    assert.equal(await VA.proxy.ip(), '103.15.42.201');
    assert.equal(calls[0].action, 'proxy_ip_fetch');
});

test('missing / invalid backend IP resolves to null so the caller can fall back', async () => {
    const { VA } = boot([{ ok: false, error: 'no_ip' }]);
    assert.equal(await VA.proxy.ip(), null);

    const junk = boot([{ ok: true, data: { success: true, ip: 'not-an-ip' } }]);
    assert.equal(await junk.VA.proxy.ip(), null);
});

test('an offline relay is treated as "no backend IP" (never throws)', async () => {
    const { VA } = boot([undefined]);
    assert.equal(await VA.proxy.ip(), null);
});

test('isIpv4 rejects out-of-range octets and short forms', () => {
    const { VA } = boot([]);
    assert.equal(VA.proxy.isIpv4('103.15.42.201'), true);
    assert.equal(VA.proxy.isIpv4('256.1.1.1'), false);
    assert.equal(VA.proxy.isIpv4('1.2.3'), false);
    assert.equal(VA.proxy.isIpv4(''), false);
});

test('shift() returns the rotated IP, ready to wire into the panel', async () => {
    const { VA, calls } = boot([{ ok: true, data: { success: true, ip: '27.147.10.5', region: 'BD', operator: 'X' } }]);
    const out = await VA.proxy.shift();
    assert.equal(out.ok, true);
    assert.equal(out.ip, '27.147.10.5');
    assert.equal(out.region, 'BD');
    assert.equal(out.operator, 'X');
    assert.equal(calls[0].action, 'proxy_shift');
});

test('a shift failure is reported without throwing', async () => {
    const { VA } = boot([{ ok: false, error: 'shift_failed' }]);
    const out = await VA.proxy.shift();
    assert.equal(out.ok, false);
    assert.equal(out.ip, null);
});
