// ============================================================
//  Dependency-free DOM harness for the IVAC extension modules.
//  Stubs just enough of window / document / chrome to load the
//  REAL core.js + steps.js and exercise their pure-logic helpers
//  (upload ordering, centre matching). No jsdom, no npm installs.
// ============================================================
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(__dirname, '..', 'src');

// ---- Minimal DOM node ----------------------------------------
let NODE_SEQ = 0;
export class El {
    constructor(tag = 'div', attrs = {}) {
        this.tagName = tag.toUpperCase();
        this.__id = ++NODE_SEQ;
        this.attributes = {};
        this.children = [];
        this.parentNode = null;
        this.disabled = false;
        this._text = '';
        this._rect = { top: 0, left: 0, width: 10, height: 10, right: 10, bottom: 10 };
        this.files = null;
        this.style = {};
        for (const [k, v] of Object.entries(attrs)) this.setAttribute(k, v);
    }
    setAttribute(k, v) {
        this.attributes[k] = String(v);
        if (k === 'disabled') this.disabled = v !== false && v != null;
    }
    getAttribute(k) { return k in this.attributes ? this.attributes[k] : null; }
    hasAttribute(k) { return k in this.attributes; }
    get className() { return this.attributes.class || ''; }
    set textContent(v) { this._text = v; this.children = []; }
    get textContent() {
        if (this.children.length) return this.children.map((c) => c.textContent).join('');
        return this._text;
    }
    append(...kids) {
        for (const k of kids) { k.parentNode = this; this.children.push(k); }
        return this;
    }
    dispatchEvent() { return true; }
    addEventListener() {}
    removeEventListener() {}
    focus() {}
    select() {}
    // isVisible() checks offsetParent !== null; give every attached node a
    // non-null parent (detached nodes report null, matching the browser).
    get offsetParent() { return this.parentNode || null; }
    // zoneLocked() walks up via parentElement; mirror the DOM property.
    get parentElement() { return this.parentNode || null; }
    getBoundingClientRect() { return this._rect; }
    setRect(top, left, w = 10, h = 10) {
        this._rect = { top, left, width: w, height: h, right: left + w, bottom: top + h };
        return this;
    }
    // walk self + ancestors matching a comma selector list (tag / .class / #id / [attr])
    closest(sel) {
        let el = this;
        while (el) { if (el.__matches(sel)) return el; el = el.parentNode; }
        return null;
    }
    __matches(sel) {
        return sel.split(',').some((s) => matchSimple(this, s.trim()));
    }
    __descendants() {
        const out = [];
        const walk = (n) => { for (const c of n.children) { out.push(c); walk(c); } };
        walk(this);
        return out;
    }
    querySelectorAll(sel) {
        return this.__descendants().filter((n) => n.__matches(sel));
    }
    querySelector(sel) { return this.querySelectorAll(sel)[0] || null; }
}

// Very small CSS matcher: tag, .class, #id, [attr], [attr="v"], [attr*="v" i],
// and simple compound like button.text-left or input[type="file"].
function matchSimple(el, sel) {
    if (!sel) return false;
    const parts = sel.match(/([a-zA-Z0-9*-]+)|\.[^.#\[\s]+|#[^.#\[\s]+|\[[^\]]+\]/g);
    if (!parts) return false;
    for (const p of parts) {
        if (p === '*') continue;
        if (p[0] === '.') {
            const cls = ' ' + (el.className || '') + ' ';
            if (!cls.includes(' ' + p.slice(1) + ' ')) {
                // allow substring class token match on whitespace boundaries
                const tokens = (el.className || '').split(/\s+/);
                if (!tokens.includes(p.slice(1))) return false;
            }
        } else if (p[0] === '#') {
            if (el.getAttribute('id') !== p.slice(1)) return false;
        } else if (p[0] === '[') {
            if (!matchAttr(el, p)) return false;
        } else {
            if (el.tagName !== p.toUpperCase()) return false;
        }
    }
    return true;
}
function matchAttr(el, p) {
    // [attr], [attr="v"], [attr*="v"], with optional " i" case-insensitive
    const m = p.match(/^\[([a-zA-Z0-9_-]+)(?:([*^$|~]?)=(?:"([^"]*)"|'([^']*)'|([^\]\s]+)))?(\s+i)?\]$/);
    if (!m) return false;
    const name = m[1];
    const op = m[2];
    const val = m[3] ?? m[4] ?? m[5];
    const ci = !!m[6];
    if (!el.hasAttribute(name)) return false;
    if (val == null) return true;
    let a = el.getAttribute(name) || '';
    let b = val;
    if (ci) { a = a.toLowerCase(); b = b.toLowerCase(); }
    if (op === '*') return a.includes(b);
    if (op === '^') return a.startsWith(b);
    if (op === '$') return a.endsWith(b);
    return a === b;
}

// ---- document root -------------------------------------------
export function makeDocument() {
    const root = new El('body');
    const doc = {
        body: root,
        documentElement: root,
        querySelectorAll: (sel) => root.querySelectorAll(sel),
        querySelector: (sel) => root.querySelector(sel),
        createElement: (t) => new El(t),
        addEventListener() {},
        removeEventListener() {},
        getElementById: (id) => root.querySelector('#' + id),
    };
    return { doc, root };
}

// ---- load the real modules into a VM sandbox -----------------
// loadModulesFull returns { VA, store, sandbox } so tests can pre-seed
// chrome.storage.local (opts.seed), choose which modules to load
// (opts.modules), and inspect/mutate the sandbox (e.g. location.href).
export function loadModulesFull(doc, opts = {}) {
    const store = { local: Object.assign({}, opts.seed || {}), session: {} };
    const chrome = {
        runtime: {
            getManifest: () => ({ version: '9.2' }),
            sendMessage: opts.sendMessage || (() => {}),
            onMessage: { addListener() {} },
            id: 'test',
            lastError: null,
        },
        storage: {
            local: {
                get: (k, cb) => cb(typeof k === 'string' ? { [k]: store.local[k] } : store.local),
                set: (o, cb) => { Object.assign(store.local, o); cb && cb(); },
            },
            session: {
                get: (k, cb) => cb(typeof k === 'string' ? { [k]: store.session[k] } : store.session),
                set: (o, cb) => { Object.assign(store.session, o); cb && cb(); },
            },
        },
    };
    const win = {};
    const sandbox = {
        window: win,
        document: doc,
        chrome,
        console,
        // Web Crypto + text/encoding globals — needed by license.js's device
        // fingerprint (crypto.subtle.digest + TextEncoder).
        crypto: globalThis.crypto,
        TextEncoder,
        TextDecoder,
        atob: globalThis.atob,
        btoa: globalThis.btoa,
        setTimeout, clearTimeout, setInterval, clearInterval,
        MutationObserver: class { observe() {} disconnect() {} },
        getComputedStyle: () => ({ display: 'block', visibility: 'visible', opacity: '1' }),
        Node: El,
        AbortController,           // used by controller.skipPage() / launchRun()
        Event: (typeof Event !== 'undefined' ? Event : class { constructor(t) { this.type = t; } }),
        KeyboardEvent: (typeof KeyboardEvent !== 'undefined' ? KeyboardEvent
            : class { constructor(t, o) { this.type = t; Object.assign(this, o || {}); } }),
        location: { href: 'https://payment.ivacbd.com/', host: 'payment.ivacbd.com', hostname: 'payment.ivacbd.com' },
    };
    win.window = win;
    sandbox.globalThis = sandbox;
    vm.createContext(sandbox);
    const modules = opts.modules || ['core.js', 'verification.js', 'steps.js'];
    for (const f of modules) {
        const code = fs.readFileSync(path.join(SRC, f), 'utf8');
        vm.runInContext(code, sandbox, { filename: f });
    }
    return { VA: win.VA, store, sandbox };
}

// Backward-compatible: existing tests call loadModules(doc) and use the
// returned VA directly.
export function loadModules(doc, opts) {
    return loadModulesFull(doc, opts).VA;
}
