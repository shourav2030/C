// ============================================================
//  Proxy IP toggle — Config switch that enables/disables the
//  feature. OFF: no proxy is fetched or generated and the Run-tab
//  card reports the dedicated device IP is in use. ON: normal
//  fetch/generate behaviour.
// ============================================================
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeDocument, loadModulesFull } from './harness.mjs';

function classList(initial = '') {
    const set = new Set(initial.split(' ').filter(Boolean));
    return {
        add: (...n) => n.forEach((x) => set.add(x)),
        remove: (...n) => n.forEach((x) => set.delete(x)),
        contains: (n) => set.has(n),
        toggle: (n, on) => { if (on) set.add(n); else set.delete(n); },
    };
}

function boot() {
    const { doc } = makeDocument();
    const { VA, store } = loadModulesFull(doc, { modules: ['core.js', 'panel-css.js', 'ui.js'] });
    VA.logger = { info() {}, ok() {}, warn() {}, err() {} };
    const ui = VA.ui;
    ui.theme = 'boost';   // paid tier — the proxy card is active
    const box = { style: {}, classList: classList('callout proxy') };
    ui.refs = { proxyIp: { textContent: '' }, proxyDemo: { textContent: '' }, proxyBox: box };
    return { VA, ui, box, store };
}

test('the proxyIp toggle defaults to ON', () => {
    const { VA } = boot();
    assert.equal(VA.DEFAULT_CONFIG.toggles.proxyIp, true);
});

test('idle (ON, nothing fetched yet) shows the normal placeholder', () => {
    const { ui, box } = boot();
    ui.refreshProxyIp(false);
    assert.equal(ui.refs.proxyIp.textContent, '—');
    assert.equal(ui.refs.proxyDemo.textContent, '● IP Filtering');
    assert.equal(box.classList.contains('off'), false);
});

test('turning the toggle OFF marks the card disabled and states the device IP is used', () => {
    const { VA, ui, box } = boot();
    VA.config.setToggle('proxyIp', false);
    ui.refreshProxyIp(true);
    assert.equal(ui.refs.proxyIp.textContent, 'Disabled · using dedicated device IP');
    assert.equal(ui.refs.proxyDemo.textContent, '● Direct IP');
    assert.equal(box.classList.contains('off'), true);
});

test('while OFF the card ignores the theme gate and never fetches an IP', () => {
    const { VA, ui, box } = boot();
    VA.config.setToggle('proxyIp', false);
    let fetched = false;
    VA.proxy = { ip: () => { fetched = true; return Promise.resolve('1.2.3.4'); } };
    ui.newProxyIp();
    assert.equal(fetched, false, 'no server fetch must happen while disabled');
    assert.equal(ui.refs.proxyIp.textContent, 'Disabled · using dedicated device IP');
    assert.equal(box.classList.contains('off'), true);
});

test('turning the toggle back ON resumes the normal fetch', () => {
    const { VA, ui, box } = boot();
    VA.config.setToggle('proxyIp', false);
    ui.refreshProxyIp(true);
    assert.equal(box.classList.contains('off'), true);

    VA.config.setToggle('proxyIp', true);
    let fetched = false;
    VA.proxy = { ip: () => { fetched = true; return new Promise(() => {}); } };
    ui.refreshProxyIp(true);
    assert.equal(fetched, true, 'enabling must fetch again');
    assert.equal(box.classList.contains('off'), false);
    assert.equal(box.classList.contains('fetching'), true);
});

test('the disabled state is persisted to storage', () => {
    const { VA, store } = boot();
    VA.config.setToggle('proxyIp', false);
    assert.equal(VA.config.getLive('toggles').proxyIp, false);
    assert.equal(store.local.visaAutomatorConfig.toggles.proxyIp, false);
});
