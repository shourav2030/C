// ============================================================
//  Visa Automator — verification  (ISOLATED world)
// ------------------------------------------------------------
//  Cloudflare Turnstile handling with optional 2Captcha solving.
//  The original detection, nudge, token reading and freshness logic
//  is preserved. When manual verification is required, we first
//  attempt to obtain a token via the 2Captcha API and inject it.
//  If that fails or no API key is set, we fall back to the manual
//  alert flow exactly as before.
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.verify) return;
    const SEL = VA.SELECTORS;

    VA.verify = {
        TTL: 270000,
        _seen: { token: '', at: 0 },
        _solverOff: false, // set true for the rest of the session if the backend reports solving isn't configured

        // ------------------------------------------------------------
        //  Master switch for ALL Cloudflare handling.
        // ------------------------------------------------------------
        //  Config → Automation Toggles → "Auto Solve Cloudflare".
        //  ON  → detect, click, 2Captcha-solve, verify, alert a human if stuck.
        //  OFF → NONE of that: the watcher stays idle, gate() returns straight
        //        away, no checkbox is ticked, no solve is paid for, and no
        //        toast/alert is ever shown. The flow runs as if the extension
        //        had no Cloudflare code at all.
        //  Read LIVE (not the run snapshot) so flipping it takes effect at once.
        enabled() {
            try {
                const t = VA.config && VA.config.getLive && VA.config.getLive('toggles');
                return !(t && t.cf === false);
            } catch (_) { return true; }
        },

        // React to a toggle flip from the Config panel: OFF clears any live
        // challenge state + alert immediately; ON re-arms the normal handling.
        onToggle(on) {
            if (!on) {
                this._endChallenge();
                this._solving = false;
                try { VA.attention && VA.attention.clear(); } catch (_) {}
                VA.state.set({ turnstile: 'off' });
                VA.logger.warn('Cloudflare auto-solve OFF — all Cloudflare handling is blocked (no solve, no alerts).');
            } else {
                VA.state.set({ turnstile: 'n/a' });
                VA.logger.ok('Cloudflare auto-solve ON — challenges will be handled automatically.');
            }
        },

        hasWidget() {
            return !!(
                document.querySelector(SEL.cf.widget) ||
                document.querySelector(SEL.cf.iframe) ||
                document.querySelector(SEL.cf.token) ||
                document.querySelector(SEL.cf.hostCheckbox)
            );
        },

        // The page's own "verified" artwork (green tick / success circle) that
        // the live IVAC build paints once the check passes. Treated as a pass
        // signal in its own right, because an inline checkbox challenge does
        // not always expose a readable token to the host page.
        hasSuccessMark() {
            try {
                const el = document.querySelector(SEL.cf.success);
                return !!(el && VA.dom.isVisible(el));
            } catch (_) { return false; }
        },

        // Is the inline "Verify you are human" checkbox already ticked?
        isChecked() {
            try {
                const cb = document.querySelector(SEL.cf.hostCheckbox);
                return !!(cb && cb.checked);
            } catch (_) { return false; }
        },

        readToken() {
            const els = document.querySelectorAll(SEL.cf.token);
            for (const el of els) {
                const v = el && el.value ? String(el.value) : '';
                if (v.length > 20) return v;
            }
            return '';
        },

        isFresh(token) {
            if (!token) return false;
            if (this._seen.token !== token) this._seen = { token: token, at: Date.now() };
            return (Date.now() - this._seen.at) < this.TTL;
        },

        // Tick the inline "Verify you are human" checkbox.
        //
        // The live IVAC build renders the challenge SAME-ORIGIN (label.Nwax7 +
        // span.QZrez1 + a real checkbox input), so unlike a cross-origin
        // Turnstile iframe it is genuinely reachable and clickable from a
        // content script. We click the label/span (what a human hits) and fall
        // back to the input itself.
        //
        // Debounced per element so a slow server doesn't turn into click spam,
        // which Cloudflare would score as bot-like.
        clickCheckbox() {
            if (!this.enabled()) return false;   // Cloudflare handling switched off
            try {
                const cb = document.querySelector(SEL.cf.hostCheckbox);
                if (!cb || cb.checked) return false;
                const now = Date.now();
                if (this._lastClickAt && (now - this._lastClickAt) < 4000) return false;

                const label = cb.closest('label') || document.querySelector(SEL.cf.hostLabel);
                const span = label ? label.querySelector(SEL.cf.hostSpan) : null;
                const target = span || label || cb;
                if (!VA.dom.isVisible(target) && !VA.dom.isVisible(cb)) return false;

                this._lastClickAt = now;
                try { target.scrollIntoView({ block: 'center' }); } catch (_) {}
                VA.dom.click(target);
                // Some builds only react to the input itself.
                if (!cb.checked && target !== cb) VA.dom.click(cb);
                VA.logger.info('Clicked the Cloudflare "Verify you are human" checkbox.');
                return true;
            } catch (_) { return false; }
        },
        _lastClickAt: 0,

        nudge() {
            // Inline checkbox first — that's the live markup.
            if (this.clickCheckbox()) return;
            const box = document.querySelector(SEL.cf.widget);
            if (box && box.querySelector) {
                try {
                    const label = box.querySelector('label, input[type="checkbox"], .cf-turnstile');
                    if (label) VA.dom.click(label);
                } catch (_) { /* harmless */ }
            }
        },

        // A token in cf-turnstile-response that the PAGE / Turnstile itself
        // produced — i.e. NOT the one we injected. A human tick (or a widget
        // that auto-passes) writes a fresh token we never set, so this is
        // genuine proof of a pass. Our own injected token is deliberately
        // excluded (see isPassed) because it can sit in the field while the
        // page's success callback never ran and the button stays disabled.
        _genuineToken() {
            const tok = this.readToken();
            if (tok && tok !== this._injectedToken && this.isFresh(tok)) return tok;
            return '';
        },
        _injectedToken: '',   // the last token WE handed the page (never counts as proof)

        isPassed(successWhen) {
            // OBSERVABLE proof the PAGE ITSELF accepted the check comes first and
            // is the only fully trustworthy signal:
            //   • its success artwork (#puam6 / svg#aOAb3 / circle.tGBx5), or
            //   • the caller's predicate (e.g. "Continue Booking" now enabled).
            if (this.hasSuccessMark()) return { ok: true, token: '' };
            if (typeof successWhen === 'function') {
                try { if (successWhen()) return { ok: true, token: '' }; } catch (_) {}
            }
            const tok = this.readToken();
            if (tok && this.isFresh(tok)) {
                // A GENUINE, page-produced token proves a pass on its own.
                if (tok !== this._injectedToken) return { ok: true, token: tok };
                // A token WE injected does NOT prove a pass: Cloudflare can hold
                // it in the hidden field while the page's own success callback
                // never ran, leaving the Continue/Confirm button DISABLED — the
                // "verified ✓ but the button stayed greyed out" bug. So when a
                // successWhen predicate exists (the upload / date / booking
                // gates), the injected token is ignored; only the predicate or
                // the artwork may declare the pass. With no predicate to check
                // (the login gate), keep the legacy behaviour and accept it.
                if (typeof successWhen !== 'function') return { ok: true, token: tok };
            }
            return { ok: false };
        },

        // ------------------------------------------------------------
        //  Get the Turnstile sitekey — automatic detection, fallback
        //  to configured value, then iframe URL parsing.
        // ------------------------------------------------------------
        _getSiteKey() {
            // 1. Any element carrying a data-sitekey (the widget container).
            //    A Turnstile sitekey looks like 0x4AAAAAAA… — validate the shape
            //    so a stray data-sitekey on an unrelated element can't poison it.
            const looksLikeKey = (k) => /^0x[0-9a-zA-Z_-]{10,}$/.test(k);
            const cands = document.querySelectorAll('[data-sitekey]');
            for (const el of cands) {
                const key = (el.getAttribute('data-sitekey') || '').trim();
                if (looksLikeKey(key)) return key;
            }

            // 2. Turnstile iframe URL. The sitekey is a path segment or a
            //    query param depending on the widget mode.
            const iframe = document.querySelector(SEL.cf.iframe);
            if (iframe) {
                const src = iframe.getAttribute('src') || '';
                let m = src.match(/[?&]k=(0x[0-9a-zA-Z_-]+)/);
                if (m) return m[1];
                m = src.match(/\/(0x[0-9a-zA-Z_-]{10,})[/?]/);
                if (m) return m[1];
            }

            // 3. Inline scripts / page HTML sometimes carry the key when the
            //    widget is rendered programmatically (turnstile.render).
            try {
                const html = document.documentElement.innerHTML || '';
                const m = html.match(/(?:sitekey|siteKey)["'\s:=]+(0x[0-9a-zA-Z_-]{10,})/);
                if (m) return m[1];
            } catch (_) {}

            // 4. Last resort: an operator-configured key from Config.
            const configKey = VA.config.get('turnstileSiteKey');
            if (configKey && looksLikeKey(String(configKey).trim())) return String(configKey).trim();

            return '';
        },

        // Optional Turnstile params some widgets REQUIRE for a solved token to
        // be accepted: data-action and data-cdata (2Captcha calls them "action"
        // and "data"). Reading them from the host widget lets the solved token
        // match what the site expects.
        _getWidgetMeta() {
            // Read from the element that actually carries the sitekey — the
            // inline checkbox label matches SEL.cf.widget too but never has
            // data-action/data-cdata on it.
            const el = document.querySelector('[data-sitekey]') ||
                document.querySelector(SEL.cf.widget);
            if (!el || !el.getAttribute) return { action: '', cdata: '' };
            return {
                action: (el.getAttribute('data-action') || '').trim(),
                cdata: (el.getAttribute('data-cdata') || el.getAttribute('data-c-data') || '').trim()
            };
        },
        // Relay the solver POST through background.js. A content script cannot
        // POST to api.2captcha.com directly under MV3 (CORS + the IVAC page CSP
        // block it), so the service worker — which holds the host permission —
        // makes the call. `endpoint` is "/createTask" or "/getTaskResult".
        // Resolves with the parsed JSON body; rejects on transport failure.
        _post(endpoint, payload) {
            return new Promise((resolve, reject) => {
                let done = false;
                const finish = (fn, v) => { if (!done) { done = true; fn(v); } };
                try {
                    chrome.runtime.sendMessage({ action: 'captcha_fetch', endpoint, body: payload }, (resp) => {
                        if (chrome.runtime.lastError) { finish(reject, new Error('Cannot reach the CAPTCHA solver.')); return; }
                        if (!resp || resp.ok === false || !resp.data) {
                            const e = new Error((resp && resp.error) || ('2Captcha HTTP ' + ((resp && resp.status) || '?')));
                            if (resp && resp.configured === false) e.notConfigured = true;
                            finish(reject, e);
                            return;
                        }
                        finish(resolve, resp.data);
                    });
                } catch (_) { finish(reject, new Error('Cannot reach the CAPTCHA solver.')); }
                setTimeout(() => finish(reject, new Error('CAPTCHA solver timed out.')), 30000);
            });
        },

        async _solveTurnstile(sitekey, pageurl, timeout = 90000) {
            // No API key is read here: background.js injects `clientKey` from the
            // key it fetched from the backend, so the key never enters the page.
            if (!sitekey) throw new Error('No Turnstile sitekey found');

            // 1. Create task. Pass userAgent (2Captcha recommends matching the
            //    real browser for Turnstile) plus action/cdata when the widget
            //    exposes them — both improve token acceptance.
            const meta = this._getWidgetMeta();
            const task = {
                type: 'TurnstileTaskProxyless',
                websiteURL: pageurl,
                websiteKey: sitekey,
                userAgent: navigator.userAgent
            };
            if (meta.action) task.action = meta.action;
            if (meta.cdata) task.data = meta.cdata;

            const createRes = await this._post('/createTask', { task: task });
            if (createRes.errorId !== 0) {
                throw new Error(`2Captcha createTask error: ${createRes.errorDescription || createRes.errorCode}`);
            }
            const taskId = createRes.taskId;

            // 2. Poll for result
            const deadline = Date.now() + timeout;
            while (Date.now() < deadline) {
                const res = await this._post('/getTaskResult', { taskId: taskId });
                if (res.status === 'ready') {
                    const token = res.solution && res.solution.token;
                    if (token && token.length > 20) return token;
                    throw new Error('2Captcha returned an invalid token');
                }
                if (res.status === 'failed') {
                    throw new Error(`2Captcha solving failed: ${res.errorDescription || 'unknown'}`);
                }
                // still processing – wait
                await new Promise(r => setTimeout(r, 3000));
            }
            throw new Error('2Captcha solving timed out');
        },

        // Deliver a solved token to the page.
        //
        // Writing the hidden input alone is often not enough: React reads the
        // value via the property descriptor, and many integrations only submit
        // once the widget's JS success CALLBACK fires. So we (a) set every
        // known response field React-style, and (b) ask the MAIN world to invoke
        // the Turnstile callback, which is where the page's own submit logic
        // usually lives. Returns true only if something actually accepted it.
        _injectToken(token) {
            if (!token || token.length < 20) return false;
            // Remember exactly what we handed the page so isPassed()/_genuineToken()
            // can tell OUR token apart from one the page produced itself.
            this._injectedToken = token;
            let wrote = 0;

            const setValue = (el) => {
                try {
                    const proto = el.tagName === 'TEXTAREA'
                        ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
                    if (desc && desc.set) desc.set.call(el, token); else el.value = token;
                    el.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
                    wrote++;
                } catch (_) {}
            };

            // (a) every response field the page exposes.
            document.querySelectorAll(SEL.cf.token).forEach(setValue);

            // If the page renders no response field yet, create one inside the
            // form so a normal submit still carries the token.
            if (!wrote) {
                try {
                    const form = document.querySelector('form');
                    if (form) {
                        const inp = document.createElement('input');
                        inp.type = 'hidden';
                        inp.name = 'cf-turnstile-response';
                        inp.value = token;
                        form.appendChild(inp);
                        wrote++;
                    }
                } catch (_) {}
            }

            // (b) fire the widget callback in the PAGE world. A content script
            //     cannot call page JS directly, so we hand the token over via a
            //     postMessage that net-hook.js (MAIN world) picks up.
            try {
                window.postMessage({ __vaCf: 1, token: token }, '*');
            } catch (_) {}

            // Injecting the token is NOT the same as passing. net-hook invokes
            // the page's own Turnstile callback with it and posts back whether a
            // real callback existed; either way we now WAIT for OBSERVABLE
            // success (button enabling / success artwork) in isPassed() before
            // declaring the check passed. No more premature "verified ✓".
            if (wrote) VA.logger.info('2Captcha token placed in ' + wrote + ' field(s) and handed to the page — waiting for the check to actually pass…');
            else VA.logger.info('2Captcha token handed to the page — waiting for the check to actually pass…');
            return wrote > 0;
        },

        async _startCaptchaSolver() {
            if (!this.enabled()) return false;   // Cloudflare handling switched off
            if (this._solverOff) return false; // backend already said solving isn't configured this session
            const sitekey = this._getSiteKey();
            const pageurl = location.href;
            if (!sitekey) {
                // Warn ONCE per page, not on every watcher cycle. An inline
                // checkbox challenge legitimately has no sitekey — clickCheckbox()
                // is the right tool there, so this is not necessarily an error.
                if (this._noKeyWarnedFor !== location.href) {
                    this._noKeyWarnedFor = location.href;
                    VA.logger.info('Cloudflare challenge has no Turnstile sitekey (inline checkbox) — 2Captcha does not apply; using the checkbox instead.');
                }
                return false;
            }

            VA.logger.info('Attempting automated Turnstile solving via 2Captcha…');
            try {
                const token = await this._solveTurnstile(sitekey, pageurl, 120000); // up to 2 min
                return this._injectToken(token);
            } catch (err) {
                if (err && err.notConfigured) {
                    this._solverOff = true;
                    VA.logger.info('Automated solving isn’t enabled for this license — will wait for a manual Cloudflare check when needed.');
                    return false;
                }
                VA.logger.warn(`2Captcha solving failed: ${err.message}`);
                return false;
            }
        },

        // ============================================================
        //  GLOBAL WATCHER — solve Cloudflare on EVERY page, always.
        // ------------------------------------------------------------
        //  gate() only runs at the 5 moments a step needs it. A challenge can
        //  appear at any time (first load, mid-navigation, while the booking
        //  loop is in its gap, or in page-only mode where no step runs at all),
        //  and if nothing touches it the run stalls behind it.
        //
        //  This watcher polls independently of the run and, per challenge:
        //    1) ticks the inline checkbox (the live IVAC markup is same-origin),
        //    2) asks 2Captcha for a token — the user's chosen first resort,
        //    3) only if BOTH fail, raises the human alert + notification.
        //
        //  It runs whether or not a run is active, and stops as soon as the
        //  page shows a pass signal. It never forges a token: step 2 is a real
        //  solve through the licensed 2Captcha account.
        // ============================================================
        watch() {
            if (this._watching) return;
            this._watching = true;
            this._solving = false;
            this._alertedFor = 0;

            const ACTIVE_MS = 1500;    // visible, or a challenge is underway
            const HIDDEN_MS = 5000;    // background tab, nothing underway
            const self = this;

            const loop = async () => {
                if (!self._watching) return;
                const busy = !!(self._challengeAt || self._solving);
                // A background tab with no live challenge needn't scan at full
                // rate — the active tab owns the main thread. It still re-checks
                // (every 5s) so a challenge that appears while hidden is picked up,
                // and it re-checks INSTANTLY the moment the tab is shown, via the
                // visibilitychange listener below. A live challenge always runs at
                // full speed, hidden or not, so automation never stalls behind it.
                if (!(document.hidden && !busy)) {
                    try { await self._watchTick(); } catch (_) {}
                }
                self._timer = setTimeout(loop, document.hidden && !busy ? HIDDEN_MS : ACTIVE_MS);
            };
            self._timer = setTimeout(loop, 1200);   // let the page settle first
            VA.logger.info(this.enabled()
                ? 'Cloudflare watcher armed — challenges are handled automatically on every page.'
                : 'Cloudflare auto-solve is OFF — the watcher stays idle until you switch it on in Config.');
        },

        // Stop the global watcher and release its timer. Idempotent.
        unwatch() {
            this._watching = false;
            if (this._timer) { clearTimeout(this._timer); this._timer = null; }
        },

        async _watchTick() {
            // Master-off: touch nothing, and clear any stale challenge state/alert
            // so switching off mid-challenge leaves no popup behind.
            if (!this.enabled()) { this._endChallenge(); return; }

            // No challenge (or already passed) → make sure any stale alert and
            // per-challenge bookkeeping are cleared, then idle.
            if (!this.hasWidget()) { this._endChallenge(); return; }

            // OBSERVABLE pass only — the page's success artwork, a genuinely
            // ticked same-origin checkbox, or a page-produced token. NEVER the
            // token WE injected: trusting that was the false "verified ✓" bug.
            const passed = this.hasSuccessMark() || this.isChecked() || !!this._genuineToken();
            if (passed) {
                if (this._challengeAt) {
                    VA.state.set({ turnstile: 'verified ✓' });
                    this._toast('Cloudflare verified ✓', 'ok');
                }
                this._endChallenge();
                return;
            }

            // A live, unsolved challenge.
            if (!this._challengeAt) {
                this._challengeAt = Date.now();
                VA.logger.info('Cloudflare challenge detected — handling it automatically…');
                VA.state.set({ turnstile: 'solving…' });
                this._toast('Cloudflare detected — solving…', 'work');
            }

            // (1) Tick the inline checkbox (debounced inside clickCheckbox).
            this.clickCheckbox();

            // (2) 2Captcha FIRST, per the user's instruction. One solve in
            //     flight at a time, and a cooldown between attempts so a
            //     failing solve can't loop — each retry costs real money.
            const cooled = !this._lastSolveAt || (Date.now() - this._lastSolveAt) > 30000;
            if (!this._solving && !this._solverOff && cooled) {
                this._solving = true;
                this._lastSolveAt = Date.now();
                this._startCaptchaSolver()
                    .then((ok) => {
                        // Token delivered — but "solved" is only declared once the
                        // page shows OBSERVABLE success (the _watchTick pass branch
                        // above). Announcing it here on injection alone was the lie.
                        if (ok) this._toast('2Captcha token delivered — verifying…', 'work');
                    })
                    .catch(() => {})
                    .then(() => { this._solving = false; });
            }

            // (3) Only after the solver has had a real chance do we bother a
            //     human. 45s covers a slow 2Captcha turnaround on a busy day.
            const elapsed = Date.now() - this._challengeAt;
            const solverHadItsChance = this._solverOff || (!this._solving && elapsed > 20000);
            if ((elapsed > 45000 || solverHadItsChance) && !this._alertedFor) {
                this._alertedFor = this._challengeAt;
                VA.state.set({ turnstile: 'manual needed' });
                this._toast('CAPTCHA needs you — tick the box', 'warn');
                try {
                    VA.attention && VA.attention.raise({
                        reason: this._solverOff
                            ? 'Cloudflare check needs a human — automated solving is not enabled for this license.'
                            : 'Cloudflare check needs a human — 2Captcha could not solve it. Please tick "Verify you are human" on the IVAC tab.'
                    });
                } catch (_) {}
            }
        },

        // Reset per-challenge bookkeeping so the NEXT challenge gets a fresh
        // solve attempt and a fresh alert (rather than being suppressed).
        _endChallenge() {
            if (!this._challengeAt) return;
            this._challengeAt = 0;
            this._alertedFor = 0;
            this._lastSolveAt = 0;    // next challenge may solve immediately
            try { VA.attention && VA.attention.clear(); } catch (_) {}
        },
        _challengeAt: 0,
        _watching: false,
        _solving: false,
        _alertedFor: 0,
        _lastSolveAt: 0,          // cooldown between paid solve attempts
        _noKeyWarnedFor: '',      // warn-once-per-page for a missing sitekey
        _timer: null,             // setTimeout handle for the watcher loop (cleared by unwatch)

        // Corner toast so the operator can see CAPTCHA state at a glance
        // without reading the log. Rendered by ui.js in its own Shadow DOM.
        _toast(msg, kind) {
            if (!this.enabled()) return;   // no toasts/popups while Cloudflare handling is off
            try { VA.ui && VA.ui.cfToast && VA.ui.cfToast(msg, kind); } catch (_) {}
        },

        /**
         * Ensure verification is satisfied before a critical action.
         * opts: { signal, timeout, successWhen? }
         * Resolves { ok, token?, reason }.
         *   ok:true                → proceed (no widget, fresh token, or predicate)
         *   ok:false reason:manual → Cloudflare needs a human; caller waits
         *   ok:false reason:aborted→ run was stopped
         */
        async gate(opts) {
            opts = opts || {};
            const signal = opts.signal;
            const timeout = opts.timeout != null ? opts.timeout : 45000;
            const successWhen = opts.successWhen;

            if (signal && signal.aborted) return { ok: false, reason: 'aborted' };

            // Cloudflare handling is switched OFF: never wait on, nudge, solve
            // or alert about a challenge — treat readiness as satisfied and let
            // the step proceed (the page's own check, if any, is the operator's).
            if (!this.enabled()) {
                try { VA.attention && VA.attention.clear(); } catch (_) {}
                VA.state.set({ turnstile: 'off' });
                return { ok: true, reason: 'cf-off' };
            }

            let pass = this.isPassed(successWhen);
            if (pass.ok) {
                try { VA.attention && VA.attention.clear(); } catch (_) {}
                VA.state.set({ turnstile: pass.token ? 'token ✓' : 'verified ✓' });
                return { ok: true, token: pass.token };
            }

            if (!this.hasWidget() && !successWhen) {
                try { VA.attention && VA.attention.clear(); } catch (_) {}
                VA.state.set({ turnstile: 'n/a' });
                return { ok: true, reason: 'no-widget' };
            }

            VA.state.set({ turnstile: 'checking…' });
            VA.logger.info('Verification / readiness check…');
            this._toast('Cloudflare detected — solving…', 'work');
            this.nudge();

            const poll = () => { const p = this.isPassed(successWhen); return p.ok ? p : null; };

            // Phase 1 — brief grace (managed widgets often pass instantly)
            const grace = Math.min(3500, timeout);
            let ok = await VA.dom.waitFor(poll, { signal: signal, timeout: grace, interval: 300 });

            // Phase 2 — 2Captcha FIRST (the user's chosen order), human only
            // if that fails. The global watcher may already have a solve in
            // flight; we reuse it rather than creating a competing task, so we
            // never pay for two solves of the same challenge.
            if (!(ok && ok.ok) && !(signal && signal.aborted)) {
                let solverPromise;
                if (this._solving) {
                    solverPromise = Promise.resolve(false);   // watcher owns it
                    VA.logger.info('A CAPTCHA solve is already in progress — waiting on it.');
                } else if (this.hasWidget() && !this._solverOff) {
                    this._solving = true;
                    solverPromise = this._startCaptchaSolver()
                        .catch(() => false)
                        .then((r) => { this._solving = false; return r; });
                } else {
                    solverPromise = Promise.resolve(false);
                }

                // Give the solver a real window before nagging a human. 2Captcha
                // typically answers Turnstile in 15-60s, longer under load.
                const solveWindow = Math.min(Math.max(0, timeout - grace), 60000);
                if (solveWindow > 0) {
                    ok = await VA.dom.waitFor(poll, { signal: signal, timeout: solveWindow, interval: 400 });
                }

                if (!(ok && ok.ok) && !(signal && signal.aborted)) {
                    const solverResult = await solverPromise.catch(() => false);
                    if (solverResult) {
                        // Token injected — give the page a moment to accept it.
                        ok = await VA.dom.waitFor(poll, { signal: signal, timeout: 8000, interval: 300 });
                    }
                }

                // Only NOW involve a human, and keep waiting for the rest of
                // the budget so a solve that lands late still resumes the run.
                if (!(ok && ok.ok) && !(signal && signal.aborted)) {
                    VA.state.set({ turnstile: 'manual needed' });
                    this._toast('CAPTCHA needs you — tick the box', 'warn');
                    try {
                        VA.attention && VA.attention.raise({
                            reason: this._solverOff
                                ? 'Cloudflare "Verify you are human" — automated solving is not enabled for this license. Please tick the box on the IVAC tab.'
                                : 'Cloudflare "Verify you are human" — 2Captcha could not solve it. Please tick the box on the IVAC tab.'
                        });
                    } catch (_) {}
                    const manualWait = Math.min(90000, Math.max(15000, timeout));
                    ok = await VA.dom.waitFor(poll, { signal: signal, timeout: manualWait, interval: 500 });
                }
            }

            if (ok && ok.ok) {
                try { VA.attention && VA.attention.clear(); } catch (_) {}
                VA.state.set({ turnstile: ok.token ? 'token ✓' : 'verified ✓' });
                VA.logger.ok('Verification passed.');
                this._toast('Cloudflare verified ✓', 'ok');
                return { ok: true, token: ok.token };
            }

            if (signal && signal.aborted) {
                try { VA.attention && VA.attention.clear(); } catch (_) {}
                return { ok: false, reason: 'aborted' };
            }

            VA.state.set({ turnstile: 'manual needed' });
            VA.logger.waiting('Human verification required — please solve the Cloudflare check. Automation resumes automatically.');
            return { ok: false, reason: 'manual' };
        }
    };

    // Delivery feedback from net-hook (MAIN world): did a REAL page-side
    // Turnstile callback actually run when we handed over the solved token?
    // This drives honest LOGGING only — never a pass decision (a callback
    // running does not prove the page accepted the token; only observable
    // success does — see isPassed / _watchTick). MAIN→ISOLATED share the DOM
    // window, so a window 'message' from net-hook is delivered here too.
    try {
        window.addEventListener('message', function (ev) {
            if (ev.source !== window) return;
            const d = ev.data;
            if (!d || d.__vaCfDelivered !== 1) return;
            if (d.ok) {
                VA.logger.info('Handed the solved token to the page’s Turnstile callback — the check should tick and enable the button shortly.');
            } else {
                VA.logger.warn('Solved token delivered, but the page exposes no Turnstile callback to accept it automatically — if the box stays unticked, tick "Verify you are human" once by hand and automation continues.');
            }
        }, false);
    } catch (_) {}

    // A tab that has just been shown must be checked at once — the watcher
    // throttles itself in the background (see watch()), so this closes the gap
    // between "challenge appeared while hidden" and "handled".
    try {
        document.addEventListener('visibilitychange', function () {
            if (document.hidden) return;
            const v = VA.verify;
            if (v && v._watching) { try { v._watchTick(); } catch (_) {} }
        });
    } catch (_) {}
})();