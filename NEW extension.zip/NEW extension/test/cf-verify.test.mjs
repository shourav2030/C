// Regression tests for the Cloudflare "false-verified" bug.
//
// The bug: the extension logged "2Captcha token injected + callback fired /
// Verification passed" and showed "verified ✓", but the real page checkbox
// never ticked, so the "Continue Booking" button stayed DISABLED and both
// upload and date-booking dead-ended. Root cause: isPassed()/_watchTick trusted
// the token WE injected as proof of a pass.
//
// The fix these tests lock in: a pass is only declared on OBSERVABLE page state
//   • the page's success artwork (#puam6 / svg#aOAb3 / circle.tGBx5), or
//   • the caller's successWhen predicate (e.g. Continue Booking now enabled), or
//   • a GENUINE token the page produced itself (never the one we injected).
import test from 'node:test';
import assert from 'node:assert/strict';
import { El, makeDocument, loadModules } from './harness.mjs';

const TOK = (c) => c.repeat(40);   // a token long enough to pass readToken()'s >20 guard

// Drop a cf-turnstile-response field carrying `value` into the page.
function tokenField(root, value) {
    const inp = new El('input', { name: 'cf-turnstile-response', type: 'hidden' });
    inp.value = value;
    root.append(inp);
    return inp;
}

test('isPassed: an INJECTED token alone does NOT pass a gate whose button is disabled (the bug)', () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    // Reproduce the exact bad state: our 2Captcha token sits in the hidden
    // field, but the page never accepted it, so Continue Booking is disabled.
    const token = TOK('x');
    V._injectedToken = token;          // this is what _injectToken() records
    tokenField(root, token);
    const continueEnabled = () => false;
    assert.equal(V.isPassed(continueEnabled).ok, false,
        'must NOT report verified while the Continue button is still disabled');
});

test('isPassed: flips to pass the instant the target button enables (observable success)', () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    const token = TOK('x');
    V._injectedToken = token;
    tokenField(root, token);
    let enabled = false;
    const continueEnabled = () => enabled;
    assert.equal(V.isPassed(continueEnabled).ok, false);
    enabled = true;                    // page accepted it → button becomes clickable
    const pass = V.isPassed(continueEnabled);
    assert.equal(pass.ok, true, 'button enabled ⇒ pass');
    assert.equal(pass.token, '', 'observable pass carries no token');
});

test('isPassed: the page success artwork counts as a pass on its own', () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    // No token, no predicate — but the page painted the green success circle.
    root.append(new El('svg', { id: 'aOAb3' }));
    assert.equal(V.isPassed().ok, true);
});

test('isPassed: a GENUINE page-produced token passes even against a disabled-button predicate', () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    V._injectedToken = TOK('y');       // what WE handed the page
    tokenField(root, TOK('z'));        // a DIFFERENT token the page itself wrote
    const pass = V.isPassed(() => false);
    assert.equal(pass.ok, true, 'a token we did not inject is genuine proof');
    assert.equal(pass.token, TOK('z'));
});

test('isPassed: login gate (no successWhen) keeps its legacy accept-injected-token behaviour', () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    const token = TOK('x');
    V._injectedToken = token;
    tokenField(root, token);
    // With no predicate to check (the login gate), the injected token is still
    // accepted — this path was deliberately left unchanged.
    assert.equal(V.isPassed().ok, true);
});

test('_genuineToken excludes our injected token but returns a page-produced one', () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    const field = tokenField(root, TOK('a'));
    V._injectedToken = TOK('a');
    assert.equal(V._genuineToken(), '', 'our own injected token is never genuine');
    field.value = TOK('b');            // page overwrote it with its own token
    assert.equal(V._genuineToken(), TOK('b'));
});

// A live inline challenge: label.Nwax7 + span.QZrez1 + the "human" checkbox,
// no success artwork yet. _solverOff skips the paid 2Captcha path (which only
// errors under the harness) so these gate tests stay fast and focused on the
// pass-decision, which is where the bug lived.
function liveChallenge(root) {
    const label = new El('label', { class: 'Nwax7' });
    label.append(new El('span', { class: 'QZrez1' }));
    label.append(new El('input', { type: 'checkbox', 'aria-label': 'Verify you are human' }));
    root.append(label);
    return label;
}

test('gate: never resolves ok on an injected token while the Continue button stays disabled (the bug)', async () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    V._solverOff = true;
    liveChallenge(root);
    // Our token is already sitting in the field, but the page has NOT accepted
    // it and the button never enables — the exact false-positive condition.
    V._injectedToken = TOK('x');
    tokenField(root, TOK('x'));

    // The box never passes → a human would have to step in. We abort shortly to
    // avoid the 15s manual-wait floor; the point is that up to the abort the
    // gate never once declared success on the injected token.
    const ac = new AbortController();
    setTimeout(() => ac.abort(), 300);
    const res = await V.gate({ successWhen: () => false, signal: ac.signal, timeout: 60000 });
    assert.equal(res.ok, false, 'gate must not report verified on an injected token while the button is disabled');
});

test('gate: passes on the observable predicate, and never hands back the injected token', async () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    V._solverOff = true;
    liveChallenge(root);
    V._injectedToken = TOK('x');
    tokenField(root, TOK('x'));

    let enabled = false;
    setTimeout(() => { enabled = true; }, 400);   // page finally accepts it → button enables
    const res = await V.gate({ successWhen: () => enabled, timeout: 8000 });
    assert.equal(res.ok, true);
    assert.equal(res.token, '', 'passed because the button enabled, NOT because of the injected token');
});

test('gate: passes immediately when the predicate is already satisfied', async () => {
    const { doc, root } = makeDocument();
    const V = loadModules(doc).verify;
    V._solverOff = true;
    liveChallenge(root);
    const res = await V.gate({ successWhen: () => true, timeout: 1000 });
    assert.equal(res.ok, true);
});
