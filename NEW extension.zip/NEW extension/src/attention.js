// ============================================================
//  Visa Automator — attention  (ISOLATED world)
// ------------------------------------------------------------
//  Makes the HUMAN step (solving a Cloudflare "Verify you are
//  human" check) as fast and unmissable as possible — the point
//  is to lose as little time as we can during a heavy-traffic
//  booking rush. This does NOT bypass or solve anything: it only
//  draws a person's attention to the tab so they can tick the box.
//
//    • scrolls the challenge into view,
//    • flashes the panel,
//    • plays a short beep (best-effort — may be blocked by autoplay),
//    • asks the background worker to focus this tab/window and pop a
//      desktop notification.
//
//  Debounced: the loud parts fire once per challenge (until clear()),
//  so a slow server that keeps us waiting never turns into beep spam.
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || VA.attention) return;
    const SEL = VA.SELECTORS;

    let active = false;
    let audioCtx = null;

    function beep() {
        try {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            audioCtx = audioCtx || new AC();
            if (audioCtx.state === 'suspended') audioCtx.resume().catch(function () {});
            const now = audioCtx.currentTime;
            [0, 0.18].forEach(function (t, i) {
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.type = 'sine';
                osc.frequency.value = i === 0 ? 880 : 1180;
                gain.gain.setValueAtTime(0.0001, now + t);
                gain.gain.exponentialRampToValueAtTime(0.25, now + t + 0.02);
                gain.gain.exponentialRampToValueAtTime(0.0001, now + t + 0.15);
                osc.connect(gain); gain.connect(audioCtx.destination);
                osc.start(now + t); osc.stop(now + t + 0.16);
            });
        } catch (_) { /* best-effort */ }
    }

    function scrollChallengeIntoView() {
        try {
            const el = document.querySelector(SEL.cf.iframe) ||
                document.querySelector(SEL.cf.widget) ||
                document.querySelector(SEL.cf.hostCheckbox);
            if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
        } catch (_) {}
    }

    VA.attention = {
        // Draw a human to the tab. Safe to call every tick — only the first
        // call per challenge does the loud work; later calls just re-scroll.
        raise(opts) {
            opts = opts || {};
            scrollChallengeIntoView();
            if (active) return;
            active = true;
            try { if (VA.ui && VA.ui.flash) VA.ui.flash(true); } catch (_) {}
            if (opts.sound !== false) beep();
            try {
                chrome.runtime.sendMessage({
                    action: 'attention',
                    reason: opts.reason || 'Cloudflare human check needed on the IVAC tab.',
                    title: 'IVAC SLOT AUTOMATION PRO — action needed'
                }, function () { void chrome.runtime.lastError; });
            } catch (_) {}
            VA.logger.waiting('🔔 ' + (opts.reason || 'Human verification needed') + ' — this tab was brought to the front.');
        },

        // Challenge cleared / no longer needed — stop flashing and drop the
        // desktop notification.
        clear() {
            if (!active) return;
            active = false;
            try { if (VA.ui && VA.ui.flash) VA.ui.flash(false); } catch (_) {}
            try { chrome.runtime.sendMessage({ action: 'attention_clear' }, function () { void chrome.runtime.lastError; }); } catch (_) {}
        },

        isActive() { return active; }
    };
})();
