// ============================================================
//  Visa Automator — net bridge  (ISOLATED world, document_start)
// ------------------------------------------------------------
//  Installs the postMessage listener AS EARLY AS POSSIBLE so that
//  network events emitted by net-hook.js before the heavy modules
//  (document_idle) exist are not lost. Events are buffered on an
//  ISOLATED-world global array (`window.__VA_NET_QUEUE`) which the
//  same-world modules drain once VA.net is ready. (R4)
//
//  Note: this global lives in the ISOLATED world and is shared with
//  core/controller (same world); it is invisible to net-hook.js
//  (MAIN world), which is exactly why the bridge lives here.
// ============================================================
(function () {
    'use strict';
    const Q = (window.__VA_NET_QUEUE = window.__VA_NET_QUEUE || []);
    if (window.__VA_BRIDGE_BOUND) return;
    window.__VA_BRIDGE_BOUND = true;

    window.addEventListener('message', function (ev) {
        // Only trust messages this window posted to itself (net-hook uses window.postMessage).
        if (ev.source !== window) return;
        const d = ev.data;
        if (!d || d.__va !== 1) return;

        const evt = {
            url: d.url || '',
            method: d.method || 'GET',
            status: d.status | 0,
            webviewUrl: d.webviewUrl || '',
            // In-flight upload tracking (see net-hook). `inflight` is the page's
            // live count of pending upload_file POSTs; `phase` marks a start/end
            // ping that only moves the counter (no HTTP status to log).
            inflight: (typeof d.inflight === 'number') ? d.inflight : undefined,
            phase: d.phase || ''
        };

        // Deliver live if the consumer is ready; otherwise buffer for drain.
        const VA = window.VA;
        if (VA && VA.net && typeof VA.net._ingest === 'function') {
            try { VA.net._ingest(evt); } catch (_) { Q.push(evt); }
        } else {
            Q.push(evt);
            if (Q.length > 200) Q.shift(); // never grow unbounded before drain
        }
    }, false);
})();
