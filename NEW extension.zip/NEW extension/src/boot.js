// ============================================================
//  Visa Automator — boot  (ISOLATED world, document_idle)
// ------------------------------------------------------------
//  Wires everything together exactly once (R7):
//    • registers the single chrome.runtime.onMessage handler
//      (toolbar toggle + payment-URL fallback from background.js),
//    • hydrates saved config + files (Start is gated on this — see
//      controller.start), then drains any network events the bridge
//      buffered before VA.net existed,
//    • restores panel open/closed and auto-resumes a run that was
//      active before an SPA reload / navigation.
// ============================================================
(function () {
    'use strict';
    const VA = window.VA;
    if (!VA || window.__VA_BOOTED) return;
    window.__VA_BOOTED = true;

    // (0) Start license verification immediately (idempotent). isUsable() is a
    //     synchronous cache read, but we must let init() verify the cached
    //     signed license before auto-resuming a run below (the gate reads it).
    const licenseReady = (VA.license && VA.license.init) ? VA.license.init() : Promise.resolve();

    // (1) single message handler
    try {
        chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
            if (!msg || !msg.action) return;
            if (msg.action === 'toggle_widget') {
                try { VA.ui.toggle(); } catch (e) { VA.logger.err('toggle: ' + e.message); }
                sendResponse && sendResponse({ ok: true });
            } else if (msg.action === 'payment_url' && msg.url) {
                VA.controller.onPayment(msg.url);
                sendResponse && sendResponse({ ok: true });
            }
        });
    } catch (e) { /* not in an extension context */ }

    // (1b) Keyboard shortcut — Alt+Shift+R resumes without hunting for the
    //      panel: clears a hard pause, or flips Auto Date Book back on. Handy
    //      right after a coworker solves a challenge or books a slot by hand.
    try {
        document.addEventListener('keydown', (ev) => {
            if (!ev.altKey || !ev.shiftKey || (ev.key !== 'R' && ev.key !== 'r')) return;
            try {
                if (VA.state.get('paused')) VA.controller.resumeManual();
                else if (VA.config.toggles && !VA.config.toggles().book) VA.controller.setBooking(true);
            } catch (e) { VA.logger.err('shortcut: ' + e.message); }
        }, true);
    } catch (_) {}

    // (1c) Arm the GLOBAL Cloudflare watcher. Independent of the run loop, so a
    //      challenge is handled on every page and at every moment — including
    //      before Start, between stages, and during the booking gap. 2Captcha
    //      is tried first; a human is only alerted if that fails.
    try { VA.verify && VA.verify.watch && VA.verify.watch(); }
    catch (e) { VA.logger.err('cf watcher: ' + e.message); }

    // (2) hydrate, then boot the UI
    VA.config.load(() => {
        // Drain network events captured before the consumer was ready.
        try { VA.net.drain(); } catch (_) {}

        VA.logger.info('Ready — settings loaded. ' + VA.config.files().length + ' file(s) queued.');

        VA.storage.getUi((u) => {
            u = u || {};
            // Show the panel by default; honor an explicit prior "closed".
            if (u.panelOpen === false) VA.ui.mount();
            else VA.ui.show();

            // Auto-resume a run interrupted by a page reload/navigation —
            // in whichever mode it was running (full, or page-only booking).
            // Wait for the license check first; the controller gate refuses to
            // launch without a usable license (and will surface the panel).
            if (u.running) {
                const datesOnly = !!u.datesOnly;
                VA.logger.info('Detected an active run before reload — resuming automatically' + (datesOnly ? ' (date page only)' : '') + '.');
                licenseReady.then(() => {
                    VA.run.setTimeout(() => {
                        try { datesOnly ? VA.controller.startDatesOnly() : VA.controller.start(); }
                        catch (e) { VA.logger.err('resume: ' + e.message); }
                    }, 1200);
                });
            }
        });
    });
})();
